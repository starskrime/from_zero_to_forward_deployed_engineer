"""Load the leads CSV into SQLite."""
import csv
import sqlite3
from pathlib import Path

LEADS = """CREATE TABLE IF NOT EXISTS leads (
    lead_id TEXT PRIMARY KEY, full_name TEXT NOT NULL, email TEXT NOT NULL, loan_amount REAL NOT NULL,
    credit_score INTEGER NOT NULL, annual_income REAL NOT NULL, property_state TEXT NOT NULL,
    loan_type TEXT NOT NULL, created_at TEXT NOT NULL, zip TEXT, city TEXT)"""


def seed(conn: sqlite3.Connection, csv_path: Path) -> int:
    conn.execute(LEADS)
    with open(csv_path, newline="") as f:
        rows = list(csv.DictReader(f))
    conn.executemany(
        "INSERT OR REPLACE INTO leads VALUES (:lead_id, :full_name, :email, :loan_amount, :credit_score, "
        ":annual_income, :property_state, :loan_type, :created_at, :zip, :city)", rows)
    conn.commit()
    return len(rows)
