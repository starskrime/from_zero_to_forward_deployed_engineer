"""The final assessment the agent must produce."""
from typing import Literal

from pydantic import BaseModel, model_validator

TIER_RANGES = {"hot": (8, 10), "warm": (5, 7), "cold": (1, 4)}


class LeadScore(BaseModel):
    lead_id: str
    score: int
    tier: Literal["hot", "warm", "cold"]
    monthly_payment: float | None
    dti_pct: float | None
    reasons: list[str]
    risks: list[str]
    next_action: str

    @model_validator(mode="after")
    def score_matches_tier(self):
        low, high = TIER_RANGES[self.tier]
        if not low <= self.score <= high:
            raise ValueError(f"score {self.score} is outside the {self.tier} range {low}-{high}")
        return self
