# Break it & fix it: Week 1

This small lead-qualifier agent looks fine and runs without errors. It has six
bugs, each one a mistake that shows up in real agent loops and tool code.

    pip install openai pydantic httpx pytest
    python -m pytest -q

Six tests fail. Fix the code in `lead_agent/`, never the tests. For each bug,
write one line in `BUGS.md`: what was wrong, what a user would have seen in
production, and how you fixed it.

Everything runs offline: the model replies are scripted and served through
`httpx.MockTransport`, so there is no API key and no cost. Like the real
Responses API, the fake in `tests/fakes.py` rejects a request (HTTP 400) when
a tool result has no matching call in the input, or a call has no result.
Read it before you start: knowing what the API checks is half the job.
