"""Six of these tests fail. Each failure is a bug in lead_agent/, not in the tests. Fix the code."""
import json
import sqlite3

import pytest
from pydantic import ValidationError

from lead_agent.agent import AgentError, RunStats, final_assessment, qualify, run_agent
from lead_agent.schema import LeadScore
from lead_agent.store import seed
from lead_agent.tools import DATA, TOOL_SCHEMAS, Tools
from tests.fakes import function_call, message, reasoning, response, scripted_client


@pytest.fixture
def tools():
    conn = sqlite3.connect(":memory:")
    seed(conn, DATA / "leads_clean.csv")
    return Tools(conn)


def outputs(request: dict) -> list[dict]:
    return [i for i in request["input"] if i.get("type") == "function_call_output"]


# ---- tools --------------------------------------------------------------------------------

def test_payment_and_dti_match_the_answer_key(tools):
    assert json.loads(tools.run("calculate_payment", '{"principal": 405000, "annual_rate_pct": 6.25, "years": 30}')) \
        == {"monthly_payment": 2493.65}
    assert json.loads(tools.run("calculate_dti", '{"annual_income": 69000, "monthly_debts": 1650, '
                                                 '"new_monthly_payment": 1613.18}')) == {"dti_pct": 56.8}


def test_state_filter_treats_input_as_a_value(tools):
    assert {r["lead_id"] for r in tools.list_leads_by_state("tx")} == {"L-1001", "L-1007", "L-1014", "L-1016"}
    assert tools.list_leads_by_state("TX' OR '1'='1") == []


def test_bad_arguments_come_back_as_errors(tools):
    missing_arg = json.loads(tools.run("calculate_payment", '{"principal": 300000}'))
    broken_json = json.loads(tools.run("get_lead", '{"lead_id": "L-1001"'))
    no_such_lead = json.loads(tools.run("get_lead", '{"lead_id": "L-9999"}'))
    assert "error" in missing_arg and "error" in broken_json and "error" in no_such_lead


def test_only_declared_tools_can_run(tools):
    result = json.loads(tools.run("delete_lead", '{"lead_id": "L-1001"}'))
    assert "error" in result
    assert tools.get_lead("L-1001")["full_name"] == "Maria Gonzalez"


def test_tool_schemas_are_strict():
    for tool in TOOL_SCHEMAS:
        params = tool["parameters"]
        assert tool["strict"] is True
        assert params["additionalProperties"] is False, tool["name"]
        assert sorted(params["required"]) == sorted(params["properties"]), tool["name"]


# ---- the loop -----------------------------------------------------------------------------

def test_happy_path_sends_results_back(tools):
    requests = []
    client = scripted_client([
        response([reasoning(), function_call("list_leads_by_state", state="TX")]),
        response([reasoning(), function_call("calculate_payment", principal=405000, annual_rate_pct=6.25, years=30)]),
        response([message("Nadia Aliyeva (L-1016): $2,493.65 per month.")]),
    ], requests)
    stats = RunStats()
    conversation = run_agent(client, tools, "Largest Texas loan, payment at 6.25%?", stats)
    assert json.loads(outputs(requests[2])[-1]["output"]) == {"monthly_payment": 2493.65}
    assert [i.get("type") for i in requests[1]["input"]][1:3] == ["reasoning", "function_call"]
    assert stats.steps == 3 and stats.tool_calls == 2
    assert stats.cost_usd == pytest.approx(3 * (100 * 0.10 + 20 * 0.50) / 1_000_000)
    assert conversation[-1].type == "message"


def test_text_next_to_a_tool_call_does_not_end_the_run(tools):
    requests = []
    client = scripted_client([
        response([message("Let me pull the lead record first."), function_call("get_lead", lead_id="L-1016")]),
        response([message("L-1016 is Nadia Aliyeva in Addison, TX.")]),
    ], requests)
    run_agent(client, tools, "Who is L-1016?", RunStats())
    assert len(requests) == 2, "the loop stopped while a tool call was still unanswered"
    assert "Addison" in outputs(requests[1])[0]["output"]


def test_step_limit_stops_a_model_that_never_finishes(tools):
    requests = []
    client = scripted_client([response([function_call("get_lead", lead_id="L-1001")]) for _ in range(5)], requests)
    with pytest.raises(AgentError):
        run_agent(client, tools, "q", RunStats(), max_steps=3)
    assert len(requests) == 3


def test_parallel_calls_are_all_answered(tools):
    requests = []
    client = scripted_client([
        response([function_call("get_lead", lead_id="L-1016"), function_call("get_crm_notes", lead_id="L-1016")]),
        response([message("Nadia Aliyeva: 9 years employed.")]),
    ], requests)
    run_agent(client, tools, "Tell me about L-1016.", RunStats())
    sent = outputs(requests[1])
    assert len(sent) == 2
    assert "Addison" in sent[0]["output"] and "employment_years" in sent[1]["output"]


# ---- the final assessment -----------------------------------------------------------------

ASSESSMENT = {"lead_id": "L-1016", "score": 9, "tier": "hot", "monthly_payment": 2493.65, "dti_pct": 26.7,
              "reasons": ["768 credit", "DTI 26.7%"], "risks": [], "next_action": "Call today."}


def test_qualify_end_to_end(tools):
    requests = []
    client = scripted_client([
        response([reasoning(), function_call("get_lead", lead_id="L-1016")]),
        response([message("I have what I need.")]),
        response([message(json.dumps(ASSESSMENT))]),
    ], requests)
    score, stats = qualify(client, tools, "L-1016")
    assert score.tier == "hot" and score.score == 9
    assert any(i.get("type") == "function_call" for i in requests[2]["input"])
    assert stats.steps == 2 and stats.input_tokens == 300


def test_score_outside_its_tier_is_rejected(tools):
    client = scripted_client([response([message(json.dumps({**ASSESSMENT, "score": 3}))])])
    with pytest.raises(ValidationError):
        final_assessment(client, [{"role": "user", "content": "Qualify lead L-1016."}], RunStats())
    with pytest.raises(ValidationError):
        LeadScore(**{**ASSESSMENT, "tier": "cold"})
