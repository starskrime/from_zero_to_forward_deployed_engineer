"""Scripted Responses API replies, served through httpx.MockTransport: no network, no API key.

Like the real API, this fake rejects (HTTP 400) a request whose input breaks the tool-call protocol:
- a function_call_output whose call_id matches no function_call earlier in the input;
- a function_call in the input with no function_call_output after it.
It also returns 400 when the code makes more API calls than the test scripted.
"""
import itertools
import json

import httpx
from openai import OpenAI

_ids = itertools.count(1)
USAGE = {"input_tokens": 100, "output_tokens": 20, "total_tokens": 120,
         "input_tokens_details": {"cached_tokens": 0}, "output_tokens_details": {"reasoning_tokens": 0}}


def response(output: list) -> dict:
    return {"id": f"resp_{next(_ids)}", "object": "response", "created_at": 0, "model": "gpt-6-luna",
            "status": "completed", "output": output, "usage": USAGE,
            "parallel_tool_calls": True, "tool_choice": "auto", "tools": []}


def reasoning() -> dict:
    return {"type": "reasoning", "id": f"rs_{next(_ids)}", "summary": []}


def function_call(name: str, **arguments) -> dict:
    n = next(_ids)
    return {"type": "function_call", "id": f"fc_{n}", "call_id": f"call_{n}", "name": name,
            "arguments": json.dumps(arguments), "status": "completed"}


def message(text: str) -> dict:
    return {"type": "message", "id": f"msg_{next(_ids)}", "status": "completed", "role": "assistant",
            "content": [{"type": "output_text", "text": text, "annotations": []}]}


def _error(text: str) -> httpx.Response:
    return httpx.Response(400, json={"error": {"message": text, "type": "invalid_request_error",
                                               "param": "input", "code": None}})


def protocol_error(items: list) -> str | None:
    """Return why the API would reject this input, or None if it is well-formed."""
    seen_calls, answered = set(), set()
    for item in items:
        kind = item.get("type")
        if kind == "function_call":
            seen_calls.add(item["call_id"])
        elif kind == "function_call_output":
            if item["call_id"] not in seen_calls:
                return f"No tool call found for function call output with call_id {item['call_id']}."
            answered.add(item["call_id"])
    missing = seen_calls - answered
    if missing:
        return f"No tool output found for function call {sorted(missing)[0]}."
    return None


def scripted_client(replies: list[dict], requests: list | None = None) -> OpenAI:
    """Each API call gets the next reply; request bodies are saved so tests can inspect them."""
    queue = list(replies)

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        if requests is not None:
            requests.append(body)
        items = body["input"] if isinstance(body["input"], list) else []
        problem = protocol_error(items)
        if problem:
            return _error(problem)
        if not queue:
            return _error("Script exhausted: the code made more API calls than this test scripted.")
        return httpx.Response(200, json=queue.pop(0))

    return OpenAI(api_key="test", max_retries=0,
                  http_client=httpx.Client(transport=httpx.MockTransport(handler)))
