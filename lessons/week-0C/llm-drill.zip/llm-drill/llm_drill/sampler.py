"""The last step of every LLM: turn logits into probabilities and pick one token."""
import math
import random


def softmax(logits: dict[str, float], temperature: float = 1.0) -> dict[str, float]:
    """Turn raw scores into probabilities. Lower temperature = sharper."""
    if temperature <= 0:
        raise ValueError("temperature must be > 0 (use greedy() for temperature 0)")
    biggest = max(logits.values())
    exps = {tok: math.exp(s - biggest) / temperature for tok, s in logits.items()}
    total = sum(exps.values())
    return {tok: e / total for tok, e in exps.items()}


def greedy(logits: dict[str, float]) -> str:
    return max(logits, key=logits.get)


def top_p_filter(probs: dict[str, float], p: float) -> dict[str, float]:
    """Keep the most likely tokens until their total reaches p, then renormalize."""
    if p >= 1.0:
        return dict(probs)
    kept, running = {}, 0.0
    for tok, prob in sorted(probs.items(), key=lambda kv: kv[1], reverse=True):
        if running + prob > p:
            break
        kept[tok] = prob
        running += prob
    total = sum(kept.values())
    return {tok: prob / total for tok, prob in kept.items()}


def sample(logits: dict[str, float], temperature: float = 1.0, top_p: float = 1.0,
           rng: random.Random | None = None) -> str:
    if temperature == 0:
        return greedy(logits)
    rng = rng or random.Random()
    probs = top_p_filter(softmax(logits, temperature), top_p)
    return rng.choices(list(probs), weights=list(probs.values()), k=1)[0]
