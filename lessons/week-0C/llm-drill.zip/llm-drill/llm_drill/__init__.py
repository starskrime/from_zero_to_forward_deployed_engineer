"""A small toolkit for comparing LLMs: sampling, pricing, provider adapters, similarity and checks."""
