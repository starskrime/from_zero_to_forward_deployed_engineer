"""One answer shape for three providers (the adapter pattern)."""
import time

import anthropic
import openai
from google import genai
from google.genai import types
from pydantic import BaseModel


class Answer(BaseModel):
    provider: str
    model: str
    text: str
    input_tokens: int
    output_tokens: int   # includes hidden reasoning tokens: they are billed as output
    latency_s: float


def ask_openai(client: openai.OpenAI, model: str, system: str, prompt: str, max_tokens: int = 300) -> Answer:
    start = time.perf_counter()
    r = client.responses.create(model=model, instructions=system, input=prompt,
                                max_output_tokens=max_tokens, reasoning={"effort": "none"})
    return Answer(provider="openai", model=model, text=r.output_text,
                  input_tokens=r.usage.input_tokens, output_tokens=r.usage.output_tokens,
                  latency_s=time.perf_counter() - start)


def ask_claude(client: anthropic.Anthropic, model: str, system: str, prompt: str, max_tokens: int = 300) -> Answer:
    start = time.perf_counter()
    msg = client.messages.create(model=model, system=system, max_tokens=max_tokens,
                                 messages=[{"role": "user", "content": prompt}])
    text = msg.content[0].text
    return Answer(provider="claude", model=model, text=text,
                  input_tokens=msg.usage.input_tokens, output_tokens=msg.usage.output_tokens,
                  latency_s=time.perf_counter() - start)


def ask_gemini(client: genai.Client, model: str, system: str, prompt: str, max_tokens: int = 300) -> Answer:
    start = time.perf_counter()
    r = client.models.generate_content(
        model=model, contents=prompt,
        config=types.GenerateContentConfig(system_instruction=system, max_output_tokens=max_tokens))
    u = r.usage_metadata
    return Answer(provider="gemini", model=model, text=r.text or "",
                  input_tokens=u.prompt_token_count or 0,
                  output_tokens=(u.candidates_token_count or 0) + (u.thoughts_token_count or 0),
                  latency_s=time.perf_counter() - start)
