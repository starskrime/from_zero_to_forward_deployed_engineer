"""Cosine similarity by hand, and a top-k search over stored vectors."""


def cosine(a: list[float], b: list[float]) -> float:
    if len(a) != len(b):
        raise ValueError(f"vectors have different lengths: {len(a)} vs {len(b)}")
    return sum(x * y for x, y in zip(a, b))


def top_k(query: list[float], docs: dict[str, list[float]], k: int = 3) -> list[tuple[float, str]]:
    scored = sorted(((cosine(query, v), name) for name, v in docs.items()), reverse=True)
    return scored[:k]
