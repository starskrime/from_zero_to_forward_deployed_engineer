"""Token counts to dollars. Prices are USD per 1M tokens, checked 2026-09-23."""
PRICES_CHECKED_ON = "2026-09-23"

PRICES = {  # model: (input, output, cached_input)
    "gpt-6-luna":            (0.10, 0.50, 0.01),
    "gemini-3.5-flash-lite": (0.30, 2.50, 0.03),
    "claude-haiku-4-5":      (1.00, 5.00, 0.10),
    "claude-sonnet-5":       (2.00, 10.00, 0.20),
    "claude-opus-5-5":       (4.00, 20.00, 0.20),
}


def cost_usd(model: str, input_tokens: int, output_tokens: int, cached_tokens: int = 0) -> float:
    """Cost of one call. cached_tokens is the part of input_tokens read from the prompt cache.

    output_tokens must already include any hidden reasoning ("thinking") tokens.
    """
    price_in, price_out, price_cached = PRICES[model]
    fresh = input_tokens
    return (fresh * price_in + cached_tokens * price_cached + output_tokens * price_out) / 1_000_000


def monthly(model: str, requests: int, input_tokens: int, output_tokens: int, cached_tokens: int = 0) -> float:
    return requests * cost_usd(model, input_tokens, output_tokens, cached_tokens)


def cost_per_1k(total_cost: float, runs: int) -> float:
    """Cost per 1,000 runs, from a bench total. runs = every result, repeats included."""
    return total_cost / runs * 1000
