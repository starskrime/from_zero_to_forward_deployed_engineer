"""Check model output in code: numbers and JSON replies."""
import json
import re

NUMBER = re.compile(r"-?\d+(?:\.\d+)?")


def extract_number(text: str) -> float | None:
    """The first number in the text, handling a minus sign, commas and decimals."""
    match = NUMBER.search(text)
    return float(match.group().replace(",", "")) if match else None


def strip_fences(text: str) -> str:
    return re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip())


def parse_json_reply(text: str) -> dict | None:
    try:
        data = json.loads(strip_fences(text))
    except json.JSONDecodeError:
        return None
    return data if isinstance(data, dict) else None
