"""Rough latency model: time to first token, then a steady output speed."""


def total_latency(ttft_s: float, output_tokens: int, tokens_per_s: float) -> float:
    return ttft_s + output_tokens / tokens_per_s


def max_tokens_for_budget(budget_s: float, ttft_s: float, tokens_per_s: float) -> int:
    """The longest answer that still finishes within budget_s."""
    return max(0, int((budget_s - ttft_s) * tokens_per_s))
