# Break it & fix it: Week 0C

This small toolkit for comparing LLMs looks fine and runs without errors. It has
six bugs, each one a mistake that shows up in real code that samples tokens,
prices calls, parses provider responses, compares embeddings or checks answers.

    pip install openai anthropic google-genai pydantic httpx pytest
    python -m pytest -q

Six tests fail. Fix the code in `llm_drill/`, never the tests. For each bug,
write one line in `BUGS.md`: what was wrong, what a user would have seen in
production, and how you fixed it.

Everything runs offline: the provider tests send real SDK clients to
`httpx.MockTransport` (and `httpx2.MockTransport` for Claude) with hand-written
responses, so there is no API key and no API cost.
