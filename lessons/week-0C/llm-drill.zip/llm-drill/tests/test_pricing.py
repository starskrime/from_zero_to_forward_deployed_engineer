import pytest

from llm_drill.pricing import cost_per_1k, cost_usd, monthly


@pytest.mark.parametrize("model, expected", [
    ("gpt-6-luna", 5.50),
    ("gemini-3.5-flash-lite", 21.50),
    ("claude-haiku-4-5", 55.00),
    ("claude-sonnet-5", 110.00),
    ("claude-opus-5-5", 220.00),
])
def test_monthly_triage_cost_matches_the_lesson_table(model, expected):
    assert monthly(model, 20_000, 1_500, 250) == pytest.approx(expected)


def test_cached_prefix_is_billed_at_the_cached_price():
    # 1,200 of the 1,500 input tokens are a shared system prompt read from the cache
    # (Sonnet 5 caches prefixes of 1,024+ tokens; Haiku 4.5 needs 4,096+, so it wouldn't cache this one)
    assert monthly("claude-sonnet-5", 20_000, 1_500, 250, cached_tokens=1_200) == pytest.approx(66.80)


def test_reasoning_tokens_are_billed_as_output():
    # usage.output_tokens already includes the 600 reasoning tokens
    assert cost_usd("gpt-6-luna", 1_000, 800) == pytest.approx(0.0005)


def test_cost_per_1k_counts_every_result():
    # one provider, 8 prompts x --repeat 3 = 24 results costing $0.03 in total
    assert cost_per_1k(0.03, 24) == pytest.approx(1.25)
