from llm_drill.checks import extract_number, parse_json_reply


def test_number_with_thousands_separator_and_cents():
    assert extract_number("The payment is $1,798.65 per month.") == 1798.65


def test_negative_number():
    assert extract_number("about -3 degrees") == -3.0


def test_decimal_without_separator():
    assert extract_number("The rate is 6.5% fixed.") == 6.5


def test_no_number():
    assert extract_number("no numbers") is None


def test_json_in_fences_is_parsed():
    assert parse_json_reply('```json\n{"a": 1}\n```') == {"a": 1}


def test_json_with_chatter_or_not_an_object_is_rejected():
    assert parse_json_reply('Sure! {"a": 1}') is None
    assert parse_json_reply("[1, 2]") is None
