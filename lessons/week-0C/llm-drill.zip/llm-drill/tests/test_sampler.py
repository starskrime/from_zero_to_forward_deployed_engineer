import random
from collections import Counter

import pytest

from llm_drill.sampler import greedy, sample, softmax, top_p_filter

LOGITS = {" Paris": 6.0, " Lyon": 4.0, " the": 3.5, " a": 3.0, " London": 1.0}


@pytest.mark.parametrize("t", [0.5, 1.0, 2.0])
def test_probabilities_sum_to_one(t):
    assert sum(softmax(LOGITS, t).values()) == pytest.approx(1.0)


def test_temperature_matches_the_lesson_table():
    assert softmax(LOGITS, 1.0)[" Paris"] == pytest.approx(0.785, abs=5e-4)
    assert softmax(LOGITS, 0.5)[" Paris"] == pytest.approx(0.973, abs=5e-4)
    assert softmax(LOGITS, 2.0)[" Paris"] == pytest.approx(0.510, abs=5e-4)


def test_temperature_zero_or_below_is_rejected():
    with pytest.raises(ValueError):
        softmax(LOGITS, 0)


def test_greedy_and_temperature_zero_pick_paris():
    assert greedy(LOGITS) == " Paris"
    assert sample(LOGITS, temperature=0) == " Paris"


def test_top_p_keeps_the_smallest_set_that_reaches_p():
    kept = top_p_filter(softmax(LOGITS, 1.0), 0.9)
    assert list(kept) == [" Paris", " Lyon", " the"]
    assert kept[" Paris"] == pytest.approx(0.821, abs=5e-4)


def test_top_p_one_keeps_everything():
    assert len(top_p_filter(softmax(LOGITS, 1.0), 1.0)) == 5


def test_seeded_sampling_matches_the_distribution():
    rng = random.Random(7)
    counts = Counter(sample(LOGITS, 1.0, rng=rng) for _ in range(10_000))
    assert 7_600 < counts[" Paris"] < 8_100
    assert 900 < counts[" Lyon"] < 1_250
