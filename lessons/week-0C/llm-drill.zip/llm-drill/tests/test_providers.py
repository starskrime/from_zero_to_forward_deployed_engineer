"""Each adapter parses a real-looking response through the real SDK, with no network.

OpenAI and Gemini use httpx; the Claude SDK is built on httpx2, so it gets an httpx2 mock.
"""
import anthropic
import httpx
import httpx2
import openai
from google import genai
from google.genai import types

from llm_drill.providers import ask_claude, ask_gemini, ask_openai


def openai_client(body: dict) -> openai.OpenAI:
    handler = lambda request: httpx.Response(200, json=body)
    return openai.OpenAI(api_key="test", http_client=httpx.Client(transport=httpx.MockTransport(handler)))


def claude_client(body: dict) -> anthropic.Anthropic:
    handler = lambda request: httpx2.Response(200, json=body)
    return anthropic.Anthropic(api_key="test", http_client=httpx2.Client(transport=httpx2.MockTransport(handler)))


def gemini_client(body: dict) -> genai.Client:
    handler = lambda request: httpx.Response(200, json=body)
    return genai.Client(api_key="test", http_options=types.HttpOptions(
        httpx_client=httpx.Client(transport=httpx.MockTransport(handler))))


def claude_body(content: list[dict], output_tokens: int) -> dict:
    return {"id": "msg_1", "type": "message", "role": "assistant", "model": "claude-haiku-4-5",
            "content": content, "stop_reason": "end_turn", "stop_sequence": None,
            "usage": {"input_tokens": 19, "output_tokens": output_tokens}}


def test_openai_output_tokens_include_reasoning():
    body = {"id": "resp_1", "object": "response", "created_at": 0, "model": "gpt-6-luna", "status": "completed",
            "output": [{"type": "message", "id": "m1", "status": "completed", "role": "assistant",
                        "content": [{"type": "output_text", "text": "billing", "annotations": []}]}],
            "usage": {"input_tokens": 40, "output_tokens": 130, "total_tokens": 170,
                      "input_tokens_details": {"cached_tokens": 0},
                      "output_tokens_details": {"reasoning_tokens": 128}},
            "parallel_tool_calls": True, "tool_choice": "auto", "tools": []}
    a = ask_openai(openai_client(body), "gpt-6-luna", "sys", "Classify this ticket.")
    assert (a.text, a.input_tokens, a.output_tokens) == ("billing", 40, 130)


def test_claude_single_text_block():
    body = claude_body([{"type": "text", "text": "billing"}], 3)
    a = ask_claude(claude_client(body), "claude-haiku-4-5", "sys", "Classify this ticket.")
    assert (a.text, a.input_tokens, a.output_tokens) == ("billing", 19, 3)


def test_claude_text_after_a_thinking_block():
    body = claude_body([{"type": "thinking", "thinking": "The ticket mentions a refund...", "signature": "sig"},
                        {"type": "text", "text": "billing"}], 60)
    a = ask_claude(claude_client(body), "claude-haiku-4-5", "sys", "Classify this ticket.")
    assert a.text == "billing"
    assert a.output_tokens == 60


def test_gemini_counts_thinking_tokens_as_output():
    body = {"candidates": [{"content": {"role": "model", "parts": [{"text": "billing"}]}, "finishReason": "STOP"}],
            "usageMetadata": {"promptTokenCount": 38, "candidatesTokenCount": 2, "thoughtsTokenCount": 90,
                              "totalTokenCount": 130}}
    a = ask_gemini(gemini_client(body), "gemini-3.5-flash-lite", "sys", "Classify this ticket.")
    assert (a.text, a.input_tokens, a.output_tokens) == ("billing", 38, 92)


def test_gemini_with_no_text_returns_empty_string():
    # thinking used the whole output budget: no text parts, r.text is None
    body = {"candidates": [{"content": {"role": "model"}, "finishReason": "MAX_TOKENS"}],
            "usageMetadata": {"promptTokenCount": 38, "thoughtsTokenCount": 300, "totalTokenCount": 338}}
    a = ask_gemini(gemini_client(body), "gemini-3.5-flash-lite", "sys", "Classify this ticket.", max_tokens=300)
    assert (a.text, a.output_tokens) == ("", 300)
