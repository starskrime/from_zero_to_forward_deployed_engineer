import math

import pytest

from llm_drill.similarity import cosine, top_k


def test_cosine_known_values():
    assert cosine([1, 2, 3], [2, 4, 6]) == pytest.approx(1.0)
    assert cosine([1, 2, 3], [-1, -2, -3]) == pytest.approx(-1.0)
    assert cosine([1, 2, 3], [3, -1, 0]) == pytest.approx(0.0845, abs=1e-4)


def test_vectors_of_different_lengths_are_rejected():
    with pytest.raises(ValueError):
        cosine([1.0, 0.0, 0.0], [1.0, 0.0])


def test_top_k_is_sorted_and_limited():
    s = 1 / math.sqrt(2)
    docs = {"reset password": [1.0, 0.0], "charged twice": [0.0, 1.0], "sso": [s, s]}
    result = top_k([1.0, 0.0], docs, k=2)
    assert [name for _, name in result] == ["reset password", "sso"]
