import pytest

from llm_drill.latency import max_tokens_for_budget, total_latency


def test_total_latency_is_ttft_plus_generation_time():
    assert total_latency(0.6, 400, 80) == pytest.approx(5.6)


def test_answer_length_that_fits_a_two_second_budget():
    assert max_tokens_for_budget(2.0, 0.6, 80) == 112
    assert max_tokens_for_budget(0.5, 0.6, 80) == 0
