"""Writes data/halden.json, the fictional Halden Auto Parts catalog. Every make, model and part is invented."""
import json
from pathlib import Path

VEHICLES = [
    ("arlo-vela-2019", "Arlo", "Vela", 2019, "1.6L I4"),
    ("arlo-vela-2021", "Arlo", "Vela", 2021, "1.6L I4 turbo"),
    ("brenmark-tundris-2018", "Brenmark", "Tundris", 2018, "3.5L V6"),
    ("calloway-mistral-2020", "Calloway", "Mistral", 2020, "2.0L I4 hybrid"),
    ("dunholt-pira-2017", "Dunholt", "Pira", 2017, "1.2L I3"),
    ("esker-voss-2022", "Esker", "Voss", 2022, "2.5L I4"),
]
A19, A21, BT, CM, DP, EV = (v[0] for v in VEHICLES)

# part_number, name, category, attributes, price, stock, fits, extra
PARTS = [
    ("HB-4417-K", "Ceramic brake pads, front axle set", "brake_pads", {"position": "front", "compound": "ceramic"}, 54.99, 12, [A19, A21]),
    ("HB-4418-K", "Ceramic brake pads, rear axle set", "brake_pads", {"position": "rear", "compound": "ceramic"}, 44.99, 8, [A19, A21]),
    ("HB-4471-K", "Semi-metallic brake pads, front axle set", "brake_pads", {"position": "front", "compound": "semi-metallic"}, 69.99, 6, [BT]),
    ("HB-4472-K", "Semi-metallic brake pads, rear axle set", "brake_pads", {"position": "rear", "compound": "semi-metallic"}, 59.99, 5, [BT]),
    ("HB-5120-M", "Low-dust brake pads, front axle set", "brake_pads", {"position": "front", "compound": "ceramic"}, 49.99, 9, [CM]),
    ("HB-5121-M", "Low-dust brake pads, rear axle set", "brake_pads", {"position": "rear", "compound": "ceramic"}, 39.99, 7, [CM]),
    ("HB-6030-P", "Performance brake pads, front axle set", "brake_pads", {"position": "front", "compound": "ceramic"}, 64.99, 3, [EV]),
    ("HR-3880-F", "Vented brake rotor, front, 280 mm", "brake_rotor", {"position": "front", "diameter_mm": 280}, 79.99, 10, [A19, A21]),
    ("HR-38B0-F", "Vented brake rotor, front, 330 mm", "brake_rotor", {"position": "front", "diameter_mm": 330}, 119.99, 4, [BT]),
    ("HR-3881-R", "Solid brake rotor, rear, 260 mm", "brake_rotor", {"position": "rear", "diameter_mm": 260}, 69.99, 6, [A19, A21]),
    ("HR-5200-F", "Vented brake rotor, front, 296 mm", "brake_rotor", {"position": "front", "diameter_mm": 296}, 89.99, 5, [CM]),
    ("HF-2010-A", "Spin-on oil filter, M20x1.5", "oil_filter", {"thread": "M20x1.5", "type": "spin-on"}, 8.99, 40, [A19, A21]),
    ("HF-2O10-A", "Spin-on oil filter, heavy duty, 3/4-16", "oil_filter", {"thread": "3/4-16", "type": "spin-on"}, 11.49, 25, [BT]),
    ("HF-2011-A", "Spin-on oil filter, compact, M18x1.5", "oil_filter", {"thread": "M18x1.5", "type": "spin-on"}, 7.99, 30, [DP]),
    ("HF-3300-C", "Cartridge oil filter element", "oil_filter", {"type": "cartridge"}, 12.99, 22, [CM, EV]),
    ("HA-5310-T", "Engine air filter, panel", "air_filter", {"shape": "panel"}, 18.99, 14, [A19]),
    ("HA-S310-T", "Engine air filter, panel, high flow", "air_filter", {"shape": "panel"}, 21.99, 9, [EV]),
    ("HA-5311-T", "Engine air filter, panel, turbo", "air_filter", {"shape": "panel"}, 22.99, 11, [A21]),
    ("HA-7400-T", "Engine air filter, round", "air_filter", {"shape": "round"}, 24.99, 6, [BT]),
    ("HC-1200-G", "Cabin air filter, activated carbon", "cabin_filter", {"media": "carbon"}, 16.99, 20, [A19, A21]),
    ("HC-1210-G", "Cabin air filter, particulate", "cabin_filter", {"media": "particulate"}, 17.99, 18, [CM, EV]),
    ("HC-1220-G", "Cabin air filter, particulate", "cabin_filter", {"media": "particulate"}, 15.99, 15, [DP, BT]),
    ("HS-7114-C", "Iridium spark plug, gap 0.8 mm", "spark_plug", {"gap_mm": 0.8, "tip": "iridium"}, 9.49, 60, [A19]),
    ("HS-71I4-C", "Iridium spark plug, gap 0.7 mm, turbo", "spark_plug", {"gap_mm": 0.7, "tip": "iridium"}, 10.49, 48, [A21]),
    ("HS-7120-C", "Platinum spark plug, gap 0.9 mm", "spark_plug", {"gap_mm": 0.9, "tip": "platinum"}, 7.99, 36, [DP]),
    ("HS-7300-D", "Iridium spark plug, gap 1.1 mm", "spark_plug", {"gap_mm": 1.1, "tip": "iridium"}, 12.99, 30, [BT, CM, EV]),
    ("HW-5822-L", "Wiper blade, 22 in (560 mm), driver side", "wiper_blade", {"position": "driver", "length_in": 22}, 14.99, 30, [A19, A21, CM]),
    ("HW-5B22-L", "Beam wiper blade, 22 in (560 mm), driver side", "wiper_blade", {"position": "driver", "length_in": 22}, 17.99, 24, [BT, EV]),
    ("HW-5818-L", "Wiper blade, 18 in (455 mm), passenger side", "wiper_blade", {"position": "passenger", "length_in": 18}, 12.99, 26, [A19, A21]),
    ("HW-5810-R", "Rear wiper blade, 10 in (255 mm)", "wiper_blade", {"position": "rear", "length_in": 10}, 9.99, 16, [DP, EV]),
    ("HT-6150-K", "Serpentine belt, 6 rib, 1500 mm", "serpentine_belt", {"ribs": 6, "length_mm": 1500}, 29.99, 9, [A19]),
    ("HT-6151-K", "Serpentine belt, 6 rib, 1510 mm", "serpentine_belt", {"ribs": 6, "length_mm": 1510}, 31.99, 7, [A21]),
    ("HT-7200-K", "Serpentine belt, 7 rib, 2200 mm", "serpentine_belt", {"ribs": 7, "length_mm": 2200}, 44.99, 5, [BT]),
    ("HL-1100-H", "Headlight bulb, type HX1", "bulb", {"bulb_type": "HX1", "use": "headlight"}, 11.99, 50, [A19, A21, DP]),
    ("HL-1101-H", "Headlight bulb, type HX2", "bulb", {"bulb_type": "HX2", "use": "headlight"}, 13.99, 40, [CM, EV]),
    ("HL-3100-B", "Brake and tail light bulb, type T3", "bulb", {"bulb_type": "T3", "use": "brake/tail"}, 3.99, 200, [A19, A21, BT, CM, DP, EV]),
    ("HV-6600-B", "Battery, case H6, 640 CCA", "battery", {"case": "H6", "cca": 640}, 169.99, 0, [A19, A21, CM]),
    ("HV-6610-B", "Battery, case H6, 680 CCA", "battery", {"case": "H6", "cca": 680}, 179.99, 6, [A19, A21, CM]),
    ("HV-6800-B", "Battery, case H8, 850 CCA", "battery", {"case": "H8", "cca": 850}, 219.99, 4, [BT]),
    ("HV-6500-B", "Battery, case H5, 540 CCA", "battery", {"case": "H5", "cca": 540}, 149.99, 5, [DP, EV]),
]
DISCONTINUED = {"HV-6600-B": "HV-6610-B"}


def build() -> dict:
    parts = []
    for pn, name, cat, attrs, price, stock, fits in PARTS:
        p = {"part_number": pn, "name": name, "category": cat, "attributes": attrs, "price": price,
             "stock": stock, "fits": fits, "image": f"catalog/{pn}.png", "status": "active"}
        if pn in DISCONTINUED:
            p["status"], p["superseded_by"] = "discontinued", DISCONTINUED[pn]
        parts.append(p)
    return {
        "store": "Halden Auto Parts (fictional)",
        "part_number_format": "LL-XXXX-X: two-letter line code, four characters (mostly digits), one suffix character",
        "line_codes": {"HB": "brake_pads", "HR": "brake_rotor", "HF": "oil_filter", "HA": "air_filter",
                       "HC": "cabin_filter", "HS": "spark_plug", "HW": "wiper_blade", "HT": "serpentine_belt",
                       "HL": "bulb", "HV": "battery"},
        "vehicles": [{"id": i, "make": mk, "model": md, "year": y, "engine": e} for i, mk, md, y, e in VEHICLES],
        "parts": parts,
    }


if __name__ == "__main__":
    out = Path(__file__).resolve().parent.parent / "halden.json"
    out.write_text(json.dumps(build(), indent=1) + "\n")
    print(f"wrote {out}")
