"""Writes data/embeddings.json: SYNTHETIC 32-dim stand-ins for image embeddings.

These are not computed from the pixels. They are built so nearest-neighbour search behaves like a real
image encoder would on these photos: parts of one category sit together, parts that look physically
identical (front/rear pads of one car, a battery and its successor, two same-shape filters) are near
ties, and each degraded photo sits near the part it shows, further away the worse the photo is.
The lesson shows how to compute real SigLIP 2 embeddings instead (optional, needs torch)."""
import json
from pathlib import Path

import numpy as np

from make_images import PHOTOS

DATA = Path(__file__).resolve().parent.parent
DIM = 32
TWINS = {"HB-4418-K": "HB-4417-K", "HB-4472-K": "HB-4471-K", "HB-5121-M": "HB-5120-M",
         "HF-2O10-A": "HF-2010-A", "HT-6151-K": "HT-6150-K", "HV-6610-B": "HV-6600-B",
         "HS-71I4-C": "HS-7114-C"}
NOISE = {"clear": 0.15, "rotate15": 0.2, "rotate90": 0.25, "tiny": 0.35, "crop": 0.3, "glare": 0.3,
         "dim": 0.3, "blur": 0.4, "dark": 0.45, "no_number": 0.3, "injection": 0.2, "two_parts": 0.2}


def unit(v: np.ndarray) -> np.ndarray:
    return v / np.linalg.norm(v)


def main() -> None:
    rng = np.random.default_rng(2026)
    catalog = json.loads((DATA / "halden.json").read_text())
    bases = {c: unit(rng.normal(size=DIM)) for c in sorted({p["category"] for p in catalog["parts"]})}
    vecs: dict[str, np.ndarray] = {}
    for p in catalog["parts"]:                       # originals first, so twins can copy them
        if p["part_number"] not in TWINS:
            vecs[p["part_number"]] = unit(bases[p["category"]] + 0.45 * unit(rng.normal(size=DIM)))
    for pn, twin in TWINS.items():
        vecs[pn] = unit(vecs[twin] + 0.04 * unit(rng.normal(size=DIM)))
    photos = {}
    for name, pns, cond, *_ in PHOTOS:
        if not pns:                                  # something Halden doesn't sell: its own direction
            photos[f"photos/{name}.png"] = unit(rng.normal(size=DIM))
            continue
        base = unit(sum(vecs[pn] for pn in pns))
        photos[f"photos/{name}.png"] = unit(base + NOISE[cond] * unit(rng.normal(size=DIM)))
    rounded = lambda d: {k: [round(float(x), 4) for x in v] for k, v in d.items()}  # noqa: E731
    out = {"note": "SYNTHETIC stand-in vectors, not computed from pixels. See README.txt.", "dim": DIM,
           "catalog": rounded({pn: vecs[pn] for pn in sorted(vecs)}), "photos": rounded(photos)}
    (DATA / "embeddings.json").write_text(json.dumps(out) + "\n")
    print(f"wrote {len(vecs)} catalog and {len(photos)} photo vectors")


if __name__ == "__main__":
    main()
