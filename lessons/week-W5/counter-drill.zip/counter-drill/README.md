# Break it & fix it: Week 5

This trimmed-down Halden Auto Parts counter assistant (part-number lookup, read-back and quantity
rules, barge-in handling, structured extraction with retries, photo preparation and matching, and a
LangGraph checkout that waits for a person on risky orders) looks fine and runs without errors. It has
six bugs, each one a mistake that shows up in real voice and vision agents.

    pip install langgraph pydantic pillow numpy pytest
    python -m pytest -q

Six tests fail. Fix the code in `counter_drill/`, never the tests. For each bug, write one line in
`BUGS.md`: what was wrong, what a customer (or the store) would have seen in production, and how you
fixed it.

Everything runs offline: the model replies are scripted and routed by content, the embeddings are
synthetic stand-in vectors, and the order system is a fake that records every order placed, so there is
no API cost. Halden Auto Parts, its vehicles and every part number are fictional.
