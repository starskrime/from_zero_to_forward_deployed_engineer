"""Day 4: the checkout graph. Low-risk orders go straight through; risky ones wait for a person.

LangGraph has no built-in interrupt timeout, so the deadline lives in state and in the approval card,
and sweep_expired() resumes stale threads with a "timeout" decision."""
import time
from collections.abc import Callable
from typing import TypedDict

from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, interrupt

from counter_drill.catalog import Catalog
from counter_drill.identify import CONFIDENT_MARGIN
from counter_drill.schema import Order, OrderLine, order_errors
from counter_drill.speech import check_quantity, read_back

RISK_TOTAL = 150.00             # design choice: above this, a person approves
APPROVAL_TTL_SECS = 15 * 60     # design choice: a pending approval expires after 15 minutes
DECISIONS = ("approve", "edit", "reject")
CLOSED = {"reject": "rejected", "timeout": "escalate_to_human"}


class CheckoutState(TypedDict, total=False):
    order: dict
    picks: list[dict]
    risk: list[str]
    deadline: float
    decision: str
    outcome: str
    order_id: str
    audit: list[dict]


def risk_reasons(order: Order, picks: list[dict]) -> list[str]:
    reasons = []
    if order.calculated_total > RISK_TOTAL:
        reasons.append(f"total ${order.calculated_total:.2f} is over ${RISK_TOTAL:.0f}")
    if order.conflict_detected:
        reasons.append(f"customer was told ${order.stated_total:.2f}; catalog total is ${order.calculated_total:.2f}")
    for line in order.lines:
        if check_quantity(line.quantity).status == "confirm":
            reasons.append(f"{line.quantity} x {line.part_number}: {check_quantity(line.quantity).message}")
    for pick in picks:
        if pick.get("replaced"):
            reasons.append(f"{pick['part_number']} replaces discontinued {pick['replaced']}")
        if pick.get("method") == "image" and (pick.get("margin") or 0) < CONFIDENT_MARGIN:
            reasons.append(f"{pick['part_number']} was matched from a photo with a low margin ({pick['margin']})")
        reasons += pick.get("flags", [])
    return reasons


def approval_card(state: CheckoutState, catalog: Catalog) -> dict:
    """What the approver must see: the exact lines and consequence, why this needs a person, and when
    the request expires. Pure: it runs again when the node resumes."""
    order = Order(**state["order"])
    return {
        "kind": "checkout_approval",
        "vehicle_id": order.vehicle_id,
        "lines": [{"part_number": l.part_number, "name": catalog.get(l.part_number)["name"], "quantity": l.quantity,
                   "unit_price": l.unit_price, "line_total": round(l.quantity * l.unit_price, 2)} for l in order.lines],
        "total": order.calculated_total,
        "consequence": f"places order for ${order.calculated_total:.2f}",
        "read_back": [f"{l.quantity} of {read_back(l.part_number)}" for l in order.lines],
        "risk_reasons": state["risk"],
        "deadline": state["deadline"],
        "allowed_decisions": list(DECISIONS),
    }


def build_checkout(catalog: Catalog, orders, clock: Callable[[], float] = time.time, checkpointer=None):
    """`orders` has place(order: dict) -> order id."""

    def assess(state: CheckoutState):
        reasons = risk_reasons(Order(**state["order"]), state.get("picks", []))
        return {"risk": reasons, "deadline": clock() + APPROVAL_TTL_SECS if reasons else 0.0, "audit": []}

    def approve(state: CheckoutState):
        card = approval_card(state, catalog)
        answer = interrupt(card)
        answer = answer if isinstance(answer, dict) else {}
        decision = answer.get("decision")
        entry = {"approver": answer.get("approver", "unknown"), "decision": decision, "at": clock(), "shown": card}
        update = {"audit": state.get("audit", []) + [entry]}
        if decision in ("approve", "timeout"):
            return update | {"decision": "approve"}
        if decision == "edit":
            lines = [OrderLine(part_number=l["part_number"], quantity=l["quantity"],
                               unit_price=(catalog.get(l["part_number"]) or {}).get("price", 0.0))
                     for l in answer.get("lines", [])]
            order = Order(vehicle_id=state["order"]["vehicle_id"], lines=lines,
                          stated_total=state["order"].get("stated_total"))
            if errors := order_errors(order, catalog):
                entry["errors"] = errors
                return update | {"decision": "reject", "outcome": "rejected"}
            return update | {"decision": "approve", "order": order.model_dump()}
        return update | {"decision": "reject", "outcome": CLOSED.get(decision, "rejected")}

    def place(state: CheckoutState):
        return {"order_id": orders.place(state["order"]), "outcome": "placed"}

    g = StateGraph(CheckoutState)
    g.add_node("assess", assess)
    g.add_node("approve", approve)
    g.add_node("place", place)
    g.add_edge(START, "assess")
    g.add_conditional_edges("assess", lambda s: "approve" if s["risk"] else "place", ["approve", "place"])
    g.add_conditional_edges("approve", lambda s: "place" if s["decision"] == "approve" else END, ["place", END])
    g.add_edge("place", END)
    return g.compile(checkpointer=checkpointer)


def sweep_expired(graph, thread_ids: list[str], now: float) -> list[str]:
    """Run every minute or so by a scheduler. Resumes expired approvals with a timeout decision."""
    expired = []
    for tid in thread_ids:
        config = {"configurable": {"thread_id": tid}}
        pending = [i for i in graph.get_state(config).interrupts if i.value.get("kind") == "checkout_approval"]
        if pending and pending[0].value["deadline"] < now:
            graph.invoke(Command(resume={"decision": "timeout", "approver": "system:expiry-sweep"}), config)
            expired.append(tid)
    return expired
