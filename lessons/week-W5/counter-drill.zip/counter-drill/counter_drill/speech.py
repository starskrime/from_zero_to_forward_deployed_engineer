"""Day 1: what we say back, and how many of one part a counter will sell."""
from dataclasses import dataclass

from counter_drill.catalog import normalize_part_number

# NATO words in "B as in Bravo" form: bare letter names collide on a phone line (B/D/P/E/V, M/N, F/S).
# Digits are always "zero", never "oh", because O is a letter in some Halden part numbers.
NATO = {"A": "Alpha", "B": "Bravo", "C": "Charlie", "D": "Delta", "E": "Echo", "F": "Foxtrot", "G": "Golf",
        "H": "Hotel", "I": "India", "J": "Juliet", "K": "Kilo", "L": "Lima", "M": "Mike", "N": "November",
        "O": "Oscar", "P": "Papa", "Q": "Quebec", "R": "Romeo", "S": "Sierra", "T": "Tango", "U": "Uniform",
        "V": "Victor", "W": "Whiskey", "X": "X-ray", "Y": "Yankee", "Z": "Zulu"}
DIGIT_WORDS = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"]


def read_back(part_number: str) -> str:
    """'HB-4417-K' -> 'H as in Hotel, B as in Bravo. dash. four, four, one, seven. dash. K as in Kilo.'"""
    c = normalize_part_number(part_number)
    groups = [c[:2], c[2:6], c[6:]] if len(c) == 7 else [c]

    def say(ch: str) -> str:
        return DIGIT_WORDS[int(ch)] if ch.isdigit() else f"{ch} as in {NATO[ch]}"
    return " dash. ".join(", ".join(say(ch) for ch in g) + "." for g in groups if g)


MIN_QTY, CONFIRM_ABOVE, MAX_QTY = 1, 4, 20  # design choice: a counter sells up to a box of 20 of one item


@dataclass
class QuantityCheck:
    status: str          # "ok" | "confirm" | "refuse"
    message: str = ""


def check_quantity(n: int) -> QuantityCheck:
    if n < MIN_QTY or n > MAX_QTY:
        return QuantityCheck("refuse", f"quantity {n} is outside {MIN_QTY}-{MAX_QTY}; a person must handle it")
    if n > CONFIRM_ABOVE:
        return QuantityCheck("confirm", f"quantity {n} is more than {CONFIRM_ABOVE}; confirm it with the customer")
    return QuantityCheck("ok")
