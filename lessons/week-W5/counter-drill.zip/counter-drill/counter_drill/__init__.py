"""Halden Auto Parts counter assistant, trimmed for the Week 5 drill.

The model proposes; deterministic code and a human decide."""
