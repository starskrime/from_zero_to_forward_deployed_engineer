"""Day 1 + 3: the shapes the model must fill, and the checks a schema cannot do.

A JSON schema removes syntax errors; it does not stop a well-formed lie. Nullable fields give the model a
legal way to say "not stated", and the semantic checks below catch the rest."""
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field, model_validator

from counter_drill.catalog import Catalog, fold, format_part_number, spoken_to_chars
from counter_drill.speech import check_quantity


class Category(str, Enum):
    brake_pads = "brake_pads"
    brake_rotor = "brake_rotor"
    oil_filter = "oil_filter"
    air_filter = "air_filter"
    cabin_filter = "cabin_filter"
    spark_plug = "spark_plug"
    wiper_blade = "wiper_blade"
    serpentine_belt = "serpentine_belt"
    bulb = "bulb"
    battery = "battery"
    other = "other"


class Position(str, Enum):
    front = "front"
    rear = "rear"
    driver = "driver"
    passenger = "passenger"
    not_applicable = "not_applicable"
    unclear = "unclear"


class PartQuery(BaseModel):
    """One thing the customer wants, as heard or seen. Every field may be null."""
    model_config = ConfigDict(extra="forbid")
    category: Category | None = None
    category_detail: str | None = None
    position: Position | None = None
    part_number_heard: str | None = Field(None, description="Exactly as spoken or printed; null if none. Never guess.")
    quantity_heard: str | None = Field(None, description="The customer's words for how many, e.g. 'a pair'.")

    @model_validator(mode="after")
    def other_needs_detail(self):
        if self.category == Category.other and not self.category_detail:
            raise ValueError("category is 'other', so category_detail must say what the part is")
        return self


class OrderDraft(BaseModel):
    """What the extractor returns for a phone or kiosk conversation."""
    model_config = ConfigDict(extra="forbid")
    vehicle_id: str | None = None
    items: list[PartQuery] = Field(default_factory=list)
    wants_human: bool = False
    stated_total: float | None = Field(None, description="A total or price the customer says they were quoted.")


class OrderLine(BaseModel):
    part_number: str
    quantity: int
    unit_price: float                    # always copied from the catalog, never from the model


class Order(BaseModel):
    vehicle_id: str
    lines: list[OrderLine]
    stated_total: float | None = None
    calculated_total: float = 0.0
    conflict_detected: bool = False

    @model_validator(mode="after")
    def compute_total(self):
        self.calculated_total = round(sum(line.quantity * line.unit_price for line in self.lines), 2)
        self.conflict_detected = (self.stated_total is not None
                                  and abs(self.stated_total - self.calculated_total) >= 0.01)
        return self


class Issue(BaseModel):
    message: str
    missing: bool = False   # True: the information is not in the source, so a retry cannot fix it


def grounded(heard: str, transcript: str) -> bool:
    """Did the customer actually say this part number?"""
    return fold(spoken_to_chars(heard)) in fold(spoken_to_chars(transcript))


def draft_issues(draft: OrderDraft, transcript: str, catalog: Catalog) -> list[Issue]:
    """Semantic checks on an extraction. Fixable issues go back to the model; missing ones go to the customer."""
    issues = []
    if draft.wants_human:
        return issues
    if draft.vehicle_id is None:
        issues.append(Issue(message="the vehicle is not stated in the transcript", missing=True))
    elif draft.vehicle_id not in catalog.vehicles:
        issues.append(Issue(message=f"vehicle_id '{draft.vehicle_id}' is not one of: {', '.join(catalog.vehicles)}"))
    if not draft.items:
        issues.append(Issue(message="the customer has not said what part they need", missing=True))
    for i, item in enumerate(draft.items):
        heard = item.part_number_heard
        if heard is None and item.category is None:
            issues.append(Issue(message=f"item {i}: nothing identifies the part (no number, no category)", missing=True))
        if heard is not None:
            key = spoken_to_chars(heard)
            if not grounded(heard, transcript):
                issues.append(Issue(message=f"item {i}: part number '{heard}' does not appear in the transcript; "
                                            "copy it exactly as the customer said it, or use null"))
            elif catalog.get(key) is None and not catalog.near(key):
                issues.append(Issue(message=f"item {i}: {format_part_number(key)} is not in the catalog; "
                                            "copy it exactly as the customer said it, or use null"))
    return issues


def order_errors(order: Order, catalog: Catalog) -> list[str]:
    """The last gate before anything is placed (also used to check a human's edits)."""
    errors = []
    if order.vehicle_id not in catalog.vehicles:
        errors.append(f"unknown vehicle {order.vehicle_id}")
    if not order.lines:
        errors.append("order has no lines")
    for line in order.lines:
        part = catalog.get(line.part_number)
        if part is None:
            errors.append(f"{line.part_number} is not in the catalog")
            continue
        if part["status"] != "active":
            errors.append(f"{line.part_number} is discontinued")
        if not catalog.fits(part, order.vehicle_id):
            errors.append(f"{line.part_number} does not fit {order.vehicle_id}")
        if check_quantity(line.quantity).status == "refuse":
            errors.append(f"{line.part_number}: {check_quantity(line.quantity).message}")
        if abs(line.unit_price - part["price"]) >= 0.01:
            errors.append(f"{line.part_number}: unit price {line.unit_price} is not the catalog price {part['price']}")
    return errors
