"""Days 1-3: turn what was heard or seen into exactly one catalog part, or a question.

Shared by the voice and the photo paths. Acceptance rules:
- an exact catalog number that fits the vehicle and agrees with what the customer said, or
- (photo) a nearest-neighbour top-1 with a clear margin that agrees with the model's attributes, or
- (voice) the customer's own description narrows the fitting parts to exactly one.
Everything else becomes up to three candidates for a clarifying question. Look-alike and one-edit
numbers are never auto-picked, and text seen in a photo is never obeyed."""
import re
from dataclasses import dataclass, field

import numpy as np

from counter_drill.catalog import Catalog, fold, format_part_number, spoken_to_chars
from counter_drill.schema import Category, PartQuery, Position
from counter_drill.vision import knn

# Design choices, tuned on the synthetic embeddings (re-tune on real SigLIP 2 vectors).
ACCEPT_MARGIN = 0.05       # top-1 must beat top-2 by this much cosine
CONFIDENT_MARGIN = 0.12    # below this, an accepted photo match is flagged for human review
MIN_SIMILARITY = 0.75      # below this, nothing in the catalog looks like the photo
INSTRUCTION_LIKE = re.compile(r"\b(ignore|instructions?|system|approve|override|disregard|assistant)\b", re.I)
SPECIFIC_POSITIONS = {Position.front, Position.rear, Position.driver, Position.passenger}


@dataclass
class Identification:
    status: str                                  # "match" | "ask" | "no_match"
    part: dict | None = None
    method: str = ""                             # "number" | "image" | "description"
    candidates: list[str] = field(default_factory=list)
    reason: str = ""
    margin: float | None = None
    replaced: str | None = None                  # discontinued number this part supersedes
    flags: list[str] = field(default_factory=list)


def number_keys(query: PartQuery, visible_text: list[str]) -> list[str]:
    raw = ([query.part_number_heard] if query.part_number_heard else []) + list(visible_text)
    keys = []
    for text in raw:
        key = spoken_to_chars(text)
        if len(key) >= 4 and any(c.isdigit() for c in key) and key not in keys:
            keys.append(key)
    return keys


def _disagrees(query: PartQuery, part: dict) -> str | None:
    if query.category not in (None, Category.other) and query.category.value != part["category"]:
        return f"{part['part_number']} is a {part['category']}, not a {query.category.value}"
    pos = part["attributes"].get("position")
    if query.position in SPECIFIC_POSITIONS and pos and query.position.value != pos:
        return f"{part['part_number']} is for the {pos}, not the {query.position.value}"
    return None


def _pns(parts: list[dict]) -> list[str]:
    return [p["part_number"] for p in parts][:3]


def identify(query: PartQuery, vehicle_id: str | None, catalog: Catalog, *, source: str = "voice",
             visible_text: list[str] = (), vector: np.ndarray | None = None,
             index: dict[str, np.ndarray] | None = None) -> Identification:
    flags = [f"ignored instruction-like text in photo: {t!r}" for t in visible_text if INSTRUCTION_LIKE.search(t)]
    cat = query.category.value if query.category not in (None, Category.other) else None
    pos = query.position.value if query.position in SPECIFIC_POSITIONS else None
    keys = number_keys(query, list(visible_text))

    exact = []
    for key in keys:
        if (p := catalog.get(key)) and p not in exact:
            exact.append(p)
    if len(exact) > 1:
        return Identification("ask", candidates=_pns(exact), flags=flags,
                              reason="more than one part number: " + ", ".join(_pns(exact)))
    if exact:
        part, replaced = catalog.current(exact[0])
        if not catalog.fits(part, vehicle_id):
            fitting = [p for p in catalog.near(exact[0]["part_number"]) if catalog.fits(p, vehicle_id)]
            fitting = fitting or catalog.for_vehicle(vehicle_id, part["category"], pos) \
                or catalog.for_vehicle(vehicle_id, part["category"])
            return Identification("ask", candidates=_pns(fitting), flags=flags,
                                  reason=f"{part['part_number']} does not fit {vehicle_id or 'an unknown vehicle'}")
        twins = [p for p in catalog.near(part["part_number"])
                 if fold(p["part_number"]) == fold(part["part_number"]) and catalog.fits(p, vehicle_id)]
        if twins:  # HF-2010-A vs HF-2O10-A both fitting: the printed or spoken form can't settle it
            return Identification("ask", candidates=_pns([part] + twins), flags=flags,
                                  reason=f"{part['part_number']} looks like {twins[0]['part_number']}")
        if why := _disagrees(query, part):
            return Identification("ask", candidates=_pns(catalog.for_vehicle(vehicle_id, part["category"])),
                                  reason=why, flags=flags)
        return Identification("match", part=part, method="number", replaced=replaced, flags=flags)

    near = []
    for key in keys:
        near += [p for p in catalog.near(key) if p not in near]
    if near:  # a look-alike or one-character slip: ask, never pick
        fitting = [p for p in near if catalog.fits(p, vehicle_id)] or near
        return Identification("ask", candidates=_pns(fitting), flags=flags,
                              reason=f"heard {format_part_number(keys[0])}; did you mean {' or '.join(_pns(fitting))}?")
    if any(len(k) == 7 for k in keys):
        return Identification("ask", candidates=_pns(catalog.for_vehicle(vehicle_id, cat, pos)), flags=flags,
                              reason=f"{format_part_number(keys[0])} is not a Halden part number")
    if vehicle_id is None:
        return Identification("ask", reason="which vehicle is it for? fitment decides the part", flags=flags)

    if vector is not None and index:
        ranked = knn(vector, index, [p["part_number"] for p in catalog.for_vehicle(vehicle_id)])
        if not ranked or ranked[0][1] < MIN_SIMILARITY:
            return Identification("no_match", reason="nothing that fits this vehicle looks like the photo", flags=flags)
        margin = ranked[0][1] - (ranked[1][1] if len(ranked) > 1 else 0.0)
        top = catalog.get(ranked[0][0])
        if margin >= ACCEPT_MARGIN:
            return Identification("match", part=top, method="image", margin=round(margin, 3), flags=flags)
        return Identification("ask", candidates=[pn for pn, _ in ranked], margin=round(margin, 3), flags=flags,
                              reason="the photo is a close call between " + " and ".join(pn for pn, _ in ranked[:2]))

    if source == "voice" and cat:
        pool = catalog.for_vehicle(vehicle_id, cat, pos)
        if len(pool) == 1:
            return Identification("match", part=pool[0], method="description")
        if pool:
            return Identification("ask", candidates=_pns(pool), reason="which one: " + ", ".join(
                f"{p['part_number']} ({p['name']})" for p in pool[:3]))
    return Identification("no_match", reason="no fitting part matches that description", flags=flags)

