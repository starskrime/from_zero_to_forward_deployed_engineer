"""Day 2: what happens when the customer talks over the bot."""
from dataclasses import dataclass, field

BACKCHANNELS = {"uh-huh", "uh huh", "mm", "mhm", "mm-hmm", "mmhmm", "yeah", "yep", "ok", "okay", "right",
                "sure", "got it"}
FALSE_INTERRUPTION_SECS = 2.0  # LiveKit's false_interruption_timeout example value


def is_backchannel(text: str) -> bool:
    return text.lower().strip(" .,!?") in BACKCHANNELS


@dataclass
class TurnManager:
    """Barge-in bookkeeping. While the bot speaks, user speech pauses playback. A real interruption
    cancels it and trims the assistant message to what was actually heard; a backchannel ("uh-huh")
    or silence within the window resumes it, because the customer was only listening."""
    history: list[dict] = field(default_factory=list)
    window_secs: float = FALSE_INTERRUPTION_SECS
    speaking: str | None = None      # full text of the reply being played
    spoken_chars: int = 0            # how much of it the TTS has actually played
    paused_at: float | None = None

    def bot_says(self, text: str) -> None:
        self.history.append({"role": "assistant", "content": text})
        self.speaking, self.spoken_chars, self.paused_at = text, 0, None

    def bot_progress(self, chars: int) -> None:
        self.spoken_chars = chars

    def bot_done(self) -> None:
        self.speaking = None

    def user_speech_started(self, now: float) -> str:
        if self.speaking is None:
            return "listen"
        self.paused_at = now
        return "pause_tts"

    def user_said(self, text: str, now: float) -> str:
        if self.speaking is not None and self.paused_at is not None:
            if is_backchannel(text) and now - self.paused_at <= self.window_secs:
                self.paused_at = None
                return "resume_tts"
            self.history.append({"role": "user", "content": text})
            self._truncate()
            self.speaking = self.paused_at = None
            return "stop_tts"
        self.history.append({"role": "user", "content": text})
        return "new_turn"

    def tick(self, now: float) -> str | None:
        """Called by the event loop: speech with no words after the window was noise, so resume."""
        if self.paused_at is not None and now - self.paused_at > self.window_secs:
            self.paused_at = None
            return "resume_tts"
        return None

    def _truncate(self) -> None:
        heard = self.speaking[: self.spoken_chars]
        if self.spoken_chars < len(self.speaking) and " " in heard:
            heard = heard[: heard.rfind(" ")]
        self.history[-1] = {"role": "assistant", "content": heard.rstrip(" ,")}
