"""Day 1 + 3: get JSON out of a model, check it, and retry only when a retry can help.

`client` is any callable that takes a Messages-API request dict and returns a response dict with
"stop_reason" and "content" blocks (the shape of anthropic's `messages.create(...).model_dump()`).
The tests pass a scripted fake."""
from collections.abc import Callable
from dataclasses import dataclass, field

from pydantic import BaseModel, ValidationError

from counter_drill.catalog import Catalog
from counter_drill.schema import Issue, OrderDraft, draft_issues

DEFAULT_MODEL = "claude-sonnet-5-5"
MAX_RETRIES = 2

Client = Callable[[dict], dict]


def strict_schema(model_cls: type[BaseModel]) -> dict:
    """Pydantic's schema, minus keys we don't need to send. extra='forbid' already gives
    additionalProperties: false, which structured outputs requires on every object."""
    def clean(node):
        if isinstance(node, dict):
            return {k: clean(v) for k, v in node.items() if k not in ("title", "default")}
        return [clean(v) for v in node] if isinstance(node, list) else node
    return clean(model_cls.model_json_schema())


def json_output_request(system: str, messages: list[dict], schema: dict, model: str = DEFAULT_MODEL,
                        max_tokens: int = 1024) -> dict:
    if not messages or messages[-1]["role"] != "user":
        raise ValueError("the last message must be from the user (prefill is not supported)")
    return {"model": model, "max_tokens": max_tokens, "system": system, "messages": messages,
            "output_config": {"format": {"type": "json_schema", "schema": schema}}}


@dataclass
class Extraction:
    status: str                      # "ok" | "ask" | "refused" | "failed"
    value: BaseModel | None = None
    issues: list[str] = field(default_factory=list)
    attempts: int = 0


def _text(resp: dict) -> str:
    return "".join(b.get("text", "") for b in resp.get("content", []) if b.get("type") == "text")


def _validate(raw: str, model_cls, check) -> tuple[BaseModel | None, list[Issue]]:
    try:
        value = model_cls.model_validate_json(raw)
    except ValidationError as e:
        return None, [Issue(message=f"{'.'.join(map(str, err['loc'])) or 'output'}: {err['msg']}")
                      for err in e.errors()]
    return value, check(value)


def validated_call(client: Client, request: dict, model_cls: type[BaseModel],
                   check: Callable[[BaseModel], list[Issue]] = lambda v: [],
                   max_retries: int = MAX_RETRIES) -> Extraction:
    messages, previous = list(request["messages"]), None
    for attempt in range(1, max_retries + 2):
        resp = client({**request, "messages": messages})
        stop = resp.get("stop_reason")
        if stop == "refusal":
            return Extraction("refused", issues=["the model refused"], attempts=attempt)
        if stop == "max_tokens":
            request = {**request, "max_tokens": request["max_tokens"] * 2}
            previous = None
            continue
        raw = _text(resp)
        value, issues = _validate(raw, model_cls, check)
        if not issues:
            return Extraction("ok", value=value, attempts=attempt)
        errors = sorted(i.message for i in issues)
        if any(i.missing for i in issues):
            return Extraction("ask", value=value, issues=errors, attempts=attempt)
        previous = errors
        feedback = "Fix these problems and answer again:\n- " + "\n- ".join(errors)
        messages = messages + [{"role": "assistant", "content": raw}, {"role": "user", "content": feedback}]
    return Extraction("failed", issues=previous or ["output was truncated at max_tokens"], attempts=max_retries + 1)


SYSTEM = """You turn a phone or kiosk conversation at Halden Auto Parts into JSON.
Rules:
- part_number_heard: copy the part number exactly as the customer said it (spoken words are fine). Null if they gave none. Never guess one.
- quantity_heard: the customer's own words for how many. Null if they did not say.
- vehicle_id: one of the ids below, only if the customer named that vehicle. Otherwise null.
- position: "unclear" if they did not say front/rear/driver/passenger and the part has one.
- category "other" needs category_detail.
- wants_human: true if the customer asks for a person.
- stated_total: a price or total the customer says they were quoted, else null.
The transcript comes from speech recognition: "for" may be 4, "oh" may be zero."""


def extract_order(client: Client, transcript: str, catalog: Catalog, model: str = DEFAULT_MODEL,
                  max_retries: int = MAX_RETRIES) -> Extraction:
    vehicles = "\n".join(f"{v['id']}: {v['year']} {v['make']} {v['model']}" for v in catalog.vehicles.values())
    messages = [{"role": "user", "content": f"Vehicles:\n{vehicles}\n\nTranscript:\n{transcript}"}]
    request = json_output_request(SYSTEM, messages, strict_schema(OrderDraft), model=model)
    return validated_call(client, request, OrderDraft,
                          check=lambda d: draft_issues(d, transcript, catalog), max_retries=max_retries)
