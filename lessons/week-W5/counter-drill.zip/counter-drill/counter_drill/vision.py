"""Day 3: get a customer's photo ready for a vision model, and find catalog parts that look like it.

Claude vision docs: cost is ceil(w/28) * ceil(h/28) visual tokens. Standard models cap images at 1568 px
on the long edge and 1568 tokens; bigger images are downscaled with the aspect ratio kept."""
import io
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps

MAX_EDGE, MAX_TOKENS = 1568, 1568


def image_tokens(width: int, height: int) -> int:
    return math.ceil(width / 28) * math.ceil(height / 28)


def claude_target_size(width: int, height: int) -> tuple[int, int]:
    """The size Claude will actually see: fit the long edge, then shrink until under the token cap."""
    scale = min(1.0, MAX_EDGE / max(width, height))
    w = round(width * scale)
    while image_tokens(w, round(w * height / width)) > MAX_TOKENS:
        w -= 1
    return (w, round(w * height / width)) if w != width else (width, height)


def prepare_image(source: str | Path | bytes | Image.Image) -> Image.Image:
    """Upright, no bigger than the model will see anyway, and nothing but pixels: no EXIF, so no GPS
    position, camera serial or timestamps leave the store."""
    img = source if isinstance(source, Image.Image) else Image.open(
        io.BytesIO(source) if isinstance(source, bytes) else source)
    img = ImageOps.exif_transpose(img).convert("RGB")
    size = claude_target_size(*img.size)
    if size != img.size:
        img = img.resize(size, Image.LANCZOS)
    return img


def png_bytes(img: Image.Image) -> bytes:
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def load_embeddings(path: str | Path) -> dict[str, np.ndarray]:
    """Catalog part number -> vector."""
    data = json.loads(Path(path).read_text())
    return {k: np.asarray(v, dtype=float) for k, v in data["catalog"].items()}


def knn(vector: np.ndarray, index: dict[str, np.ndarray], allowed: list[str], k: int = 3) -> list[tuple[str, float]]:
    """Cosine similarity, best first, over the allowed part numbers only (the fitment filter is hard)."""
    q = vector / np.linalg.norm(vector)
    scored = [(pn, float(index[pn] @ q / np.linalg.norm(index[pn]))) for pn in allowed if pn in index]
    return sorted(scored, key=lambda s: -s[1])[:k]
