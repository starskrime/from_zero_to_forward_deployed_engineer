"""Day 1: the catalog is the source of truth. A part number from a model or a customer is a search key."""
import json
import re
from dataclasses import dataclass
from pathlib import Path

# Look-alike characters that OCR and speech mix up. Folding both sides lets us find confusable pairs.
_FOLD = str.maketrans({"O": "0", "I": "1", "B": "8", "S": "5"})

LETTERS = {  # letter names as an ASR engine writes them, plus NATO words
    "ay": "A", "a": "A", "alpha": "A", "alfa": "A", "bee": "B", "be": "B", "b": "B", "bravo": "B",
    "see": "C", "sea": "C", "c": "C", "charlie": "C", "dee": "D", "d": "D", "delta": "D",
    "ee": "E", "e": "E", "echo": "E", "eff": "F", "ef": "F", "f": "F", "foxtrot": "F",
    "gee": "G", "g": "G", "golf": "G", "aitch": "H", "h": "H", "hotel": "H", "eye": "I", "i": "I",
    "india": "I", "jay": "J", "j": "J", "juliet": "J", "kay": "K", "k": "K", "kilo": "K",
    "el": "L", "l": "L", "lima": "L", "em": "M", "m": "M", "mike": "M", "en": "N", "n": "N",
    "november": "N", "o": "O", "oscar": "O", "pee": "P", "p": "P", "papa": "P", "cue": "Q", "q": "Q",
    "quebec": "Q", "are": "R", "r": "R", "romeo": "R", "ess": "S", "s": "S", "sierra": "S",
    "tee": "T", "t": "T", "tango": "T", "you": "U", "u": "U", "uniform": "U", "vee": "V", "v": "V",
    "victor": "V", "w": "W", "whiskey": "W", "ex": "X", "x": "X", "xray": "X", "why": "Y", "y": "Y",
    "yankee": "Y", "zed": "Z", "zee": "Z", "z": "Z", "zulu": "Z",
}
DIGITS = {"zero": "0", "one": "1", "two": "2", "three": "3", "four": "4", "five": "5", "six": "6",
          "seven": "7", "eight": "8", "nine": "9", "niner": "9"}
SOUNDALIKE_DIGITS = {"for": "4", "fore": "4", "to": "2", "too": "2", "won": "1", "ate": "8"}
SKIP = {"um", "uh", "er", "like", "dash", "hyphen", "number", "part", "is", "it's", "its", "the", "uh-huh",
        "and", "then", "okay", "ok", "so", "yeah", "that's", "thats"}
DIGIT_POSITIONS = range(2, 6)  # LL-XXXX-X: the middle block is usually digits


def normalize_part_number(text: str) -> str:
    """'hb 4417.k' -> 'HB4417K'. Separators are noise; the compact form is what we compare."""
    return re.sub(r"[\s\-._/]", "", text).upper()


def format_part_number(compact: str) -> str:
    """'HB4417K' -> 'HB-4417-K' (only for 7-character keys; anything else is returned as is)."""
    c = normalize_part_number(compact)
    return f"{c[:2]}-{c[2:6]}-{c[6:]}" if len(c) == 7 else c


def fold(text: str) -> str:
    return normalize_part_number(text).translate(_FOLD)


def spoken_to_chars(text: str) -> str:
    """'bee aitch four four one seven kay' -> 'BH4417K'. 'oh' is 0 in digit positions and O elsewhere;
    'for'/'to' count as digits only inside the number (after the two-letter line code)."""
    out: list[str] = []
    text = text.lower().replace("uh-huh", " ").replace("mm-hmm", " ")
    words = re.findall(r"[a-z0-9']+", text)
    for i, w in enumerate(words):
        pos = len("".join(out))
        if w in ("double", "triple") or w in SKIP:
            continue
        repeat = {"double": 2, "triple": 3}.get(words[i - 1] if i else "", 1)
        if w == "oh":
            ch = "0" if pos in DIGIT_POSITIONS else "O"
        elif w in DIGITS:
            ch = DIGITS[w]
        elif w in SOUNDALIKE_DIGITS and pos >= 2:
            ch = SOUNDALIKE_DIGITS[w]
        elif w in LETTERS:
            ch = LETTERS[w]
        elif (pos == 0 and re.fullmatch(r"[a-z]{2}", w)) or re.search(r"\d", w):  # 'hb', '4417', '2o10'
            ch = w.upper()
        else:
            continue
        out.append(ch * repeat)
    return "".join(out)


def edit_distance(a: str, b: str) -> int:
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


@dataclass
class Catalog:
    vehicles: dict[str, dict]
    parts: dict[str, dict]          # keyed by the compact part number

    def get(self, part_number: str) -> dict | None:
        """Exact lookup only. Never 'closest'."""
        return self.parts.get(normalize_part_number(part_number))

    def near(self, part_number: str) -> list[dict]:
        """Parts one edit away or differing only by look-alike characters. These are candidates to ask
        about, never an answer: HF-2010-A and HF-2O10-A are both real and fit different vehicles."""
        key = normalize_part_number(part_number)
        return [p for k, p in self.parts.items()
                if k != key and (edit_distance(k, key) < 1 or fold(k) == fold(key))]

    def fits(self, part: dict, vehicle_id: str | None) -> bool:
        return vehicle_id is not None and vehicle_id in part["fits"]

    def current(self, part: dict) -> tuple[dict, str | None]:
        """Follow superseded_by. Returns (part to sell, discontinued number it replaces or None)."""
        replaced = None
        while part.get("superseded_by"):
            replaced = replaced or part["part_number"]
            part = self.get(part["superseded_by"])
        return part, replaced

    def for_vehicle(self, vehicle_id: str | None, category: str | None = None,
                    position: str | None = None) -> list[dict]:
        """Active parts that fit, optionally narrowed by category and position."""
        return [p for p in self.parts.values()
                if p["status"] == "active" and self.fits(p, vehicle_id)
                and (category is None or p["category"] == category)
                and (position is None or p["attributes"].get("position") == position)]


def load_catalog(path: str | Path) -> Catalog:
    data = json.loads(Path(path).read_text())
    return Catalog(vehicles={v["id"]: v for v in data["vehicles"]},
                   parts={normalize_part_number(p["part_number"]): p for p in data["parts"]})
