"""Six of these tests fail. Each failure is a bug in counter_drill/, not in the tests. Fix the code."""
import io
from pathlib import Path

import numpy as np
import pytest
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command
from PIL import Image

from counter_drill.catalog import format_part_number, load_catalog, normalize_part_number, spoken_to_chars
from counter_drill.checkout import APPROVAL_TTL_SECS, build_checkout, sweep_expired
from counter_drill.extract import extract_order
from counter_drill.identify import identify
from counter_drill.schema import Order, OrderLine, PartQuery, order_errors
from counter_drill.speech import check_quantity, read_back
from counter_drill.turns import TurnManager
from counter_drill.vision import claude_target_size, knn, load_embeddings, png_bytes, prepare_image
from tests.fakes import Clock, FakeOrders, RoutedClient, refusal, text_reply

DATA = Path(__file__).resolve().parent.parent / "data"
CATALOG = load_catalog(DATA / "halden.json")
INDEX = load_embeddings(DATA / "embeddings.json")

T_NO_NUMBER = "Customer: front brake pads for my twenty nineteen Arlo Vela"
GOOD = {"vehicle_id": "arlo-vela-2019", "items": [{"category": "brake_pads", "position": "front",
        "part_number_heard": None, "quantity_heard": None, "category_detail": None}],
        "wants_human": False, "stated_total": None}
INVENTED = {**GOOD, "items": [{**GOOD["items"][0], "part_number_heard": "HB-4417-K"}]}


# Day 1: the catalog is the source of truth ------------------------------------------------------------

def test_part_numbers_are_normalized_and_spoken_forms_decoded():
    assert normalize_part_number(" hb 4417.k ") == "HB4417K"
    assert format_part_number("hb4417k") == "HB-4417-K"
    assert spoken_to_chars("aitch eff two oh one oh ay") == "HF2010A"          # 'oh' in the digit block is zero
    assert spoken_to_chars("H S seven one one for C") == "HS7114C"             # 'for' inside the number is 4
    assert spoken_to_chars("aitch vee six six double oh bee") == "HV6600B"


def test_lookup_is_exact_and_look_alikes_are_only_candidates():
    assert CATALOG.get("HF-2010-A")["fits"] != CATALOG.get("HF-2O10-A")["fits"]
    assert CATALOG.get("HB-4417") is None
    assert {p["part_number"] for p in CATALOG.near("HF-2010-A")} == {"HF-2O10-A", "HF-2011-A"}
    assert [p["part_number"] for p in CATALOG.near("HL-11OO-H")] == ["HL-1100-H"]


def test_fitment_filter_skips_discontinued_and_follows_supersession():
    assert [p["part_number"] for p in CATALOG.for_vehicle("arlo-vela-2019", "brake_pads", "front")] == ["HB-4417-K"]
    assert [p["part_number"] for p in CATALOG.for_vehicle("arlo-vela-2019", "battery")] == ["HV-6610-B"]
    assert CATALOG.for_vehicle(None, "battery") == []
    part, replaced = CATALOG.current(CATALOG.get("HV-6600-B"))
    assert (part["part_number"], replaced) == ("HV-6610-B", "HV-6600-B")


def test_read_back_spells_letters_and_quantities_have_bounds():
    said = read_back("HF-2O10-A")
    assert said == "H as in Hotel, F as in Foxtrot. dash. two, O as in Oscar, one, zero. dash. A as in Alpha."
    assert [check_quantity(n).status for n in (1, 4, 5, 20, 21, 0, 18000)] == \
        ["ok", "ok", "confirm", "confirm", "refuse", "refuse", "refuse"]


def test_order_total_and_the_last_gate():
    order = Order(vehicle_id="arlo-vela-2021", stated_total=169.99,
                  lines=[OrderLine(part_number="HV-6610-B", quantity=1, unit_price=179.99)])
    assert (order.calculated_total, order.conflict_detected) == (179.99, True)
    bad = Order(vehicle_id="calloway-mistral-2020", lines=[
        OrderLine(part_number="HB-9999-K", quantity=1, unit_price=1.0),
        OrderLine(part_number="HB-4471-K", quantity=1, unit_price=69.99),
        OrderLine(part_number="HW-5822-L", quantity=40, unit_price=14.99),
        OrderLine(part_number="HF-3300-C", quantity=1, unit_price=0.0),
        OrderLine(part_number="HV-6600-B", quantity=1, unit_price=169.99)])
    assert order_errors(bad, CATALOG) == [
        "HB-9999-K is not in the catalog",
        "HB-4471-K does not fit calloway-mistral-2020",
        "HW-5822-L: quantity 40 is outside 1-20; a person must handle it",
        "HF-3300-C: unit price 0.0 is not the catalog price 12.99",
        "HV-6600-B is discontinued"]


# Day 2: barge-in -----------------------------------------------------------------------------------

def test_barge_in_truncates_history_to_what_was_heard():
    tm = TurnManager()
    tm.bot_says("Front pads are fifty four ninety nine, and the rotors are seventy nine ninety nine.")
    tm.bot_progress(24)                               # "Front pads are fifty fou" has played
    assert tm.user_speech_started(now=10.0) == "pause_tts"
    assert tm.user_said("no, the rear ones", now=10.6) == "stop_tts"
    assert tm.history == [{"role": "assistant", "content": "Front pads are fifty"},
                          {"role": "user", "content": "no, the rear ones"}]


def test_backchannel_and_noise_resume_without_truncating():
    tm = TurnManager()
    tm.bot_says("That's H as in Hotel, B as in Bravo.")
    tm.bot_progress(10)
    tm.user_speech_started(now=5.0)
    assert tm.user_said("uh-huh", now=5.4) == "resume_tts"
    assert tm.history == [{"role": "assistant", "content": "That's H as in Hotel, B as in Bravo."}]
    tm.user_speech_started(now=6.0)
    assert tm.tick(now=7.5) is None
    assert tm.tick(now=8.1) == "resume_tts"


# Days 2-3: structured output and retries -----------------------------------------------------------

def test_retry_with_the_specific_error_removes_an_invented_number():
    client = RoutedClient({"front brake pads": [INVENTED, GOOD]})
    ext = extract_order(client, T_NO_NUMBER, CATALOG)
    assert (ext.status, ext.attempts, ext.value.items[0].part_number_heard) == ("ok", 2, None)
    assert "does not appear in the transcript" in client.requests[1]["messages"][-1]["content"]


def test_same_error_twice_is_futile_so_ask():
    t = "Customer: I need bee aitch nine nine nine nine kay for a twenty seventeen Dunholt Pira"
    said = {**GOOD, "vehicle_id": "dunholt-pira-2017",
            "items": [{**GOOD["items"][0], "category": None, "part_number_heard": "bee aitch nine nine nine nine kay"}]}
    client = RoutedClient({"nine nine": [said]}, sticky=True)
    ext = extract_order(client, t, CATALOG)
    assert (ext.status, ext.attempts, len(client.requests)) == ("ask", 2, 2)
    assert "BH-9999-K is not in the catalog" in ext.issues[0]


def test_stop_reasons_and_missing_information_are_not_blindly_retried():
    client = RoutedClient({"air filter": [{**GOOD, "vehicle_id": None}]})
    ext = extract_order(client, "Customer: do you have an air filter?", CATALOG)
    assert (ext.status, ext.attempts, len(client.requests)) == ("ask", 1, 1)
    client = RoutedClient({"front brake pads": [refusal()]})
    assert extract_order(client, T_NO_NUMBER, CATALOG).status == "refused" and len(client.requests) == 1
    client = RoutedClient({"front brake pads": [text_reply('{"vehicle_id": "arlo-', "max_tokens"), GOOD]})
    ext = extract_order(client, T_NO_NUMBER, CATALOG)
    assert ext.status == "ok" and client.requests[1]["max_tokens"] == 2 * client.requests[0]["max_tokens"]
    assert len(client.requests[1]["messages"]) == 1                     # truncated JSON is not fed back


# Day 3: photos -----------------------------------------------------------------------------------------

def test_prepare_image_strips_exif_and_applies_orientation():
    src = Image.open(DATA / "photo_02_sideways.jpg")
    assert src.size == (480, 640) and src.getexif().get_ifd(0x8825)       # GPS present, stored sideways
    prepared = prepare_image(DATA / "photo_02_sideways.jpg")
    assert prepared.size == (640, 480)
    assert prepared.info == {} and len(prepared.getexif()) == 0            # nothing left to leak, in memory either
    assert len(Image.open(io.BytesIO(png_bytes(prepared))).getexif()) == 0


def test_target_size_and_the_fitment_filter_on_knn():
    assert claude_target_size(1920, 1080) == (1456, 819)
    w, h = claude_target_size(4032, 3024)                                  # a phone photo
    assert max(w, h) <= 1568 and abs(w / h - 4 / 3) < 0.01
    allowed = [p["part_number"] for p in CATALOG.for_vehicle("arlo-vela-2019")]
    assert knn(INDEX["HB-4471-K"], INDEX, list(INDEX))[0][0] == "HB-4471-K"
    assert "HB-4471-K" not in [pn for pn, _ in knn(INDEX["HB-4471-K"], INDEX, allowed)]
    assert knn(np.ones(32), INDEX, []) == []


def test_voice_identification_narrows_to_one_part_or_asks():
    front = identify(PartQuery(category="brake_pads", position="front"), "arlo-vela-2019", CATALOG)
    either = identify(PartQuery(category="brake_pads", position="unclear"), "arlo-vela-2019", CATALOG)
    assert (front.status, front.part["part_number"], front.method) == ("match", "HB-4417-K", "description")
    assert (either.status, either.candidates) == ("ask", ["HB-4417-K", "HB-4418-K"])
    old = identify(PartQuery(part_number_heard="aitch vee six six double oh bee"), "arlo-vela-2019", CATALOG)
    assert (old.part["part_number"], old.replaced) == ("HV-6610-B", "HV-6600-B")


def test_photo_match_needs_a_margin_and_agreement():
    halfway = (INDEX["HB-4417-K"] + INDEX["HB-4418-K"]) / 2
    q = PartQuery(category="brake_pads", position="unclear")
    tie = identify(q, "arlo-vela-2019", CATALOG, source="image", vector=halfway, index=INDEX)
    assert tie.status == "ask" and tie.margin < 0.05 and set(tie.candidates[:2]) == {"HB-4417-K", "HB-4418-K"}
    clear = identify(q, "arlo-vela-2019", CATALOG, source="image", vector=INDEX["HR-3880-F"], index=INDEX)
    assert clear.status == "ask"          # a confident match that disagrees with the model's category: ask
    unrelated = identify(PartQuery(), "arlo-vela-2019", CATALOG, source="image", vector=np.eye(32)[0], index=INDEX)
    assert unrelated.status == "no_match"


# Day 4: checkout with a person in the loop ---------------------------------------------------------------

def _checkout(order: Order, picks: list[dict], thread: str):
    orders, clock = FakeOrders(), Clock()
    graph = build_checkout(CATALOG, orders, clock, checkpointer=InMemorySaver())
    config = {"configurable": {"thread_id": thread}}
    result = graph.invoke({"order": order.model_dump(), "picks": picks}, config)
    return graph, config, result, orders, clock


def _pick(pn, replaced=None):
    return {"part_number": pn, "method": "number", "margin": None, "replaced": replaced, "flags": []}


SMALL = Order(vehicle_id="arlo-vela-2019", lines=[OrderLine(part_number="HB-4417-K", quantity=1, unit_price=54.99)])
RISKY = Order(vehicle_id="arlo-vela-2021", stated_total=169.99,
              lines=[OrderLine(part_number="HV-6610-B", quantity=1, unit_price=179.99)])


def test_risky_order_pauses_for_a_person_then_places_once():
    _, _, result, orders, _ = _checkout(SMALL, [_pick("HB-4417-K")], "small")
    assert "__interrupt__" not in result and result["outcome"] == "placed" and len(orders.placed) == 1

    graph, config, result, orders, clock = _checkout(RISKY, [_pick("HV-6610-B", "HV-6600-B")], "risky")
    card = result["__interrupt__"][0].value
    assert orders.placed == []
    assert card["risk_reasons"] == ["total $179.99 is over $150",
                                    "customer was told $169.99; catalog total is $179.99",
                                    "HV-6610-B replaces discontinued HV-6600-B"]
    assert card["read_back"][0].startswith("1 of H as in Hotel, V as in Victor. dash. six, six, one, zero.")
    assert card["deadline"] == clock.t + APPROVAL_TTL_SECS
    clock.t += 60
    done = graph.invoke(Command(resume={"decision": "approve", "approver": "counter-07"}), config)
    assert done["outcome"] == "placed" and len(orders.placed) == 1
    assert (done["audit"][0]["approver"], done["audit"][0]["at"]) == ("counter-07", clock.t)
    assert done["audit"][0]["shown"] == card


def test_expired_approval_is_escalated_never_approved():
    graph, config, result, orders, clock = _checkout(RISKY, [_pick("HV-6610-B")], "expires")
    deadline = result["__interrupt__"][0].value["deadline"]
    assert sweep_expired(graph, ["expires"], now=deadline - 1) == []
    clock.t = deadline + 1
    assert sweep_expired(graph, ["expires"], now=clock.t) == ["expires"]
    state = graph.get_state(config).values
    assert state["outcome"] == "escalate_to_human" and orders.placed == []
    assert state["audit"][0]["decision"] == "timeout" and state["audit"][0]["approver"] == "system:expiry-sweep"
    assert sweep_expired(graph, ["expires"], now=clock.t + 999) == []
