"""A scripted stand-in for the model, routed by content, so every test runs offline and deterministically."""
import itertools
import json

_ids = itertools.count(1)


def text_reply(obj, stop_reason: str = "end_turn") -> dict:
    text = obj if isinstance(obj, str) else json.dumps(obj)
    return {"id": f"msg_{next(_ids)}", "type": "message", "role": "assistant", "stop_reason": stop_reason,
            "content": [{"type": "text", "text": text}]}


def refusal() -> dict:
    return {"id": f"msg_{next(_ids)}", "type": "message", "role": "assistant", "stop_reason": "refusal", "content": []}


class RoutedClient:
    """routes maps a string that appears in the request to a queue of replies (dicts are wrapped with
    text_reply). With sticky=True, a route whose queue has one reply left keeps returning it, which
    models a model that repeats itself. Every request is recorded in .requests."""

    def __init__(self, routes: dict[str, list], sticky: bool = False):
        self.queues = {k: list(v) for k, v in routes.items()}
        self.sticky, self.requests = sticky, []

    def __call__(self, request: dict) -> dict:
        self.requests.append(request)
        text = request.get("system", "") + json.dumps(request["messages"])
        key = next((k for k in self.queues if k in text), None)
        if key is None or not self.queues[key]:
            raise AssertionError(f"no scripted reply for: {text[:160]}")
        reply = self.queues[key][0] if self.sticky and len(self.queues[key]) == 1 else self.queues[key].pop(0)
        return reply if "stop_reason" in reply else text_reply(reply)


class FakeOrders:
    """Records every order placed."""

    def __init__(self):
        self.placed = []

    def place(self, order: dict) -> str:
        self.placed.append(order)
        return f"HAP-{len(self.placed):05d}"


class Clock:
    def __init__(self, t: float = 1_000_000.0):
        self.t = t

    def __call__(self) -> float:
        return self.t
