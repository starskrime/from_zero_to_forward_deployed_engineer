import hashlib
import math
import re


class FakeEmbedder:
    """Texts that share words get similar vectors. No network, no cost."""

    def __init__(self, dims: int = 256):
        self.dims = dims
        self.name = f"fake-{dims}"

    def embed(self, texts: list[str]) -> list[list[float]]:
        out = []
        for text in texts:
            v = [0.0] * self.dims
            for word in re.findall(r"[a-z0-9]+", text.lower()):
                v[int(hashlib.md5(word.encode()).hexdigest(), 16) % self.dims] += 1.0
            norm = math.sqrt(sum(x * x for x in v)) or 1.0
            out.append([x / norm for x in v])
        return out
