"""Turn every source into Documents: text plus metadata that says where it came from."""
import csv
from dataclasses import dataclass, field
from pathlib import Path

from pypdf import PdfReader


@dataclass
class Document:
    text: str
    metadata: dict = field(default_factory=dict)


def load_markdown(path: Path) -> Document:
    text = path.read_text(encoding="utf-8")
    title = next((line[2:].strip() for line in text.splitlines() if line.startswith("# ")), path.stem)
    return Document(text, {"source": path.name, "title": title, "doc_type": "doc"})


def load_pdf(path: Path) -> list[Document]:
    """One Document per page."""
    reader = PdfReader(path)
    title = (reader.metadata.title if reader.metadata and reader.metadata.title else path.stem)
    docs = []
    for number, page in enumerate(reader.pages, start=1):
        text = page.extract_text().strip()
        if text:
            docs.append(Document(text, {"source": path.name, "title": title, "page": number, "doc_type": "pdf"}))
    return docs


def load_tickets(path: Path) -> list[Document]:
    """One Document per resolved ticket: the problem and its resolution belong together."""
    with open(path, newline="", encoding="utf-8") as f:
        return [Document(
            f"Ticket {r['ticket_id']} ({r['category']}): {r['subject']}\n"
            f"Problem: {r['description']}\nResolution: {r['resolution']}",
            {"source": r["ticket_id"], "title": r["subject"], "doc_type": "ticket", "created_at": r["created_at"]})
            for r in csv.DictReader(f)]


def load_all(folder: Path) -> list[Document]:
    docs = [load_markdown(p) for p in sorted((folder / "docs").glob("*.md"))]
    for p in sorted((folder / "pdfs").glob("*.pdf")):
        docs += load_pdf(p)
    docs += load_tickets(folder / "tickets.csv")
    return docs
