from dataclasses import dataclass

import chromadb

from kb_drill.loaders import Document


@dataclass
class Hit:
    text: str
    metadata: dict
    score: float


class KnowledgeBase:
    def __init__(self, embedder, path: str | None = ".chroma"):
        client = chromadb.PersistentClient(path=path) if path else chromadb.Client()
        self.embedder = embedder
        self.collection = client.get_or_create_collection(
            "kb-main", configuration={"hnsw": {"space": "cosine"}}, embedding_function=None)

    def add(self, chunks: list[Document]) -> int:
        vectors = self.embedder.embed([c.text for c in chunks])
        self.collection.upsert(ids=[c.metadata["chunk_id"] for c in chunks], embeddings=vectors,
                               documents=[c.text for c in chunks], metadatas=[c.metadata for c in chunks])
        return self.collection.count()

    def search(self, query: str, k: int = 5, where: dict | None = None) -> list[Hit]:
        vector = self.embedder.embed([query])[0]
        r = self.collection.query(query_embeddings=[vector], n_results=k, where=where)
        return [Hit(doc, meta, round(dist, 4))
                for doc, meta, dist in zip(r["documents"][0], r["metadatas"][0], r["distances"][0])]
