"""Split Documents into chunks small enough to retrieve precisely, big enough to make sense alone."""
import re

from kb_drill.loaders import Document


def chunk_fixed(text: str, size: int = 800, overlap: int = 100) -> list[str]:
    """Fixed-size windows that overlap, so a sentence cut at a boundary appears whole in one of them."""
    if overlap >= size:
        raise ValueError("overlap must be smaller than size")
    chunks, start = [], 0
    while start < len(text):
        chunks.append(text[start:start + size])
        if start + size >= len(text):
            break
        start += size
    return chunks


def chunk_markdown(doc: Document, max_chars: int = 1200) -> list[Document]:
    """One chunk per '## ' section, prefixed with the document and section titles for context."""
    parts = re.split(r"(?m)^## ", doc.text)
    intro, sections = parts[0], parts[1:]
    out = []
    intro_body = "\n".join(line for line in intro.splitlines() if not line.startswith("# ")).strip()
    if intro_body:
        out.append(("Overview", intro_body))
    for section in sections:
        heading, _, body = section.partition("\n")
        out.append((heading.strip(), body.strip()))
    chunks = []
    for heading, body in out:
        for piece in (chunk_fixed(body, max_chars, 150) if len(body) > max_chars else [body]):
            chunks.append(Document(f"{doc.metadata['title']} > {heading}\n{piece}",
                                   {**doc.metadata, "section": heading}))
    return chunks


def chunk_documents(docs: list[Document]) -> list[Document]:
    chunks = []
    for doc in docs:
        if doc.metadata["doc_type"] == "doc":
            chunks += chunk_markdown(doc)
        elif doc.metadata["doc_type"] == "pdf":
            chunks += [Document(f"{doc.metadata['title']} (page {doc.metadata['page']})\n{piece}", doc.metadata)
                       for piece in chunk_fixed(doc.text, 1200, 200)]
        else:
            chunks.append(doc)                        # a ticket is already a natural unit
    counters: dict[str, int] = {}
    for chunk in chunks:                              # number chunks within each source, so ids stay
        source = chunk.metadata["source"]             # stable when other documents are added or removed
        counters[source] = counters.get(source, 0) + 1
        chunk.metadata = {**chunk.metadata, "chunk_id": f"{source}#{counters[source]}"}
    return chunks
