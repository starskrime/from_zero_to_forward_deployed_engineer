# Break it & fix it: Week 2

This small RAG package looks fine and runs without errors. It has six bugs,
each one a mistake that shows up in real RAG code.

    pip install pypdf chromadb pydantic openai httpx pytest
    python -m pytest -q

Six tests fail. Fix the code in `kb_drill/`, never the tests. For each bug,
write one line in `BUGS.md`: what was wrong, what a user would have seen in
production, and how you fixed it.

Everything runs offline: the embedder is a word-hash fake and the model
replies are scripted, so there is no API cost.
