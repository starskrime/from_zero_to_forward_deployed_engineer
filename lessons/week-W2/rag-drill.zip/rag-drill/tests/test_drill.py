"""Five of these tests fail. Each failure is a bug in kb_drill/, not in the tests. Fix the code."""
import json
from pathlib import Path

import chromadb

from kb_drill.answer import IDK, answer_question
from kb_drill.chunking import chunk_documents, chunk_fixed
from kb_drill.embeddings import FakeEmbedder
from kb_drill.loaders import load_all, load_pdf
from kb_drill.store import Hit, KnowledgeBase
from tests.fakes import message, response, scripted_client

DATA = Path(__file__).resolve().parent.parent / "data"


def test_loads_all_documents():
    assert len(load_all(DATA)) == 40


def test_pdf_table_row_stays_together():
    page = load_pdf(DATA / "pdfs" / "it-security-handbook.pdf")[1]
    assert any("Screen lock" in line and "1 minute" in line for line in page.text.splitlines())


def test_fixed_chunks_overlap():
    assert chunk_fixed("abcdefghij", size=4, overlap=1) == ["abcd", "defg", "ghij"]


def test_chunk_count():
    assert len(chunk_documents(load_all(DATA))) == 57


def test_two_embedding_models_can_share_one_database(tmp_path):
    small, large = KnowledgeBase(FakeEmbedder(32), str(tmp_path)), KnowledgeBase(FakeEmbedder(64), str(tmp_path))
    chunks = chunk_documents(load_all(DATA))
    assert small.add(chunks) == 57 and large.add(chunks) == 57


def test_best_match_has_highest_score():
    kb = KnowledgeBase(FakeEmbedder(1024), None)
    kb.add(chunk_documents(load_all(DATA)))
    hits = kb.search("Which printer queue on the 3rd floor of the Dallas office?", k=5)
    assert hits[0].metadata["source"] == "T-1004"
    assert hits[0].score == max(h.score for h in hits) and 0 < hits[0].score <= 1


def hit(source, score=0.6):
    return Hit(f"text from {source}", {"source": source, "title": source}, score)


def test_citation_points_at_the_right_source():
    client = scripted_client([response([message(json.dumps({"answerable": True, "answer": "Use DAL-3F-PRINT [2].", "citations": [2]}))])])
    _, sources = answer_question(client, "printer?", [hit("T-1001"), hit("T-1004")])
    assert [s.metadata["source"] for s in sources] == ["T-1004"]


def test_uncited_answer_becomes_i_dont_know():
    client = scripted_client([response([message(json.dumps({"answerable": True, "answer": "Probably Friday.", "citations": []}))])])
    ans, _ = answer_question(client, "menu?", [hit("T-1001")])
    assert ans.answer == IDK


def test_low_scores_skip_the_model():
    ans, _ = answer_question(object(), "menu?", [hit("T-1001", 0.1)], min_score=0.3)
    assert ans.answer == IDK
