"""Build fake Responses API replies so the agent can be tested with no network."""
import itertools
import json

import httpx
from openai import OpenAI

_ids = itertools.count(1)
USAGE = {"input_tokens": 100, "output_tokens": 20, "total_tokens": 120,
         "input_tokens_details": {"cached_tokens": 0}, "output_tokens_details": {"reasoning_tokens": 0}}


def response(output: list) -> dict:
    return {"id": f"resp_{next(_ids)}", "object": "response", "created_at": 0, "model": "gpt-6-luna",
            "status": "completed", "output": output, "usage": USAGE,
            "parallel_tool_calls": True, "tool_choice": "auto", "tools": []}


def function_call(name: str, **arguments) -> dict:
    n = next(_ids)
    return {"type": "function_call", "id": f"fc_{n}", "call_id": f"call_{n}", "name": name,
            "arguments": json.dumps(arguments), "status": "completed"}


def message(text: str) -> dict:
    return {"type": "message", "id": f"msg_{next(_ids)}", "status": "completed", "role": "assistant",
            "content": [{"type": "output_text", "text": text, "annotations": []}]}


def scripted_client(replies: list[dict], requests: list | None = None) -> OpenAI:
    """Each API call gets the next reply from the list; request bodies are saved for assertions."""
    queue = list(replies)

    def handler(request: httpx.Request) -> httpx.Response:
        if requests is not None:
            requests.append(json.loads(request.content))
        return httpx.Response(200, json=queue.pop(0))

    return OpenAI(api_key="test", http_client=httpx.Client(transport=httpx.MockTransport(handler)))
