# Password and MFA policy

## Password rules
- Minimum length: 14 characters. Passphrases are encouraged.
- Passwords expire every 365 days, or immediately if a compromise is suspected.
- You cannot reuse any of your last 10 passwords.
- Never share your password with anyone, including IT. IT will never ask for it.

## Multi-factor authentication (MFA)
- MFA is required for every employee. The approved methods are Okta Verify push and a hardware security key (YubiKey).
- SMS codes are not allowed.
- Engineers with production access must use a hardware security key.

## Resetting your password
Use the "Forgot password" link on the SSO portal at `sso.lumora.example`. You will need Okta Verify on your phone.
If you have lost your phone as well, call the IT help line at extension 4357 (HELP) for an identity check by video.

## Account lockout
After 10 failed sign-in attempts your account is locked for 30 minutes. It unlocks automatically; IT can unlock it sooner after an identity check.
