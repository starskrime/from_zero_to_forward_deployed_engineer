# New laptop and onboarding

## What new hires receive
- Engineers: MacBook Pro 16-inch, 36 GB memory.
- Everyone else: MacBook Air 15-inch, or a Dell Latitude 7450 on request.
- Laptops ship to the new hire's home address 5 business days before the start date.

## First-day setup
1. Connect to Wi-Fi and sign in with the temporary password from your welcome email.
2. Set up Okta Verify when prompted, then choose your permanent password.
3. The laptop enrolls itself in device management (Jamf for Mac, Intune for Windows) and installs the standard apps. This takes about 40 minutes; keep it plugged in.

## Replacing a laptop
Laptops are refreshed every 4 years. A broken laptop is replaced within 2 business days: open a "Hardware" ticket and IT will send a prepaid shipping label for the old one.
Do not wipe a laptop yourself before returning it. IT wipes it after checking that no data needs to be kept.
