# Single sign-on and application access

All company applications are reached through the SSO portal at `sso.lumora.example` (Okta).

## Requesting access to an application
1. Open the "Access Requests" tile in the SSO portal.
2. Pick the application and the role you need, and give a business reason.
3. Your manager approves. Applications marked "sensitive" (Salesforce admin, finance systems, production AWS) also need the application owner's approval.

Standard requests are usually approved within one business day.

## Access reviews
Every quarter, managers review their team's access. Access that is not re-approved within 14 days is removed automatically.

## Contractors
Contractor accounts expire on the contract end date entered in Workday. To extend, the hiring manager updates the end date in Workday; access follows within 24 hours.
