# Connecting to the VPN

Lumora uses GlobalProtect for remote access to internal systems. You need the VPN for the finance
systems, the build servers and the internal wiki. Everyday tools (email, chat, the SSO portal) work without it.

## Install
1. Open Self Service on your Mac (or Software Center on Windows) and install "GlobalProtect".
2. Enter the portal address `vpn.lumora.example`.
3. Sign in with your Lumora SSO account. You will be asked to approve a push notification in the Okta Verify app.

## Common problems
- **"Gateway not responding"**: switch to the `us-east` gateway from the GlobalProtect menu. The `us-west` gateway is under maintenance every Sunday 02:00-04:00 Central.
- **Connected but internal sites do not load**: disconnect, run `sudo dscacheutil -flushcache` on Mac (or `ipconfig /flushdns` on Windows), then reconnect.
- **Hotel or airport Wi-Fi blocks the VPN**: sign in to the Wi-Fi's captive portal in a browser first, then connect.

## Split tunneling
Only traffic to internal Lumora addresses goes through the VPN. Video calls and streaming do not, so the VPN should not slow them down.
