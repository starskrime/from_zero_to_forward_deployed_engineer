# Email, calendar and shared mailboxes

Lumora uses Microsoft 365 for email and calendar.

## Shared mailboxes
Request access to a shared mailbox (for example support@ or billing@) through the SSO portal's "Access Requests" tile. It appears in Outlook automatically within 2 hours of approval.

## Mailbox size
Each mailbox holds 100 GB. Online archiving starts automatically for email older than 2 years.

## Phishing
Use the "Report Phishing" button in Outlook for anything suspicious. Do not forward suspicious emails to IT.
If you clicked a link or entered your password on a suspicious page, change your password at once and call extension 4357.

## Out of office
Set automatic replies in Outlook under Settings > Mail > Automatic replies.
