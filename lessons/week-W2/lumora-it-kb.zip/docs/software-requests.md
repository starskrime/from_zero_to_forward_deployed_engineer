# Installing and requesting software

## Pre-approved software
Anything in Self Service (Mac) or Software Center (Windows) is pre-approved and installs without a ticket. This includes Zoom, Slack, Visual Studio Code, Docker Desktop, Figma and the Microsoft 365 apps.

## Everything else
Open a "Software Request" ticket with the name, the website and what you need it for. Security reviews new software within 5 business days.
Free browser extensions also need a request: extensions can read the pages you visit.

## Not allowed
- Personal cloud storage (Dropbox, personal Google Drive) for company files.
- Remote-control tools such as TeamViewer or AnyDesk.
- Unlicensed or pirated software of any kind.
