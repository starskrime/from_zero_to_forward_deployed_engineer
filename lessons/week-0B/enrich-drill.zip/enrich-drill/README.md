# Break it & fix it: Week 0B

This is a small version of Lead Intake v2: it validates leads with Pydantic,
looks up each lead's city concurrently with httpx and asyncio, and stores the
results in SQLite. It looks fine and runs without errors. It has six bugs,
each one a mistake that shows up in real API and data code.

    pip install "pydantic>=2" httpx pytest
    python -m pytest -q

Six tests fail. Fix the code in `lead_enrich/`, never the tests. For each bug,
write one line in `BUGS.md`: what was wrong, what a user would have seen in
production, and how you fixed it.

Everything runs offline: the ZIP-code API is replaced by `httpx.MockTransport`
fakes in `tests/fakes.py`, and the databases are in memory or in `tmp_path`.
