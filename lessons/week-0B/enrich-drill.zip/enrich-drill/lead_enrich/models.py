import csv
from datetime import date
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

US_STATES = {
    "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY",
    "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND",
    "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY", "DC",
}


class Lead(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    lead_id: str = Field(min_length=1)
    full_name: str = Field(min_length=1)
    email: str
    loan_amount: float = Field(gt=0, le=5_000_000)
    credit_score: int = Field(ge=300, le=850)
    annual_income: float = Field(ge=0)
    property_state: str
    loan_type: Literal["purchase", "refinance"]
    created_at: date
    zip: int = Field(ge=0, le=99999)

    @field_validator("email")
    @classmethod
    def email_looks_valid(cls, v: str) -> str:
        if "@" not in v or "." not in v.split("@")[-1]:
            raise ValueError("email must contain @ and a domain with a dot")
        return v.lower()

    @field_validator("property_state")
    @classmethod
    def state_is_known(cls, v: str) -> str:
        v = v.upper()
        if v not in US_STATES:
            raise ValueError(f"{v!r} is not a US state code")
        return v

    @field_validator("loan_type", mode="before")
    @classmethod
    def lower_loan_type(cls, v):
        return v.strip().lower() if isinstance(v, str) else v


def load_leads(path: Path) -> tuple[list[Lead], list[dict]]:
    """Validate every row. Returns (valid leads, error dicts with row, lead_id, field, message)."""
    valid: list[Lead] = []
    errors: list[dict] = []
    seen: set[str] = set()
    with open(path, newline="", encoding="utf-8") as f:
        for row_number, row in enumerate(csv.DictReader(f), start=2):
            lead_id = (row.get("lead_id") or "").strip()
            try:
                lead = Lead(**row)
            except ValidationError as e:
                errors += [{"row": row_number, "lead_id": lead_id, "field": str(err["loc"][0]),
                            "message": err["msg"]} for err in e.errors()]
                continue
            if lead.lead_id in seen:
                errors.append({"row": row_number, "lead_id": lead_id, "field": "lead_id",
                               "message": "duplicate lead_id"})
                continue
            seen.add(lead.lead_id)
            valid.append(lead)
    return valid, errors
