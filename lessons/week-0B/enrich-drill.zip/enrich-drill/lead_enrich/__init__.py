"""Lead Intake v2 core: validate, enrich with city data, store in SQLite."""
