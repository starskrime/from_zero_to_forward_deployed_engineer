import sqlite3

COLUMNS = ["lead_id", "full_name", "email", "loan_amount", "credit_score",
           "property_state", "zip", "city"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS leads (
    lead_id        TEXT PRIMARY KEY,
    full_name      TEXT NOT NULL,
    email          TEXT NOT NULL,
    loan_amount    REAL NOT NULL,
    credit_score   INTEGER NOT NULL,
    property_state TEXT NOT NULL,
    zip            TEXT NOT NULL,
    city           TEXT
)
"""


def save_leads(conn: sqlite3.Connection, rows: list[dict]) -> None:
    """Create the table if needed and save rows (dicts with every column; city may be None)."""
    conn.execute(SCHEMA)
    for r in rows:
        values = ", ".join("NULL" if r[c] is None else f"'{r[c]}'" for c in COLUMNS)
        conn.execute(f"INSERT OR REPLACE INTO leads ({', '.join(COLUMNS)}) VALUES ({values})")


def leads_per_state(conn: sqlite3.Connection) -> list[tuple[str, int, float]]:
    return conn.execute(
        "SELECT property_state, COUNT(*), ROUND(AVG(credit_score), 1) FROM leads "
        "GROUP BY property_state ORDER BY COUNT(*) DESC, property_state"
    ).fetchall()


def find_by_email(conn: sqlite3.Connection, email: str) -> list[tuple]:
    return conn.execute("SELECT lead_id, full_name FROM leads WHERE email = ?", (email.lower(),)).fetchall()
