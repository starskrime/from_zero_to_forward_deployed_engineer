import asyncio
import logging

import httpx

from lead_enrich.models import Lead

logger = logging.getLogger(__name__)
BASE_URL = "https://api.zippopotam.us/us/"


async def _lookup(client: httpx.AsyncClient, limit: int, zip_code: str) -> dict | None:
    sem = asyncio.Semaphore(limit)
    async with sem:
        resp = await client.get(f"{BASE_URL}{zip_code}")
    if resp.status_code == 404:
        return None
    resp.raise_for_status()
    place = resp.json()["places"][0]
    return {"city": place["place name"], "state": place["state abbreviation"]}


async def enrich_leads(leads: list[Lead], limit: int = 5,
                       transport: httpx.AsyncBaseTransport | None = None) -> tuple[dict, list[dict]]:
    """Look up each lead's ZIP concurrently (at most `limit` requests in flight).

    Returns ({lead_id: city or None}, warnings). Problems are warnings, never exceptions.
    """
    zips = sorted({lead.zip for lead in leads})
    async with httpx.AsyncClient(transport=transport, timeout=None) as client:
        results = await asyncio.gather(*(_lookup(client, limit, z) for z in zips), return_exceptions=True)
    by_zip = dict(zip(zips, results))

    cities: dict[str, str | None] = {}
    warnings: list[dict] = []
    for lead in leads:
        found = by_zip[lead.zip]
        cities[lead.lead_id] = None
        if isinstance(found, Exception):
            logger.warning("ZIP lookup for %s failed: %r", lead.zip, found)
            message = f"ZIP {lead.zip}: lookup failed ({type(found).__name__})"
        elif found is None:
            message = f"ZIP {lead.zip} not found"
        elif found["state"] != lead.property_state:
            message = f"ZIP {lead.zip} is in {found['state']}, not {lead.property_state}"
        else:
            cities[lead.lead_id] = found["city"]
            continue
        warnings.append({"lead_id": lead.lead_id, "message": message})
    return cities, warnings
