import logging
import time

import httpx

logger = logging.getLogger(__name__)
BASE_URL = "https://api.zippopotam.us/us/"


def lookup_zip(client: httpx.Client, zip_code: str, retries: int = 3,
               backoff: float = 0.5, sleep=time.sleep) -> dict | None:
    """Return {"city", "state"} for a US ZIP, or None if the ZIP doesn't exist.

    Retries failed requests with exponential backoff (honoring Retry-After on 429).
    Raises after the last attempt.
    """
    for attempt in range(1, retries + 1):
        try:
            resp = client.get(f"{BASE_URL}{zip_code}", timeout=5.0)
            if resp.status_code == 404:
                return None
            resp.raise_for_status()
            place = resp.json()["places"][0]
            return {"city": place["place name"], "state": place["state abbreviation"]}
        except (httpx.TransportError, httpx.HTTPStatusError) as e:
            status = e.response.status_code if isinstance(e, httpx.HTTPStatusError) else None
            retryable = status is None or status >= 400
            if attempt == retries or not retryable:
                raise
            wait = backoff * 2 ** (attempt - 1)
            retry_after = e.response.headers.get("Retry-After", "") if status == 429 else ""
            if retry_after.isdigit():
                wait = float(retry_after)
            logger.warning("Attempt %s for %s failed (%s); retrying in %.1fs", attempt, zip_code, e, wait)
            sleep(wait)
    return None
