"""Six of these tests fail. Each failure is a bug in lead_enrich/, not in the tests. Fix the code."""
import asyncio
import sqlite3
from collections import Counter
from pathlib import Path

import httpx
import pytest

from lead_enrich.enrich import enrich_leads
from lead_enrich.models import Lead, load_leads
from lead_enrich.store import find_by_email, leads_per_state, save_leads
from lead_enrich.zipclient import lookup_zip
from tests.fakes import SlowAPI, place_response, scripted, zip_api

DATA = Path(__file__).resolve().parent.parent / "data" / "leads_v2.csv"


def make_lead(lead_id: str, zip_code: str, state: str = "TX") -> Lead:
    return Lead(lead_id=lead_id, full_name="Test Person", email=f"{lead_id}@example.com",
                loan_amount="300000", credit_score="720", annual_income="90000", property_state=state,
                loan_type="purchase", created_at="2026-09-01", zip=zip_code)


def row(lead_id: str, state: str = "TX", score: int = 720, name: str = "Test Person", city=None) -> dict:
    return {"lead_id": lead_id, "full_name": name, "email": f"{lead_id.lower()}@example.com",
            "loan_amount": 300000.0, "credit_score": score, "property_state": state,
            "zip": "75024", "city": city}


# ---------- validation ----------

def test_sample_file_has_9_valid_and_11_invalid():
    valid, errors = load_leads(DATA)
    assert len(valid) == 9
    assert len({e["row"] for e in errors}) == 11


def test_errors_are_counted_per_field():
    _, errors = load_leads(DATA)
    assert Counter(e["field"] for e in errors) == {
        "loan_amount": 3, "credit_score": 2, "created_at": 1, "email": 1,
        "full_name": 1, "lead_id": 1, "loan_type": 1, "property_state": 1}


# ---------- the retrying client ----------

def test_lookup_found_and_missing():
    client = httpx.Client(transport=httpx.MockTransport(zip_api))
    assert lookup_zip(client, "75024") == {"city": "Plano", "state": "TX"}
    assert lookup_zip(client, "00000") is None


def test_server_error_is_retried_with_backoff():
    handler, calls = scripted(httpx.Response(503), place_response("Plano", "TX"))
    sleeps: list[float] = []
    client = httpx.Client(transport=httpx.MockTransport(handler))
    assert lookup_zip(client, "75024", sleep=sleeps.append)["city"] == "Plano"
    assert len(calls) == 2 and sleeps == [0.5]


def test_rate_limit_waits_for_retry_after():
    handler, calls = scripted(httpx.Response(429, headers={"Retry-After": "7"}), place_response("Plano", "TX"))
    sleeps: list[float] = []
    client = httpx.Client(transport=httpx.MockTransport(handler))
    assert lookup_zip(client, "75024", sleep=sleeps.append)["city"] == "Plano"
    assert sleeps == [7.0]


def test_bad_request_is_not_retried():
    handler, calls = scripted(httpx.Response(400, json={"error": "bad zip"}))
    sleeps: list[float] = []
    client = httpx.Client(transport=httpx.MockTransport(handler))
    with pytest.raises(httpx.HTTPStatusError):
        lookup_zip(client, "7502x", sleep=sleeps.append)
    assert len(calls) == 1 and sleeps == []


# ---------- concurrent enrichment ----------

def test_sample_leads_enrich_8_with_one_warning():
    valid, _ = load_leads(DATA)
    cities, warnings = asyncio.run(enrich_leads(valid, transport=httpx.MockTransport(zip_api)))
    assert sum(city is not None for city in cities.values()) == 8
    assert warnings == [{"lead_id": "L-1015", "message": "ZIP 00000 not found"}]
    assert cities["L-1019"] == "Boston"


def test_state_mismatch_is_a_warning_not_an_error():
    leads = [make_lead("L-1", "94105", state="TX")]
    cities, warnings = asyncio.run(enrich_leads(leads, transport=httpx.MockTransport(zip_api)))
    assert cities == {"L-1": None}
    assert "CA" in warnings[0]["message"]


def test_network_outage_becomes_warnings():
    def down(request):
        raise httpx.ConnectError("network is unreachable", request=request)
    leads = [make_lead("L-1", "75024"), make_lead("L-2", "78701")]
    cities, warnings = asyncio.run(enrich_leads(leads, transport=httpx.MockTransport(down)))
    assert cities == {"L-1": None, "L-2": None}
    assert [w["lead_id"] for w in warnings] == ["L-1", "L-2"]


def test_at_most_5_lookups_in_flight():
    api = SlowAPI()
    leads = [make_lead(f"L-{i}", f"{75100 + i}") for i in range(20)]
    cities, _ = asyncio.run(enrich_leads(leads, limit=5, transport=httpx.MockTransport(api)))
    assert len(cities) == 20
    assert 1 < api.peak <= 5


def test_every_lookup_has_a_timeout():
    api = SlowAPI(delay=0)
    asyncio.run(enrich_leads([make_lead("L-1", "75024")], transport=httpx.MockTransport(api)))
    assert api.timeouts and all(t is not None and None not in t.values() for t in api.timeouts)


# ---------- storage ----------

def test_leads_per_state():
    conn = sqlite3.connect(":memory:")
    save_leads(conn, [row("L-1", "TX", 700), row("L-2", "TX", 720), row("L-3", "CA", 650)])
    assert leads_per_state(conn) == [("TX", 2, 710.0), ("CA", 1, 650.0)]


def test_names_with_apostrophes_are_saved():
    conn = sqlite3.connect(":memory:")
    save_leads(conn, [row("L-1019", "MA", 684, name="Ryan O'Connor", city="Boston")])
    assert conn.execute("SELECT full_name, city FROM leads").fetchall() == [("Ryan O'Connor", "Boston")]


def test_saved_leads_survive_a_new_connection(tmp_path):
    db = tmp_path / "leads.db"
    save_leads(sqlite3.connect(db), [row("L-1"), row("L-2"), row("L-3", city="Plano")])
    assert sqlite3.connect(db).execute("SELECT COUNT(*) FROM leads").fetchone() == (3,)


def test_email_lookup_is_not_injectable():
    conn = sqlite3.connect(":memory:")
    save_leads(conn, [row("L-1"), row("L-2")])
    assert find_by_email(conn, "l-1@example.com") == [("L-1", "Test Person")]
    assert find_by_email(conn, "' OR '1'='1") == []
