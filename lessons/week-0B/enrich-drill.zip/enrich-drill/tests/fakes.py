"""A fake ZIP API for tests: no network, no API key."""
import asyncio

import httpx

PLACES = {
    "75024": ("Plano", "TX"), "73102": ("Oklahoma City", "OK"), "78701": ("Austin", "TX"),
    "30303": ("Atlanta", "GA"), "77002": ("Houston", "TX"), "75001": ("Addison", "TX"),
    "20001": ("Washington", "DC"), "02108": ("Boston", "MA"), "94105": ("San Francisco", "CA"),
}


def place_response(city: str, state: str) -> httpx.Response:
    return httpx.Response(200, json={"places": [{"place name": city, "state abbreviation": state}]})


def zip_api(request: httpx.Request) -> httpx.Response:
    """Behaves like api.zippopotam.us for the ZIPs in PLACES; 404 for anything else."""
    code = request.url.path.rsplit("/", 1)[-1]
    if code in PLACES:
        return place_response(*PLACES[code])
    return httpx.Response(404, json={})


def scripted(*responses: httpx.Response):
    """A handler that returns the given responses in order and records every request."""
    calls: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(request)
        return responses[min(len(calls), len(responses)) - 1]

    return handler, calls


class SlowAPI:
    """Async handler: every ZIP is a TX town. Tracks peak concurrency and request timeouts."""

    def __init__(self, delay: float = 0.02):
        self.delay, self.in_flight, self.peak, self.timeouts = delay, 0, 0, []

    async def __call__(self, request: httpx.Request) -> httpx.Response:
        self.timeouts.append(request.extensions.get("timeout"))
        self.in_flight += 1
        self.peak = max(self.peak, self.in_flight)
        await asyncio.sleep(self.delay)
        self.in_flight -= 1
        return place_response("Town " + request.url.path.rsplit("/", 1)[-1], "TX")
