# Break it & fix it: Week 3

This small retrieval package (BM25, hybrid fusion, reranking, metrics, chat
rewrite, LLM judge) looks fine and runs without errors. It has six bugs, each
one a mistake that shows up in real RAG II code.

    pip install rank-bm25 pydantic openai httpx pytest
    python -m pytest -q

Six tests fail. Fix the code in `kb_drill2/`, never the tests. For each bug,
write one line in `BUGS.md`: what was wrong, what a user would have seen in
production, and how you fixed it.

Everything runs offline: the vector ranking and the reranker are fakes and
the model replies are scripted, so there is no API cost.
