"""Generate an answer only from retrieved sources, with citations, or say "I don't know"."""
from pydantic import BaseModel

from kb_drill2.store import Hit

MODEL = "gpt-6-luna"
IDK = "I don't know"
INSTRUCTIONS = f"""You are Lumora's IT help desk assistant.
Answer the employee's question using ONLY the numbered sources provided and cite them by number.
If the sources do not contain the answer, set answerable to false and answer exactly: "{IDK}"."""


class Answer(BaseModel):
    answerable: bool
    answer: str
    citations: list[int]


def format_sources(hits: list[Hit]) -> str:
    return "\n\n".join(f'<source id="{i}" from="{h.metadata["source"]}">\n{h.text}\n</source>'
                       for i, h in enumerate(hits, start=1))


def answer_question(client, question: str, hits: list[Hit]) -> tuple[Answer, list[Hit]]:
    """Returns the answer and the sources it actually cited."""
    if not hits:
        return Answer(answerable=False, answer=IDK, citations=[]), []
    response = client.responses.parse(
        model=MODEL, instructions=INSTRUCTIONS, reasoning={"effort": "low"}, text_format=Answer,
        input=f"{format_sources(hits)}\n\nQuestion: {question}")
    result = response.output_parsed
    valid = [n for n in dict.fromkeys(result.citations) if 1 <= n <= len(hits)] if result else []
    if result is None or (result.answerable and not valid):     # an answer with no source is not grounded
        return Answer(answerable=False, answer=IDK, citations=[]), []
    return result.model_copy(update={"citations": valid}), [hits[n - 1] for n in valid]
