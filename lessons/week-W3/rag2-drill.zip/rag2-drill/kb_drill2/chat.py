"""Multi-turn RAG: rewrite each follow-up into a standalone search query, then retrieve and answer."""
from pydantic import BaseModel

from kb_drill2.answer import answer_question

MODEL = "gpt-6-luna"
REWRITE_INSTRUCTIONS = """Rewrite the user's latest message as one standalone search query for
Lumora's IT knowledge base. Replace pronouns and references ("it", "that", "and for a chair?")
with what they refer to in the conversation. Keep product names, codes and numbers exactly.
If the message is already standalone, return it unchanged. Do not answer the question."""


class Standalone(BaseModel):
    query: str


def rewrite(client, history: list[tuple[str, str]], message: str, turns: int = 3) -> str:
    if not history:                                   # the first message needs no rewrite: skip the call
        return message
    recent = history[:turns]
    convo = "\n".join(f"User: {u}\nAssistant: {a}" for u, a in recent)
    r = client.responses.parse(model=MODEL, instructions=REWRITE_INSTRUCTIONS, reasoning={"effort": "low"},
                               text_format=Standalone, input=f"{convo}\n\nLatest message: {message}")
    return r.output_parsed.query if r.output_parsed else message


class ChatSession:
    def __init__(self, client, searcher, k: int = 5):
        self.client, self.searcher, self.k = client, searcher, k
        self.history: list[tuple[str, str]] = []

    def ask(self, message: str):
        query = rewrite(self.client, self.history, message)
        answer, cited = answer_question(self.client, query, self.searcher.search(query, k=self.k))
        self.history.append((message, answer.answer))
        return answer, cited, query
