"""Second-stage ranking: a cross-encoder reads the question and each candidate together."""
from kb_drill2.store import Hit


def rerank(reranker, query: str, hits: list[Hit], top_n: int = 5) -> list[Hit]:
    if not hits:
        return []
    scores = reranker.scores(query, [h.text for h in hits])
    order = sorted(range(len(hits)), key=lambda i: scores[i], reverse=True)   # stable: ties keep stage-1 order
    return [Hit(hits[i].text, hits[i].metadata, round(scores[i], 4)) for i in order[:top_n]]


class RerankedSearch:
    def __init__(self, first_stage, reranker, candidates: int = 20):
        self.first_stage, self.reranker, self.candidates = first_stage, reranker, candidates

    def search(self, query: str, k: int = 5) -> list[Hit]:
        candidates = self.first_stage.search(query, k=k)
        return rerank(self.reranker, query, candidates, top_n=k)
