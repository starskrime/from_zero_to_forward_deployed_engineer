"""Hybrid search: fuse the vector and keyword rankings with Reciprocal Rank Fusion (RRF)."""
from kb_drill2.store import Hit


def rrf(rankings: list[list[Hit]], k: int = 60) -> list[Hit]:
    """Each list is best-first. A chunk scores sum(1 / (k + rank)) over the lists it appears in."""
    scores: dict[str, float] = {}
    by_id: dict[str, Hit] = {}
    for ranking in rankings:
        for rank, hit in enumerate(ranking, start=1):
            cid = hit.metadata["chunk_id"]
            scores[cid] = scores.get(cid, 0.0) + hit.score
            by_id.setdefault(cid, hit)
    order = sorted(scores, key=scores.get, reverse=True)
    return [Hit(by_id[c].text, by_id[c].metadata, scores[c]) for c in order]


class HybridSearch:
    def __init__(self, vector_search, keyword_search, candidates: int = 20):
        self.vector, self.keyword, self.candidates = vector_search, keyword_search, candidates

    def search(self, query: str, k: int = 5) -> list[Hit]:
        vector_hits = self.vector.search(query, k=self.candidates)
        keyword_hits = self.keyword.search(query, k=self.candidates)
        return rrf([vector_hits, keyword_hits])[:k]
