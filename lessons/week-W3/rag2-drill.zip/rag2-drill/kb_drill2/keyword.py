"""Keyword search with BM25: exact words, codes and ids that embeddings blur."""
from rank_bm25 import BM25Okapi

from kb_drill2.store import Hit


def tokenize(text: str) -> list[str]:
    return text.lower().split()


class KeywordIndex:
    def __init__(self, chunks: list[Hit]):
        self.chunks = chunks
        self.bm25 = BM25Okapi([tokenize(c.text) for c in chunks])

    def search(self, query: str, k: int = 5) -> list[Hit]:
        scores = self.bm25.get_scores(tokenize(query))
        ranked = sorted(range(len(self.chunks)), key=lambda i: scores[i], reverse=True)
        return [Hit(self.chunks[i].text, self.chunks[i].metadata, round(float(scores[i]), 4))
                for i in ranked[:k] if scores[i] > 0]          # a zero score shares no query word
