from dataclasses import dataclass


@dataclass
class Hit:
    text: str
    metadata: dict                                  # needs "chunk_id" and "source"
    score: float
