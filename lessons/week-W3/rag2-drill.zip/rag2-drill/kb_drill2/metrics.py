"""Retrieval metrics at the source level, and the statistics to read them honestly."""
import random


def precision_at_k(retrieved: list[str], relevant: set[str], k: int) -> float:
    top = retrieved[:k]
    return sum(s in relevant for s in top) / k          # divide by k, not by len(top)


def recall_at_k(retrieved: list[str], relevant: set[str], k: int) -> float:
    return len([s for s in retrieved[:k] if s in relevant]) / len(relevant)


def f1(p: float, r: float) -> float:
    return 0.0 if p + r == 0 else 2 * p * r / (p + r)


def reciprocal_rank(retrieved: list[str], relevant: set[str]) -> float:
    return next((1 / rank for rank, s in enumerate(retrieved, start=1) if s in relevant), 0.0)


def bootstrap_ci(values: list[float], iterations: int = 10_000, seed: int = 0) -> tuple[float, float]:
    """95% confidence interval of the mean, by resampling questions with replacement."""
    rng = random.Random(seed)
    n = len(values)
    means = sorted(sum(rng.choice(values) for _ in range(n)) / n for _ in range(iterations))
    return means[int(0.025 * iterations)], means[int(0.975 * iterations) - 1]


def paired_bootstrap(a: list[float], b: list[float], iterations: int = 10_000, seed: int = 0) -> dict:
    """Is B better than A on the SAME questions? 95% CI of mean(B - A)."""
    rng = random.Random(seed)
    n = len(a)
    diffs = [y - x for x, y in zip(a, b)]
    boots = sorted(sum(rng.choice(b) for _ in range(n)) / n - sum(rng.choice(a) for _ in range(n)) / n
                   for _ in range(iterations))
    return {"mean_diff": sum(diffs) / n, "ci": (boots[int(0.025 * iterations)], boots[int(0.975 * iterations) - 1]),
            "b_better": sum(d > 0 for d in diffs), "a_better": sum(d < 0 for d in diffs)}
