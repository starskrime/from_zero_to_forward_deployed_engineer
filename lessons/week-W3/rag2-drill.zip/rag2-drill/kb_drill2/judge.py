"""An LLM judge for one question: is every claim in the answer supported by the sources?"""
from pydantic import BaseModel

MODEL = "gpt-6-luna"
JUDGE_INSTRUCTIONS = """You grade answers from an IT help desk assistant for GROUNDEDNESS only.
An answer PASSES when every factual claim in it is stated in or directly follows from the sources.
It FAILS if even one claim is contradicted by, missing from, or broader than the sources.
Completeness and style are not your job. "I don't know" PASSES when the sources lack the answer.
First list each claim and the source text that supports it (or "none"), then decide."""


class Verdict(BaseModel):
    reasoning: str
    grounded: bool


def judge(client, question: str, sources: str, answer: str) -> Verdict:
    r = client.responses.parse(model=MODEL, instructions=JUDGE_INSTRUCTIONS, reasoning={"effort": "low"},
                               text_format=Verdict,
                               input=f"<sources>\n{sources}\n</sources>\n<question>{question}</question>\n<answer>{answer}</answer>")
    return r.output_parsed


def agreement(human: list[bool], judged: list[bool]) -> dict:
    """True = grounded (pass). The failures are what the judge exists to catch."""
    fails = [j for h, j in zip(human, judged) if not h]
    passes = [j for h, j in zip(human, judged) if h]
    return {"failures_caught": sum(not j for j in fails) / len(fails),
            "passes_kept": sum(passes) / len(passes),
            "accuracy": sum(h == j for h, j in zip(human, judged)) / len(human)}
