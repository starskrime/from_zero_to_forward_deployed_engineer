"""Six of these tests fail. Each failure is a bug in kb_drill2/, not in the tests. Fix the code."""
import json

import pytest

from kb_drill2.chat import ChatSession, rewrite
from kb_drill2.hybrid import HybridSearch
from kb_drill2.judge import agreement, judge
from kb_drill2.keyword import KeywordIndex
from kb_drill2.metrics import (bootstrap_ci, f1, paired_bootstrap, precision_at_k, recall_at_k,
                               reciprocal_rank)
from kb_drill2.rerank import RerankedSearch, rerank
from kb_drill2.store import Hit
from tests.fakes import FakeReranker, FixedSearch, message, response, scripted_client


def chunk(cid, text, score=0.0):
    return Hit(text, {"chunk_id": cid, "source": cid.split("#")[0]}, score)


TICKETS = [
    chunk("T-1001#0", "Outlook keeps asking for my password. Issue fixed by clearing saved credentials."),
    chunk("T-1004#0", "Printing on the 3rd floor in Dallas: add the queue DAL-3F-PRINT from Settings."),
    chunk("T-1009#0", "The same VPN issue again after the update. Reinstalled the client."),
    chunk("T-1018#0", "Printer driver crash on macOS. Reinstall the driver from the portal."),
    chunk("T-1022#0", "Jobs are stuck in the queue on the 2nd floor. Restarted the print spooler."),
    chunk("T-1031#0", "Same problem as T-1018: the driver crashed again after a macOS update."),
]


def ids(hits):
    return [h.metadata["chunk_id"] for h in hits]


# --- keyword search ------------------------------------------------------------------------------

def test_bm25_matches_codes_next_to_punctuation():
    index = KeywordIndex(TICKETS)
    printer = index.search("Where is the DAL-3F-PRINT queue?", k=3)
    assert [h.metadata["source"] for h in printer[:1]] == ["T-1004"]
    follow_up = index.search("any update on T-1018?", k=3)
    assert [h.metadata["source"] for h in follow_up[:1]] == ["T-1031"]


# --- hybrid search -------------------------------------------------------------------------------

def test_hybrid_fusion_uses_ranks_not_raw_scores():
    both = chunk("vpn-setup.md#2", "Install the Lumora VPN client")
    bm25_only = chunk("T-1009#0", "VPN issue again")
    vector_only = chunk("sso-and-access.md#0", "Sign in with SSO")
    vectors = FixedSearch([Hit(both.text, both.metadata, 0.82), Hit(vector_only.text, vector_only.metadata, 0.55)])
    bm25 = FixedSearch([Hit(bm25_only.text, bm25_only.metadata, 9.1), Hit(both.text, both.metadata, 7.4)])
    fused = HybridSearch(vectors, bm25).search("how do I install the vpn", k=3)
    assert ids(fused) == ["vpn-setup.md#2", "T-1009#0", "sso-and-access.md#0"]   # 1st + 2nd beats 1st alone
    assert fused[0].score == pytest.approx(1 / 61 + 1 / 62)
    assert vectors.asked_k == bm25.asked_k == 20                                 # both lists are candidates


# --- metrics and statistics ----------------------------------------------------------------------

def test_precision_mrr_f1_by_hand():
    got = ["x", "A", "x", "B", "x"]
    assert precision_at_k(got, {"A", "B", "C"}, 5) == 0.4
    assert precision_at_k(["A"], {"A"}, 5) == 0.2                 # fewer than k results still divides by k
    assert reciprocal_rank(got, {"B"}) == 0.25 and reciprocal_rank(got, {"C"}) == 0.0
    assert f1(0.4, 2 / 3) == pytest.approx(0.5)


def test_recall_counts_distinct_sources():
    assert recall_at_k(["x", "A", "x", "B", "x"], {"A", "B", "C"}, 5) == pytest.approx(2 / 3)
    # one article split into three chunks, all in the top 5: it is still ONE of the two relevant sources
    got = ["vpn-setup.md", "vpn-setup.md", "vpn-setup.md", "password-policy.md", "T-1009"]
    assert recall_at_k(got, {"vpn-setup.md", "sso-and-access.md"}, 5) == 0.5


def test_bootstrap_ci_is_wide_on_a_small_eval_set():
    lo, hi = bootstrap_ci([1.0] * 24 + [0.0] * 8, iterations=2000)
    assert lo < 0.75 < hi and hi - lo > 0.25                      # 32 questions: +/- about 15 points


def test_paired_bootstrap_keeps_questions_paired():
    a = [1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.5, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.5, 1.0, 1.0]
    same = paired_bootstrap(a, list(a), iterations=2000)
    assert same["mean_diff"] == 0 and same["ci"] == (0.0, 0.0)    # identical systems: no difference at all
    better = paired_bootstrap(a, [x + 0.1 for x in a], iterations=2000)
    assert better["ci"] == pytest.approx((0.1, 0.1)) and better["b_better"] == len(a)


# --- reranking -----------------------------------------------------------------------------------

def test_rerank_orders_by_reranker_and_cuts_to_top_n():
    hits = [chunk("a#0", "vpn gateway list", 0.9), chunk("b#0", "dallas printer queue", 0.8),
            chunk("c#0", "printer driver", 0.7)]
    out = rerank(FakeReranker(), "dallas printer", hits, top_n=2)
    assert ids(out) == ["b#0", "c#0"] and [h.score for h in out] == [2.0, 1.0]
    assert rerank(FakeReranker(), "q", []) == []


def test_reranker_can_rescue_a_chunk_ranked_twelfth():
    noise = [chunk(f"T-{2000 + i}#0", f"unrelated ticket number {i}") for i in range(20)]
    target = chunk("remote-work-equipment-policy.pdf#3", "Home office chair allowance: up to $350 every 5 years.")
    first_stage = FixedSearch(noise[:11] + [target] + noise[11:19])       # stage 1 ranks it 12th of 20
    top = RerankedSearch(first_stage, FakeReranker(), candidates=20).search("chair allowance", k=5)
    assert first_stage.asked_k == 20
    assert top[0].metadata["source"] == "remote-work-equipment-policy.pdf"


# --- multi-turn RAG ------------------------------------------------------------------------------

def test_rewrite_sends_the_latest_turns():
    history = [("How do I set up the VPN?", "Install the Lumora VPN client."),
               ("Which VPN client version?", "Version 5.2 or later."),
               ("How often do passwords expire?", "Every 90 days."),
               ("Which printer queue in Dallas?", "DAL-3F-PRINT."),
               ("What's the monitor allowance?", "$400 every 4 years.")]
    reqs = []
    client = scripted_client([response([message('{"query": "desk chair allowance for remote workers"}')])], reqs)
    assert rewrite(client, history, "And for a chair?") == "desk chair allowance for remote workers"
    sent = reqs[0]["input"]
    assert "monitor allowance" in sent and "And for a chair?" in sent
    assert "VPN" not in sent                                      # only the last 3 turns are sent


def test_chat_session_rewrites_follow_ups_only():
    searched = []

    class Spy:
        def search(self, query, k):
            searched.append(query)
            return [chunk("remote-work-equipment-policy.pdf#3", "Monitor: $400. Chair: $350.")]

    replies = [response([message('{"answerable": true, "answer": "Up to $400.", "citations": [1]}')]),
               response([message('{"query": "desk chair allowance"}')]),
               response([message('{"answerable": true, "answer": "$350.", "citations": [1]}')])]
    session = ChatSession(scripted_client(replies), Spy())
    session.ask("What's the monitor allowance?")                   # first turn: no rewrite call
    answer, cited, query = session.ask("And for a chair?")
    assert searched == ["What's the monitor allowance?", "desk chair allowance"]
    assert answer.answer == "$350." and cited[0].metadata["source"] == "remote-work-equipment-policy.pdf"


# --- LLM judge -----------------------------------------------------------------------------------

def test_judge_reads_sources_and_returns_a_verdict():
    reqs = []
    verdict = {"reasoning": "Claim '$500' has no support; the source says $350.", "grounded": False}
    client = scripted_client([response([message(json.dumps(verdict))])], reqs)
    v = judge(client, "Chair allowance?", "Chair: $350 every 5 years.", "You get $500.")
    assert v.grounded is False
    assert "<sources>\nChair: $350 every 5 years.\n</sources>" in reqs[0]["input"]
    assert reqs[0]["text"]["format"]["name"] == "Verdict"


def test_judge_agreement_by_hand():
    human = [True, True, False, False, False]
    judged = [True, False, False, True, False]
    r = agreement(human, judged)
    assert r["failures_caught"] == pytest.approx(2 / 3) and r["passes_kept"] == 0.5 and r["accuracy"] == 0.6
