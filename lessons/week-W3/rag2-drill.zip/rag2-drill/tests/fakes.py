"""Offline stand-ins: scripted Responses API replies, a word-overlap reranker, fixed rankings."""
import itertools
import json
import re

import httpx
from openai import OpenAI

_ids = itertools.count(1)
USAGE = {"input_tokens": 100, "output_tokens": 20, "total_tokens": 120,
         "input_tokens_details": {"cached_tokens": 0}, "output_tokens_details": {"reasoning_tokens": 0}}


def response(output: list) -> dict:
    return {"id": f"resp_{next(_ids)}", "object": "response", "created_at": 0, "model": "gpt-6-luna",
            "status": "completed", "output": output, "usage": USAGE,
            "parallel_tool_calls": True, "tool_choice": "auto", "tools": []}


def message(text: str) -> dict:
    return {"type": "message", "id": f"msg_{next(_ids)}", "status": "completed", "role": "assistant",
            "content": [{"type": "output_text", "text": text, "annotations": []}]}


def scripted_client(replies: list[dict], requests: list | None = None) -> OpenAI:
    """Each API call gets the next reply from the list; request bodies are saved for assertions."""
    queue = list(replies)

    def handler(request: httpx.Request) -> httpx.Response:
        if requests is not None:
            requests.append(json.loads(request.content))
        return httpx.Response(200, json=queue.pop(0))

    return OpenAI(api_key="test", http_client=httpx.Client(transport=httpx.MockTransport(handler)))


class FakeReranker:
    """Stands in for a cross-encoder: counts distinct query words found in the text."""

    def scores(self, query: str, texts: list[str]) -> list[float]:
        words = set(re.findall(r"\w+", query.lower()))
        return [float(len(words & set(re.findall(r"\w+", t.lower())))) for t in texts]


class FixedSearch:
    """A first-stage searcher that always returns the same best-first ranking; records the k it was asked for."""

    def __init__(self, hits):
        self.hits, self.asked_k = hits, None

    def search(self, query: str, k: int = 5):
        self.asked_k = k
        return self.hits[:k]
