Lumora evaluation data (Week 3). Fictional, for a learning exercise.

eval-set.json        40 questions. "relevant": the sources (file names or ticket ids) that
                     answer each one; empty for the 8 unanswerable questions.
                     "answer_contains": a fact the answer must include ("I don't know" for
                     unanswerable ones). "category": keyword, paraphrase, multi or unanswerable.
                     e01-e15 are Week 2's check questions.
conversations.json   6 two-turn conversations for checking follow-up handling.
labeled-answers.json 24 answers graded by a human for groundedness (every claim supported
                     by the given sources). Split: train (4, for prompt examples), dev (10, for
                     improving your judge), test (10, run once for the number you report).
