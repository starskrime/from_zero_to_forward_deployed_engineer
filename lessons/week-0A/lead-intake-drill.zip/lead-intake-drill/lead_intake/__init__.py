"""Lead Intake: validate a nightly CSV of mortgage leads and write JSON reports."""
