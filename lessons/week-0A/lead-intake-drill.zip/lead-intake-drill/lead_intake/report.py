"""Build report.json from validation results."""


def count_errors_by_field(results: list[dict]) -> dict[str, int]:
    """How many errors each field has across the whole file."""
    counts: dict[str, int] = {}
    for result in results:
        for error in result["errors"]:
            field = error["field"]
            if field not in counts:
                counts[field] = 1
            counts[field] += 1
    return counts


def build_report(results: list[dict], input_file: str, run_at: str) -> dict:
    valid = sum(1 for r in results if r["lead"] is not None)
    return {
        "run_at": run_at,
        "input_file": input_file,
        "total_rows": len(results),
        "valid_rows": valid,
        "invalid_rows": len(results) - valid,
        "errors_by_field": count_errors_by_field(results),
        "errors": [{"row": r["row"], "lead_id": r["lead_id"], **e}
                   for r in results for e in r["errors"]],
    }
