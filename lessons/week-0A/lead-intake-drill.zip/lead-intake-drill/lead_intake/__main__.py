import sys

from lead_intake.cli import main

sys.exit(main())
