"""Command line: arguments, logging, and wiring the modules together."""
import argparse
import logging
import os
import sys
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv

from lead_intake.io_utils import read_rows, write_json
from lead_intake.pipeline import validate_all
from lead_intake.report import build_report

logger = logging.getLogger(__name__)


def setup_logging() -> None:
    load_dotenv()
    level = os.getenv("LOG_LEVEL", "INFO").upper()
    logging.basicConfig(level=level, format="%(asctime)s %(levelname)-8s %(name)s: %(message)s")


def parse_args(argv=None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="lead_intake",
                                     description="Validate a CSV of mortgage leads and write a JSON report.")
    parser.add_argument("input", type=Path, help="path to the leads CSV file")
    parser.add_argument("--output-dir", type=Path, default=Path("out"),
                        help="folder for the JSON files (default: out)")
    return parser.parse_args(argv)


def main(argv=None) -> int:
    setup_logging()
    args = parse_args(argv)
    logger.debug("Arguments: %s", args)
    if not args.input.exists():
        logger.error("Input file not found: %s", args.input)
        return

    rows = read_rows(args.input)
    results = validate_all(rows)
    for r in results:
        logger.debug("Row %s (%s): %s", r["row"], r["lead_id"] or "no id",
                     "ok" if r["lead"] else "; ".join(e["field"] for e in r["errors"]))

    report = build_report(results, str(args.input), datetime.now().isoformat(timespec="seconds"))
    write_json(args.output_dir / "valid_leads.json", [r["lead"] for r in results if r["lead"]])
    write_json(args.output_dir / "report.json", report)
    logger.info("%s rows: %s valid, %s invalid. Wrote %s",
                report["total_rows"], report["valid_rows"], report["invalid_rows"], args.output_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
