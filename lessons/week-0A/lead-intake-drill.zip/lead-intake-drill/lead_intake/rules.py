"""Reference data the validation rules depend on."""
from pathlib import Path

STATES_FILE = Path("lead_intake") / "us_states.txt"


def load_us_states(path: Path = STATES_FILE) -> set[str]:
    """Return the set of valid property_state codes (50 states + DC)."""
    lines = Path(path).read_text(encoding="utf-8").splitlines()
    return {line.strip() for line in lines if line.strip() and not line.startswith("#")}
