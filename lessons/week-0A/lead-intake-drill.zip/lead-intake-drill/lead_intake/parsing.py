"""Turning text cells into typed values. Every function raises ValueError with a clear message."""
import math
import re
from datetime import date

_ISO_DATE = re.compile(r"(\d{4})-(\d{2})-(\d{2})")


def parse_number(raw: str, kind=float, low=None, high=None, low_inclusive=True):
    """Convert raw text to kind (int or float) and range-check it."""
    raw = raw.strip()
    if raw == "":
        raise ValueError("missing")
    try:
        value = kind(raw)
    except ValueError:
        raise ValueError(f"{raw!r} is not a {'whole number' if kind is int else 'number'}") from None
    if not math.isfinite(value):  # float() accepts "nan" and "inf"
        raise ValueError(f"{raw!r} is not a number")
    if low is not None and (value < low or (value == low and not low_inclusive)):
        raise ValueError(f"{raw} is too small")
    if high is not None and value > high:
        raise ValueError(f"{raw} is too large")
    return value


def parse_date(raw: str) -> str:
    """Accept only a real calendar date written as YYYY-MM-DD; return it in ISO form."""
    raw = raw.strip()
    m = _ISO_DATE.fullmatch(raw)
    if not m:
        raise ValueError(f"{raw!r} is not a YYYY-MM-DD date")
    year, month, day = (int(part) for part in m.groups())
    last_day = 30 if month in (4, 6, 9, 11) else 31
    if not (1 <= month <= 12 and 1 <= day <= last_day):
        raise ValueError(f"{raw} is not a real calendar date")
    return raw
