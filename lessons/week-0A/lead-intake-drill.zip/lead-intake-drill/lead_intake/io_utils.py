"""Reading the CSV export and writing JSON files."""
import csv
import json
from pathlib import Path


def read_rows(path: Path) -> list[tuple[int, dict]]:
    """Return (row_number, row) pairs. Row numbers match a spreadsheet: the header is line 1."""
    with Path(path).open(newline="", encoding="utf-8") as f:
        return list(enumerate(csv.DictReader(f), start=2))


def write_json(path: Path, data) -> None:
    """Write data as indented JSON, creating the folder if needed."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
