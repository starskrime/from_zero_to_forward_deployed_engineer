"""Business rules for one lead row."""
from lead_intake.parsing import parse_date, parse_number
from lead_intake.rules import load_us_states

US_STATES = load_us_states()
LOAN_TYPES = {"purchase", "refinance"}


def validate_row(row: dict, is_duplicate: bool = False) -> tuple[dict | None, list[dict]]:
    """Check every field of one row. Return (lead, []) if valid, else (None, errors)."""
    errors: list[dict] = []
    lead: dict = {}

    def fail(field: str, message: str) -> None:
        errors.append({"field": field, "message": message})

    lead_id = row.get("lead_id", "").strip()
    if lead_id == "":
        fail("lead_id", "missing")
    elif is_duplicate:
        fail("lead_id", f"duplicate of an earlier row ({lead_id})")
    else:
        lead["lead_id"] = lead_id

    full_name = row.get("full_name", "").strip()
    if full_name == "":
        fail("full_name", "missing")
    else:
        lead["full_name"] = full_name

    email = row.get("email", "").strip().lower()
    local, at, domain = email.partition("@")
    if not (local and at and "." in domain):
        fail("email", f"{email!r} is not a valid email address")
    else:
        lead["email"] = email

    numeric = [
        ("loan_amount", float, 0, 5_000_000, False),
        ("credit_score", int, 300, 850, True),
        ("annual_income", float, 0, None, True),
    ]
    for field, kind, low, high, low_inclusive in numeric:
        try:
            lead[field] = parse_number(row.get(field, ""), kind, low, high, low_inclusive)
        except ValueError as e:
            fail(field, str(e))

    state = row.get("property_state", "").upper()
    if state not in US_STATES:
        fail("property_state", f"{state!r} is not a US state code")
    else:
        lead["property_state"] = state

    loan_type = row.get("loan_type", "").strip().lower()
    if loan_type not in LOAN_TYPES:
        fail("loan_type", f"{loan_type!r} must be purchase or refinance")
    else:
        lead["loan_type"] = loan_type

    try:
        lead["created_at"] = parse_date(row.get("created_at", ""))
    except ValueError as e:
        fail("created_at", str(e))

    return (lead if not errors else None), errors
