"""Validate a whole file: duplicates across rows, then each row."""
from lead_intake.validation import validate_row


def find_duplicate_rows(rows: list[tuple[int, dict]]) -> set[int]:
    """Row numbers whose lead_id already appeared on an EARLIER row (the first one stays valid)."""
    first_row = {row["lead_id"].strip(): row_number for row_number, row in rows
                 if row.get("lead_id", "").strip()}
    return {n for n, row in rows
            if row.get("lead_id", "").strip() and first_row[row["lead_id"].strip()] != n}


def validate_all(rows: list[tuple[int, dict]]) -> list[dict]:
    """Return one result per row: {"row", "lead_id", "lead", "errors"}."""
    duplicates = find_duplicate_rows(rows)
    results = []
    for row_number, row in rows:
        lead, errors = validate_row(row, is_duplicate=row_number in duplicates)
        results.append({"row": row_number, "lead_id": row.get("lead_id", "").strip(),
                        "lead": lead, "errors": errors})
    return results
