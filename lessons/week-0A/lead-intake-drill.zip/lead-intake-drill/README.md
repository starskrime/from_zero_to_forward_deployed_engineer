# Break it & fix it: Week 0A

This is a small Lead Intake CLI, the same shape as your weekend project. It runs,
prints a tidy summary and exits 0. It has six bugs, each one a mistake that shows
up in real data-validation code: in paths, parsing, validation, duplicate
detection, counting and exit codes.

    python3 -m venv .venv && source .venv/bin/activate
    pip install python-dotenv pytest
    python -m pytest -q

Six tests fail. Fix the code in `lead_intake/`, never the tests. For each bug,
write one line in `BUGS.md`: what was wrong, what a user would have seen in
production, and how you fixed it.

Run everything from this folder (the one that contains `lead_intake/`). You can
also run the tool itself:

    python -m lead_intake data/leads_sample.csv --output-dir out

Everything runs offline in well under a second. No accounts, no API keys.
