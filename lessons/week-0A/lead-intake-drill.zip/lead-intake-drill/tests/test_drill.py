"""Six of these tests fail. Each failure is a bug in lead_intake/, not in the tests. Fix the code."""
import json
from pathlib import Path

import pytest

from lead_intake.cli import main
from lead_intake.io_utils import read_rows
from lead_intake.parsing import parse_date, parse_number
from lead_intake.pipeline import validate_all
from lead_intake.rules import load_us_states
from lead_intake.validation import validate_row

ROOT = Path(__file__).resolve().parent.parent
SAMPLE = ROOT / "data" / "leads_sample.csv"

GOOD = {"lead_id": "L-1", "full_name": "Maria Gonzalez", "email": "maria@example.com",
        "loan_amount": "385000", "credit_score": "742", "annual_income": "118000",
        "property_state": "TX", "loan_type": "purchase", "created_at": "2026-09-01"}


def test_sample_report_numbers(tmp_path):
    assert main([str(SAMPLE), "--output-dir", str(tmp_path)]) == 0
    report = json.loads((tmp_path / "report.json").read_text())
    assert (report["total_rows"], report["valid_rows"], report["invalid_rows"]) == (20, 9, 11)
    assert report["errors_by_field"] == {
        "loan_amount": 3, "credit_score": 2, "lead_id": 1, "full_name": 1,
        "email": 1, "property_state": 1, "loan_type": 1, "created_at": 1}


def test_sample_errors_point_to_the_right_rows():
    results = validate_all(read_rows(SAMPLE))
    found = [(r["row"], r["lead_id"], e["field"]) for r in results for e in r["errors"]]
    assert found == [
        (4, "L-1003", "email"), (5, "L-1004", "loan_amount"), (6, "L-1005", "credit_score"),
        (7, "L-1006", "full_name"), (9, "L-1008", "property_state"), (11, "L-1010", "loan_type"),
        (12, "L-1011", "created_at"), (13, "L-1012", "credit_score"), (14, "L-1013", "loan_amount"),
        (16, "L-1007", "lead_id"), (19, "L-1017", "loan_amount")]


def test_valid_lead_is_typed():
    lead, errors = validate_row(GOOD)
    assert errors == []
    assert lead["credit_score"] == 742 and isinstance(lead["credit_score"], int)
    assert lead["loan_amount"] == 385000.0 and isinstance(lead["loan_amount"], float)


def test_padded_and_mixed_case_values_are_cleaned():
    messy = {k: f"  {v}  " for k, v in GOOD.items()}
    messy.update(email=" Maria@Example.COM ", property_state=" tx ", loan_type="Purchase ")
    lead, errors = validate_row(messy)
    assert errors == []
    assert (lead["lead_id"], lead["email"], lead["property_state"], lead["loan_type"]) == \
        ("L-1", "maria@example.com", "TX", "purchase")


def test_numbers_reject_what_int_and_float_reject():
    assert parse_number(" 742 ", int, 300, 850) == 742
    for raw in ["7.5", "", "three", "nan"]:
        with pytest.raises(ValueError):
            parse_number(raw, int if raw == "7.5" else float, 0, 5_000_000)


def test_dates_must_exist_on_the_calendar():
    assert parse_date("2028-02-29") == "2028-02-29"          # leap year
    for raw in ["2026-09-31", "2026-02-29", "2026-02-30", "2026-13-01", "09/01/2026", "20260901"]:
        with pytest.raises(ValueError):
            parse_date(raw)


def test_state_list_loads_from_any_working_folder(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)          # like cron, CI, or running from your home folder
    states = load_us_states()
    assert len(states) == 51 and "DC" in states


def test_missing_input_file_exits_1(tmp_path):
    assert main([str(tmp_path / "nope.csv"), "--output-dir", str(tmp_path)]) == 1


def test_help_exits_0(capsys):
    with pytest.raises(SystemExit) as exc:
        main(["--help"])
    assert exc.value.code == 0
    assert "usage: lead_intake" in capsys.readouterr().out
