# Lead Intake CLI: project pack (Week 0A weekend)

Everything you need for the weekend project, except the code. You write all of
the code yourself, in your own repo (`code/lead-intake/`). There is no solution
in this pack.

## What's inside

| File | What it is |
|---|---|
| `BRIEF.md` | The ticket from the sales-ops lead: the problem, who uses the outputs, acceptance criteria. Read it first. |
| `SPEC.md` | The exact contract: input format, every rule, what gets normalized or rejected, error messages, both JSON outputs, log lines, exit codes. |
| `data/leads_sample.csv` | The 20-row sample from the lesson (same file as Exercise 3). |
| `data/leads_2026-10-02.csv` | Last night's real-looking export: 250 leads, saved by Excel, with blank lines, cut-off rows and other mess. All people are fictional. |
| `expected/*.expected.json` | For each data file: the counts, `errors_by_field`, and every expected error as `(row, lead_id, field)`. |
| `expected/*.valid_leads.json` | For each data file: the exact `valid_leads.json` a correct tool writes. |
| `check_my_work.py` | Runs your CLI on both files and prints PASS or FAIL for each acceptance check. |

## How to use it with the lesson

1. Unzip this pack into `code/week-0A/`, so you get
   `code/week-0A/lead-intake-project/`.
2. Copy both CSV files into your project's `data/` folder
   (`code/lead-intake/data/`). `leads_sample.csv` is probably there already.
3. Read `BRIEF.md`, then `SPEC.md`. Keep `SPEC.md` open while you build.
4. Build in the order the lesson gives, committing after each step. Check your
   numbers against `expected/` as you go.
5. When the sample file gives 20 / 9 / 11, run the checker from your project root
   with your venv active:

       cd code/lead-intake
       python ../week-0A/lead-intake-project/check_my_work.py

   If you'd rather copy `check_my_work.py` into your project, pass the pack
   folder: `python check_my_work.py ../week-0A/lead-intake-project`.

The checker runs `python -m lead_intake <file> --output-dir <temp folder>` on both
data files, with `LOG_LEVEL` set to INFO or DEBUG. It never reads your code; it only
runs it and reads its output. It compares rows and fields, never message text. It
exits 0 only when every required check passes. `--strict` is reported as
OPTIONAL, because it's a stretch goal.

Don't edit `expected/` to make a check pass. If you think an expected answer is
wrong, re-read the rule in `SPEC.md`, run with `LOG_LEVEL=DEBUG` and look at that
row. Finding the difference is the skill being trained.

Don't commit this pack into your project repo; it's reference material.
