# SALESOPS-412 · Stop losing a day of leads to one bad row

**Filed by:** Dana Whitfield, Sales Operations Lead, Prairie Home Lending (fictional)
**Assigned to:** you (engineering)
**Filed:** Friday, October 2, 2026
**Priority:** High
**Needed by:** Monday morning stand-up, so Monday night's import can use it

---

## What's going on

Every night at 1 a.m. our website exports the day's new mortgage leads as a CSV
file. At 6 a.m. the CRM imports it, and the loan officers start calling people
at 8.

The CRM import is all-or-nothing. If a single row is bad (a typo in an email,
a credit score of 905, a date like September 31) it rejects the **whole file**.
Nobody notices until the loan officers ask why their call list is empty. By
then the leads are a day old, and a mortgage lead that waits a day often goes
to another lender.

This happened three times in September. Last night's file
(`data/leads_2026-10-02.csv`, attached) has 250 leads, and I already know it
has problems: someone opened it in Excel and re-saved it, a few rows look cut
off, and the web form let some "home-equity" requests through even though we
don't offer that product yet.

## What I need

A small command-line tool that our scheduler can run before the CRM import:

1. It reads the nightly CSV.
2. It checks every lead against our rules (the rules are in `SPEC.md`).
3. It writes the **good leads** to a clean file the CRM can import.
4. It writes a **report** that tells the web team exactly what to fix: which
   row, which lead, which field, and what's wrong with it.
5. It never crashes because of a bad row. Bad rows go in the report; good rows
   still get imported.

## Who uses the outputs

| Output | Who reads it | What they do with it |
|---|---|---|
| `valid_leads.json` | The CRM import (6 a.m.) | Loads the leads into the loan officers' call lists |
| `report.json` | Priya on the web team | Fixes the form and the bad records at the source |
| Exit code | The scheduler | Decides whether to run the CRM import, and pages someone if the tool failed |
| Log lines | Whoever is on call | Sees at a glance what happened, without opening any files |

The web team will read the report every morning, so the messages need to be
plain English. The CRM is picky about types: credit scores must be whole
numbers, amounts must be numbers (not text), and emails must be lowercase.

## Acceptance criteria

- [ ] `python -m lead_intake data/leads_sample.csv --output-dir out` works,
      as described in `SPEC.md`.
- [ ] On the sample file: 20 rows, 9 valid, 11 invalid, with the error counts
      listed in `expected/`.
- [ ] On last night's file it gives the counts and the errors listed in
      `expected/`, including the rows Excel and the cut-off export messed up.
- [ ] Every bad row is reported with its row number (the line number we see
      when we open the file in a text editor), its lead ID, the field and a
      clear message. A row with two problems shows both.
- [ ] If the input file is missing, the tool logs an error and exits with
      code 1, so the scheduler does **not** run the CRM import on stale data.
- [ ] A run with bad rows still exits 0: the run worked, and the report
      explains the bad rows.
- [ ] Turning on detailed logs (`LOG_LEVEL=DEBUG`) shows one line per row,
      without changing any code.

## Definition of done

- `check_my_work.py` (in this pack) prints **ALL REQUIRED CHECKS PASS**.
- The code is on GitHub in a private repo, with a README a new teammate can
  follow from a fresh clone.
- No secrets, virtual environments or output files are committed.

## Nice to have (not this week)

- A `--strict` switch that exits with code 2 if any row is invalid, so our
  test pipeline can fail loudly.
- The errors as `errors.csv` too, because the web team lives in spreadsheets.

## Out of scope

Talking to the CRM, sending emails, or fixing the bad rows automatically. Just
tell us what's wrong; the web team will fix it at the source.

Thanks! Ping me on Slack if a rule is unclear. I'd rather answer a question
on Saturday than find a surprise on Monday.

Dana
