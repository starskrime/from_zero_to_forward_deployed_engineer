# Lead Intake CLI: specification

This is the exact contract for the tool in `BRIEF.md`. Where the lesson page and
this file differ in detail, this file wins. `check_my_work.py` tests what is
written here.

Command:

    python -m lead_intake data/leads_sample.csv --output-dir out

---

## 1. The input file

- A CSV file encoded as **UTF-8**, with a **header row** on line 1:

      lead_id,full_name,email,loan_amount,credit_score,annual_income,property_state,loan_type,created_at

- The file **may start with an Excel byte order mark (BOM)**. Excel's "CSV UTF-8"
  format adds an invisible character (U+FEFF) before the first header, so
  `row["lead_id"]` fails or comes back empty. Open the file with
  `encoding="utf-8-sig"`: it removes the mark when it's there and reads normally
  when it isn't. (`.strip()` does **not** remove it.) The nightly file has a BOM;
  the sample file doesn't.
- Lines may end with `\n` or `\r\n`. Open the file with `newline=""`, as the csv
  docs require, and let the `csv` module handle both.
- Values that contain a comma are quoted, for example `"$385,000"`. The `csv`
  module removes the quotes; the value is then `$385,000`, which is rejected
  (section 4).

## 2. Rows, blank lines and row numbers

- Every line after the header is one **row**, except **blank lines**.
- **Blank lines** (completely empty lines) are **skipped**: they are not rows,
  are not counted in `total_rows` and get no error. `csv.DictReader` already
  skips them for you.
- A row's **row number** is its **line number in the file**, counting the header
  as line 1, exactly what a person sees in a text editor. Blank lines still
  count as lines, so after a blank line the row numbers jump by one.
  - In a file without blank lines, `enumerate(reader, start=2)` gives the right
    numbers. With blank lines it drifts. Use `reader.line_num` (the line the
    reader just finished) instead: it is right in both cases.
  - In the sample file, `L-1003` is row **4**. In the nightly file, `L-2034` is
    row **36** (line 32 is blank).

## 3. Row shape: the wrong number of values

A good row has exactly **9 values**. Exports get cut off, and people add notes in
an extra column. With `csv.DictReader`:

- a **short** row gives `None` (not `""`) for the missing values;
- a **long** row puts the extra values in a list under the key `None`.

Rule: if a row doesn't have exactly 9 values, record **one** error with the field
name **`columns`** and the message `expected 9 values, found N`, and **don't check
anything else** in that row (its values may be in the wrong columns). Such a row
is invalid, and its `lead_id` is **not** recorded for duplicate checks.

## 4. Field rules

Apply these steps to every row of the right shape:

1. **Trim** every value (`.strip()`): leading and trailing spaces are never an error.
2. Check **every** field, in column order, and collect **all** of a row's errors
   (at most one error per field). Don't stop at the first problem.
3. A row is **valid** only if it has zero errors.
4. **Empty** after trimming means the error `missing`, for every field.

| Field | Valid when (after trimming) | Normalize to | Store as |
|---|---|---|---|
| `lead_id` | not empty, and not already seen on an earlier row | as is | `str` |
| `full_name` | not empty | as is (trimmed) | `str` |
| `email` | contains `@`, and the part after the first `@` contains a `.` | lowercase | `str` |
| `loan_amount` | `float()` accepts it, it's finite, `> 0` and `<= 5,000,000` | | `float` |
| `credit_score` | `int()` accepts it, and `300 <= score <= 850` | | `int` |
| `annual_income` | `float()` accepts it, it's finite, and `>= 0` | | `float` |
| `property_state` | after uppercasing, one of the 50 state codes or `DC` | uppercase | `str` |
| `loan_type` | after lowercasing, `purchase` or `refinance` | lowercase | `str` |
| `created_at` | written exactly `YYYY-MM-DD` (4, 2 and 2 digits) **and** a real calendar date | as is | `str` (ISO) |

State codes: AL AK AZ AR CA CO CT DE FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN
MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY,
plus DC. Territories such as `PR` are rejected.

### Duplicates

- IDs are compared **after trimming** and are case-sensitive: `" L-2121"` is a
  duplicate of `L-2121`.
- The **first** row with an ID is checked normally. **Every later** row with the
  same ID gets a `lead_id` error. The later row's other fields are still checked.
- An ID counts as seen from the first row (of the right shape) where it appears,
  whether or not that row turned out valid.

### Error messages

Each error in `report.json` has a `field` and a `message`. Use these messages.
`X` is the value **after trimming, before any case change**. (`check_my_work.py`
compares rows and fields, not message text, but the web team reads these.)

| Field | Condition | Message |
|---|---|---|
| `columns` | not exactly 9 values | `expected 9 values, found N` |
| any field | empty after trimming | `missing` |
| `lead_id` | ID already seen on an earlier row | `duplicate of an earlier row` |
| `email` | no `@`, or no `.` after the first `@` | `not a valid email address: X` |
| `loan_amount` | `float()` fails, or the value is NaN/infinite | `not a number: X` |
| `loan_amount` | 0 or less | `must be greater than 0: X` |
| `loan_amount` | more than 5,000,000 | `must be at most 5,000,000: X` |
| `credit_score` | `int()` fails | `not a whole number: X` |
| `credit_score` | below 300 or above 850 | `outside 300-850: X` |
| `annual_income` | `float()` fails, or the value is NaN/infinite | `not a number: X` |
| `annual_income` | below 0 | `must be 0 or more: X` |
| `property_state` | not a state code or DC | `not a US state code: X` |
| `loan_type` | not purchase or refinance | `must be purchase or refinance: X` |
| `created_at` | not written as `YYYY-MM-DD` | `not a YYYY-MM-DD date: X` |
| `created_at` | right shape, but not a real date | `not a real calendar date: X` |

### Messy input: normalize or reject?

The rule of thumb: **trim and fix letter case; never guess at numbers or dates.**
If the web team typed something the CRM can't trust, report it.

| Messy input (examples from the files) | Result | Why |
|---|---|---|
| `  Isabel Ortiz `, ` L-2053 `, ` 410000 ` | **Normalize**: trim | Spaces carry no meaning |
| `MEI.LINDQVIST@EXAMPLE.COM`, `Omar.Sato@Example.COM` | **Normalize**: lowercase | Email addresses are compared lowercase |
| `tx`, `dc`, ` Tx ` | **Normalize**: trim + uppercase | Same state, different typing |
| `Purchase`, `REFINANCE` | **Normalize**: lowercase | Same product, different typing |
| `289999.99` (loan amount) | **Valid** | A number |
| `5000000` (loan amount), `300` and `850` (score), `0` (income) | **Valid** | The limits are inclusive |
| File starts with a BOM | **Handle**: `utf-8-sig` | It's how Excel saves CSV |
| Blank line | **Skip**: not a row | Section 2 |
| `$385,000`, `1,200,000`, `350k`, `N/A` | **Reject**: `not a number` | Guessing at money is how bad loans happen |
| `0`, `-125000` (loan amount) | **Reject**: `must be greater than 0` | |
| `5250000`, `7500000` (loan amount) | **Reject**: `must be at most 5,000,000` | Above our product limit |
| `742.5`, `7OO` (letter O) (score) | **Reject**: `not a whole number` | Scores are whole numbers |
| `905`, `880`, `250`, `0` (score) | **Reject**: `outside 300-850` | |
| `-1` (income) | **Reject**: `must be 0 or more` | |
| empty or spaces-only name, empty ID, empty income | **Reject**: `missing` | |
| `arjun.moreau@examplecom`, `ingrid.walker.example.com`, `nadia.cruz@` | **Reject**: email | No dot after the `@`, or no `@` |
| `Texas`, `PR`, `zz` (state) | **Reject**: `not a US state code` | Codes only; no territories |
| `home-equity`, `HELOC` (loan type) | **Reject**: loan type | We don't offer it yet |
| `2026-02-30`, `2026-13-01`, `2026-02-29`, `2026-09-31` | **Reject**: `not a real calendar date` | 2026 isn't a leap year |
| `10/01/2026` | **Reject**: `not a YYYY-MM-DD date` | The format is fixed |
| Second (or later) row with the same `lead_id` | **Reject**: `duplicate of an earlier row` | The first one is kept |
| Row cut off after 5 values; row with a 10th "notes" value | **Reject**: `columns` | Section 3 |

Python details you may hit: `float()` also accepts `nan`, `inf`, `1e5` and `1_000`,
and `int()` accepts `+742`. NaN and infinity must be rejected (`not a number`); the
others are accepted. Neither data file contains any of them. On Python 3.11+,
`date.fromisoformat()` also accepts `20260901`, which is why the
`YYYY-MM-DD` shape is checked first: 10 characters, `-` at positions 4 and 7, and
digits everywhere else (or a regular expression, if you know them).

## 5. `valid_leads.json`

A JSON **array** with one object per valid row, **in file order**. Each object has
**exactly the 9 columns** as keys, in column order, with the types from the table
in section 4:

```json
[
  {
    "lead_id": "L-1001",
    "full_name": "Maria Gonzalez",
    "email": "maria.gonzalez@example.com",
    "loan_amount": 385000.0,
    "credit_score": 742,
    "annual_income": 118000.0,
    "property_state": "TX",
    "loan_type": "purchase",
    "created_at": "2026-09-01"
  },
  {
    "lead_id": "L-1002",
    "full_name": "James Carter",
    "email": "james.carter@example.com",
    "loan_amount": 212500.0,
    "credit_score": 688,
    "annual_income": 76000.0,
    "property_state": "OK",
    "loan_type": "refinance",
    "created_at": "2026-09-01"
  }
]
```

Note `385000.0`, not `385000`: amounts are floats, and `json.dump` writes a float
with `.0`. If there are no valid rows, write `[]`.

## 6. `report.json`

A JSON **object** with these keys:

| Key | Value |
|---|---|
| `run_at` | Local time when the run started, ISO format to the second: `datetime.now().isoformat(timespec="seconds")` |
| `input_file` | The input path exactly as given on the command line, as a string |
| `total_rows` | Number of rows (blank lines not counted) |
| `valid_rows` | Rows with zero errors |
| `invalid_rows` | Rows with one or more errors (`total_rows - valid_rows`) |
| `errors_by_field` | `{field: number of errors}` for every field with at least one error, keys sorted A to Z. `columns` counts as a field. |
| `errors` | Every error, ordered by row, then by column order within a row (`columns` first): `{"row", "lead_id", "field", "message"}` |

`lead_id` in an error is the trimmed ID, or `""` when the ID is missing.
`invalid_rows` counts rows; `errors` counts problems. A row with two problems adds
1 to `invalid_rows` and 2 entries to `errors`.

Example, shortened, for the sample file:

```json
{
  "run_at": "2026-10-03T14:02:11",
  "input_file": "data/leads_sample.csv",
  "total_rows": 20,
  "valid_rows": 9,
  "invalid_rows": 11,
  "errors_by_field": {
    "created_at": 1,
    "credit_score": 2,
    "email": 1,
    "full_name": 1,
    "lead_id": 1,
    "loan_amount": 3,
    "loan_type": 1,
    "property_state": 1
  },
  "errors": [
    {"row": 4, "lead_id": "L-1003", "field": "email", "message": "not a valid email address: aisha.rahman@example"},
    {"row": 5, "lead_id": "L-1004", "field": "loan_amount", "message": "must be greater than 0: -50000"},
    {"row": 16, "lead_id": "L-1007", "field": "lead_id", "message": "duplicate of an earlier row"}
  ]
}
```

(The real file lists all 11 errors.) Both JSON files are written with
`indent=2` and UTF-8, into `--output-dir`, which the tool creates if it doesn't
exist (`mkdir(parents=True, exist_ok=True)`).

## 7. Logging

- Use `logging`, not `print`. Set it up as on Day 4:
  `format="%(asctime)s %(levelname)-8s %(name)s: %(message)s"`, with the level
  from the `LOG_LEVEL` environment variable (read `.env` with `load_dotenv()`;
  a real environment variable wins over `.env`). Default: `INFO`.
- **One DEBUG line per row**, starting with `Row <row number>`:

      2026-10-03 14:02:11,412 DEBUG    lead_intake.cli: Row 2 (L-1001): ok
      2026-10-03 14:02:11,412 DEBUG    lead_intake.cli: Row 4 (L-1003): invalid: email
      2026-10-03 14:02:11,413 DEBUG    lead_intake.cli: Row 82 (no id): invalid: lead_id

- **One INFO summary line** at the end, with the three counts:

      2026-10-03 14:02:11,415 INFO     lead_intake.cli: 20 rows: 9 valid, 11 invalid. Wrote out

- **One ERROR line** when the input can't be read:

      2026-10-03 14:02:11,402 ERROR    lead_intake.cli: Input file not found: nope.csv

Other DEBUG lines (such as the arguments) are fine, as long as they don't start
with `Row <number>`. At `LOG_LEVEL=INFO` no DEBUG lines appear.

## 8. Command line and exit codes

    python -m lead_intake INPUT [--output-dir DIR] [--strict]

| Argument | Meaning |
|---|---|
| `INPUT` | Path to the CSV file (required) |
| `--output-dir DIR` | Where to write the two JSON files. Default: `out` |
| `--strict` | Optional stretch goal: see exit code 2 |

| Exit code | When |
|---|---|
| `0` | The run completed, **even if some rows are invalid**: the report explains them |
| `1` | The input file is missing or can't be read (for example, it isn't UTF-8). Log an ERROR and write nothing |
| `2` | Only with `--strict`: the run completed and at least one row is invalid. (argparse also exits 2 when the command line itself is wrong; both mean "don't trust this run".) |

Have `main()` return the code and end `__main__.py` with `sys.exit(main())`. A bare
`return` exits 0.

## 9. Expected results

| | `leads_sample.csv` | `leads_2026-10-02.csv` |
|---|---|---|
| total / valid / invalid | 20 / 9 / 11 | 250 / 209 / 41 |
| errors | 11 | 45 (4 rows have two problems) |
| `errors_by_field` | loan_amount 3, credit_score 2, created_at 1, email 1, full_name 1, lead_id 1, loan_type 1, property_state 1 | loan_amount 8, credit_score 7, created_at 6, lead_id 5, email 4, loan_type 4, property_state 4, full_name 3, annual_income 2, columns 2 |

Every expected error, as `(row, lead_id, field)`, is in
`expected/<file>.expected.json`. The expected clean output is in
`expected/<file>.valid_leads.json`. Run `check_my_work.py` to compare; see
`README.md`.
