Norvale EV trip data (Week 4). Norvale is a fictional region, made up for a learning exercise.

norvale.json  towns, roads (km and road name), chargers (power kW, connectors, price per kWh,
              status: two are out of service), vehicles (battery kWh, kWh per 100 km, max charge
              kW, connector; the pickup has a towing factor) and a small guidebook of places.
trips.json    14 trip requests in plain English, each with the expected structured request
              (expected_spec) and the expected result (feasible, route, km, charger ids).
