"""The trip team as a LangGraph graph: parallel stop agents, a critic loop, and a human approval
before any charger is reserved."""
import operator
from dataclasses import asdict
from typing import Annotated, TypedDict

from langgraph.graph import END, START, StateGraph
from langgraph.types import Send, interrupt

from trip_drill import agents
from trip_drill.critic import review
from trip_drill.network import ChargePlan, Route, Stop, plan_charging, shortest_route

MAX_REVISIONS = 2


class TripState(TypedDict, total=False):
    request: str
    user_id: str
    spec: dict
    route: dict
    plan: dict
    ideas: list[dict]
    usage: Annotated[list[dict], operator.add]
    itinerary: str
    problems: list[str]
    revisions: int
    status: str
    booked: list[str]


def _route(d: dict) -> Route:
    return Route(d["towns"], [tuple(leg) for leg in d["legs"]])


def _plan(d: dict) -> ChargePlan:
    return ChargePlan(d["feasible"], [Stop(**s) for s in d["stops"]], d["arrival_soc"], d["reason"])


def build_graph(client, net, booking, checkpointer=None):
    def intake(state: TripState):
        spec, u = agents.intake(client, net, state["request"])
        return {"spec": spec.model_dump(), "usage": [u]}

    def plan(state: TripState):
        spec = agents.TripSpec(**state["spec"])
        route = shortest_route(net, spec.origin, spec.destination)
        plan_ = plan_charging(net, route, net.vehicles[spec.vehicle_id], spec.start_soc, spec.reserve,
                              towing=spec.towing)
        return {"route": {"towns": route.towns, "legs": route.legs}, "plan": asdict(plan_)}

    def after_plan(state: TripState):
        if not state["plan"]["feasible"]:
            return "infeasible"
        stops = state["plan"]["stops"]
        if not stops:
            return "writer"
        interests = state["spec"]["interests"]
        return [Send("stop", {"town": s["town"], "minutes": s["minutes"], "interests": interests}) for s in stops]

    def stop(task: dict):                                    # receives ONLY its Send payload, not the state
        idea, u = agents.stop_ideas(client, net, task["town"], task["minutes"], task["interests"])
        return {"ideas": [idea.model_dump()], "usage": [u]}

    def writer(state: TripState):
        spec = agents.TripSpec(**state["spec"])
        view = agents.plan_view(spec, _route(state["route"]), _plan(state["plan"]), state.get("ideas", []))
        itinerary, u = agents.write_itinerary(client, view, state.get("problems", []))
        return {"itinerary": itinerary.summary + "\n" + "\n".join(itinerary.steps), "usage": [u]}

    def critic(state: TripState):
        spec = agents.TripSpec(**state["spec"])
        problems = review(net, _route(state["route"]), net.vehicles[spec.vehicle_id], _plan(state["plan"]),
                          spec, state["itinerary"])
        return {"problems": problems, "revisions": state.get("revisions", 0) + (1 if problems else 0)}

    def after_critic(state: TripState):
        if not state["problems"]:
            return "approve"
        return "writer" if state["revisions"] < MAX_REVISIONS else "needs_human"

    def approve(state: TripState):
        chargers = [s["charger_id"] for s in state["plan"]["stops"]]
        booked = [booking.reserve(c, state.get("user_id", "anonymous")) for c in chargers]
        decision = interrupt({"itinerary": state["itinerary"], "reserve": chargers})
        if decision is not True:
            return {"status": "declined"}
        return {"booked": booked, "status": "booked"}

    g = StateGraph(TripState)
    g.add_node("intake", intake)
    g.add_node("plan", plan)
    g.add_node("stop", stop)
    g.add_node("writer", writer)
    g.add_node("critic", critic)
    g.add_node("approve", approve)
    g.add_node("infeasible", lambda s: {"status": "infeasible"})
    g.add_node("needs_human", lambda s: {"status": "needs_human"})
    g.add_edge(START, "intake")
    g.add_edge("intake", "plan")
    g.add_conditional_edges("plan", after_plan, ["stop", "writer", "infeasible"])
    g.add_edge("stop", "writer")
    g.add_edge("writer", "critic")
    g.add_conditional_edges("critic", after_critic, ["writer", "approve", "needs_human"])
    for node in ("approve", "infeasible", "needs_human"):
        g.add_edge(node, END)
    return g.compile(checkpointer=checkpointer)
