"""The model-backed agents. Each one gets only the context it needs, and returns structured output."""
import json
from dataclasses import asdict

from pydantic import BaseModel, Field

from trip_drill.network import Network

MODEL = "gpt-6-luna"


class TripSpec(BaseModel):
    origin: str
    destination: str
    vehicle_id: str
    start_soc: float = Field(ge=0, le=1, description="state of charge at departure, 0 to 1")
    reserve: float = Field(default=0.10, ge=0.05, le=0.5, description="minimum charge on arrival anywhere")
    towing: bool = False
    interests: list[str] = Field(default_factory=list, description="food, nature, history")


class StopIdeas(BaseModel):
    town: str
    places: list[str]            # names from the guidebook only
    note: str


class Itinerary(BaseModel):
    summary: str
    steps: list[str]


def call(client, agent: str, instructions: str, payload: str, schema):
    """One structured model call. Returns (parsed, usage record) so the graph can total cost per agent."""
    r = client.responses.parse(model=MODEL, instructions=instructions, input=payload,
                               reasoning={"effort": "low"}, text_format=schema)
    if r.output_parsed is None:
        raise RuntimeError(f"{agent}: no structured output (refusal or truncation)")
    return r.output_parsed, {"agent": agent, "input_tokens": r.usage.input_tokens,
                             "output_tokens": r.usage.output_tokens}


INTAKE = """You turn a driver's trip request into a TripSpec for Norvale's EV trip planner.
Use only these town names: {towns}. Use only these vehicle ids: {vehicles}.
If the driver gives a battery percentage, convert it to a fraction (80% -> 0.8).
If they say they are towing, set towing to true. Keep interests to: food, nature, history."""


def intake(client, net: Network, request: str):
    instructions = INTAKE.format(towns=", ".join(net.towns), vehicles=", ".join(net.vehicles))
    return call(client, "intake", instructions, request, TripSpec)


STOP = """You suggest what to do during ONE charging stop on an EV road trip.
Choose at most two places from the guidebook entries given, and only ones that fit in the time available.
Prefer the driver's interests. Never invent a place that isn't listed. If nothing fits, return no places."""


def stop_context(net: Network, town: str, minutes: float, interests: list[str]) -> str:
    """Context engineering: this agent sees one town's places, the time, and the interests. Nothing else."""
    places = [p for p in net.places if p["kind"] in interests]
    return json.dumps({"town": town, "minutes_available": round(minutes), "interests": interests, "guidebook": places})


def stop_ideas(client, net: Network, town: str, minutes: float, interests: list[str]):
    return call(client, f"stop:{town}", STOP, stop_context(net, town, minutes, interests), StopIdeas)


WRITER = """You write a short, practical itinerary for an EV road trip from the plan given.
Use the exact charger ids, towns, percentages and minutes from the plan; never change or add numbers.
One step per leg or stop. Mention the places suggested for each stop."""


def write_itinerary(client, view: dict, feedback: list[str]):
    payload = json.dumps(view) + (f"\nFix these problems from review: {feedback}" if feedback else "")
    return call(client, "writer", WRITER, payload, Itinerary)


def plan_view(spec: TripSpec, route, plan, ideas: list[dict]) -> dict:
    """The compact, structured view the writer reads."""
    return {"trip": f"{spec.origin} to {spec.destination}", "km": route.km, "vehicle": spec.vehicle_id,
            "start_soc": spec.start_soc, "arrival_soc": plan.arrival_soc,
            "stops": [{**asdict(s), "ideas": next((i["places"] for i in ideas if i["town"] == s.town), [])}
                      for s in plan.stops]}
