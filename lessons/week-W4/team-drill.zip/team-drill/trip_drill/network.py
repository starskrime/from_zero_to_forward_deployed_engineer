"""Deterministic trip math: routes, energy and charging stops. No model calls here."""
import heapq
import json
from dataclasses import dataclass, field
from pathlib import Path

TAPER_FROM = 0.80          # above 80% state of charge, charging slows down...
TAPER_SPEED = 0.40         # ...to 40% of the power


@dataclass
class Network:
    towns: list[str]
    roads: dict[str, list[tuple[str, int, str]]]     # town -> [(neighbor, km, road name)]
    chargers: list[dict]
    vehicles: dict[str, dict]
    places: list[dict]


def load_network(path: Path) -> Network:
    raw = json.loads(Path(path).read_text())
    roads: dict[str, list] = {t: [] for t in raw["towns"]}
    for r in raw["roads"]:
        roads[r["a"]].append((r["b"], r["km"], r["road"]))
        roads[r["b"]].append((r["a"], r["km"], r["road"]))
    return Network(raw["towns"], roads, raw["chargers"], {v["id"]: v for v in raw["vehicles"]}, raw["places"])


@dataclass
class Route:
    towns: list[str]
    legs: list[tuple[str, str, int, str]]            # (from, to, km, road)

    @property
    def km(self) -> int:
        return sum(leg[2] for leg in self.legs)


def shortest_route(net: Network, origin: str, destination: str) -> Route:
    """Dijkstra on road km. Ties break alphabetically."""
    for town in (origin, destination):
        if town not in net.roads:
            raise ValueError(f"unknown town: {town}")
    queue, done = [(0, origin, [origin])], set()
    while queue:
        dist, town, path = heapq.heappop(queue)
        if town == destination:
            legs = []
            for a, b in zip(path, path[1:]):
                km, road = next((k, r) for n, k, r in net.roads[a] if n == b)
                legs.append((a, b, km, road))
            return Route(path, legs)
        if town in done:
            continue
        done.add(town)
        for nxt, km, road in net.roads[town]:
            if nxt not in done:
                heapq.heappush(queue, (dist + km, nxt, path + [nxt]))
    raise ValueError(f"no road from {origin} to {destination}")


def kwh_per_km(vehicle: dict, towing: bool = False) -> float:
    factor = vehicle.get("towing_factor", 1.0) if towing else 1.0
    return vehicle["kwh_per_100km"] / 100 * factor


def usable_chargers(net: Network, town: str, connector: str) -> list[dict]:
    """Chargers in a town that work and fit the car, fastest first."""
    return sorted((c for c in net.chargers if c["town"] == town and c["status"] == "available"
                   and connector in c["connectors"]), key=lambda c: (-c["power_kw"], c["id"]))


def charge_minutes(vehicle: dict, charger: dict, soc_from: float, soc_to: float) -> float:
    power = charger["power_kw"]
    below = max(0.0, min(soc_to, TAPER_FROM) - soc_from) * vehicle["battery_kwh"]
    above = max(0.0, soc_to - max(soc_from, TAPER_FROM)) * vehicle["battery_kwh"]
    return (below / power + above / (power * TAPER_SPEED)) * 60


@dataclass
class Stop:
    town: str
    charger_id: str
    arrive_soc: float
    depart_soc: float
    kwh: float
    minutes: float
    cost: float


@dataclass
class ChargePlan:
    feasible: bool
    stops: list[Stop] = field(default_factory=list)
    arrival_soc: float = 0.0
    reason: str = ""


def plan_charging(net: Network, route: Route, vehicle: dict, start_soc: float, reserve: float = 0.10,
                  charge_to: float = 0.80, towing: bool = False) -> ChargePlan:
    """Greedy: drive as far as the reserve allows, charge at the farthest usable charger before that point."""
    per_km = kwh_per_km(vehicle, towing)
    towns, cum = route.towns, [0]
    for leg in route.legs:
        cum.append(cum[-1] + leg[2])

    def soc_after(i: int, j: int, soc: float) -> float:          # drive from town i to town j
        return soc - (cum[j] - cum[i]) * per_km / vehicle["battery_kwh"]

    def chargers_at(j: int) -> list[dict]:
        return usable_chargers(net, towns[j], vehicle["connector"])

    def progress(j: int, depart: float) -> bool:                 # from j, can we reach a charger or the end?
        if soc_after(j, len(towns) - 1, depart) >= reserve:
            return True
        return any(soc_after(j, k, depart) >= reserve and chargers_at(k) for k in range(j + 1, len(towns) - 1))

    stops, i, soc = [], 0, start_soc
    while True:
        if soc_after(i, len(towns) - 1, soc) >= reserve:
            return ChargePlan(True, stops, round(soc_after(i, len(towns) - 1, soc), 3))
        first = i if not stops and i == 0 else i + 1          # the origin's own charger counts, once
        reachable = [j for j in range(first, len(towns) - 1)
                     if (j == i or soc_after(i, j, soc) >= reserve) and chargers_at(j)]
        if not reachable or (reachable[-1] == i and soc >= charge_to):
            return ChargePlan(False, stops, reason=f"no usable charger within range after {towns[i]}")
        j = reachable[-1]
        arrive, target = soc_after(i, j, soc), charge_to
        if not progress(j, target):
            target = 1.0
            if not progress(j, target):
                return ChargePlan(False, stops, reason=f"from {towns[j]}, nothing is in range, even at 100%")
        charger = chargers_at(j)[0]
        depart = max(arrive, target)
        kwh = (depart - arrive) * vehicle["battery_kwh"]
        stops.append(Stop(towns[j], charger["id"], round(arrive, 3), round(depart, 3), round(kwh, 1),
                          round(charge_minutes(vehicle, charger, arrive, depart), 1),
                          round(kwh * charger["price_per_kwh"], 2)))
        i, soc = j, depart


def validate(net: Network, route: Route, vehicle: dict, plan: ChargePlan, start_soc: float,
             reserve: float = 0.10, towing: bool = False) -> list[str]:
    """Independent checks the critic runs on ANY plan, including one a model edited."""
    problems, per_km = [], kwh_per_km(vehicle, towing)
    by_id = {c["id"]: c for c in net.chargers}
    stops = {s.town: s for s in plan.stops}
    soc = start_soc
    if route.towns[0] in stops:                                  # charging before leaving
        soc = max(soc, stops[route.towns[0]].depart_soc)
    for a, b, km, _ in route.legs:
        soc -= km * per_km / vehicle["battery_kwh"]
        if b in stops:
            s = stops[b]
            if soc < reserve - 1e-9:
                problems.append(f"arrives in {b} with {soc:.0%}, below the {reserve:.0%} reserve")
            c = by_id.get(s.charger_id)
            if c is None or c["town"] != b:
                problems.append(f"{s.charger_id} is not a charger in {b}")
            else:
                if c["status"] != "available":
                    problems.append(f"{c['id']} in {b} is {c['status']}")
                if vehicle["connector"] not in c["connectors"]:
                    problems.append(f"{c['id']} in {b} has no {vehicle['connector']} connector")
            soc = max(soc, s.depart_soc)
    problems += [f"stop in {s.town} is not on the route" for s in plan.stops if s.town not in route.towns]
    return problems
