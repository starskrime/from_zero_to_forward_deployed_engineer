"""Programmatic gates: the critic is code, so it can't be talked out of a failed check."""
import re

from trip_drill.network import validate


def review(net, route, vehicle: dict, plan, spec, itinerary_text: str) -> list[str]:
    problems = validate(net, route, vehicle, plan, spec.start_soc, spec.reserve, spec.towing)
    planned = {s.charger_id for s in plan.stops}
    mentioned = set(re.findall(r"CH-\d{2}", itinerary_text))
    problems += [f"itinerary never mentions {c}" for c in sorted(planned - mentioned)]
    problems += [f"itinerary mentions {c}, which is not in the plan" for c in sorted(mentioned - planned)]
    return problems
