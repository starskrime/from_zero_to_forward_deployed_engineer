# Break it & fix it: Week 4

This small trip-planning team (route and charging math, a validator, a stop
agent, a writer, a code critic, and a LangGraph graph with parallel stops, a
revision loop and a human approval before booking) looks fine and runs without
errors. It has six bugs, each one a mistake that shows up in real multi-agent
code.

    pip install langgraph pydantic openai httpx pytest
    python -m pytest -q

Six tests fail. Fix the code in `trip_drill/`, never the tests. For each bug,
write one line in `BUGS.md`: what was wrong, what a driver (or the booking
system) would have seen in production, and how you fixed it.

Everything runs offline: the model replies are scripted and routed by content
(so parallel agents can answer in any order), and the booking system is a fake
that records every reservation, so there is no API cost.
