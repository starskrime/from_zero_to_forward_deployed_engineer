"""Fake Responses API replies, routed by content, so parallel agents can be tested with no network."""
import itertools
import json
import threading

import httpx
from openai import OpenAI

_ids = itertools.count(1)
USAGE = {"input_tokens": 100, "output_tokens": 20, "total_tokens": 120,
         "input_tokens_details": {"cached_tokens": 0}, "output_tokens_details": {"reasoning_tokens": 0}}


def reply(obj: dict) -> dict:
    """A completed response whose text is the JSON of obj (what responses.parse reads)."""
    n = next(_ids)
    return {"id": f"resp_{n}", "object": "response", "created_at": 0, "model": "gpt-6-luna",
            "status": "completed", "usage": USAGE, "parallel_tool_calls": True, "tool_choice": "auto", "tools": [],
            "output": [{"type": "message", "id": f"msg_{n}", "status": "completed", "role": "assistant",
                        "content": [{"type": "output_text", "text": json.dumps(obj), "annotations": []}]}]}


def routed_client(routes: dict[str, list[dict]], requests: list | None = None) -> OpenAI:
    """routes maps a text that appears in the request (instructions + input) to a queue of replies.
    Parallel calls may arrive in any order, so we route by content instead of by position."""
    lock = threading.Lock()
    queues = {k: list(v) for k, v in routes.items()}

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        text = str(body.get("instructions", "")) + json.dumps(body.get("input", ""))
        with lock:
            if requests is not None:
                requests.append(body)
            key = next((k for k in queues if k in text), None)
            if key is None or not queues[key]:
                return httpx.Response(500, json={"error": {"message": f"no scripted reply for: {text[:120]}"}})
            return httpx.Response(200, json=reply(queues[key].pop(0)))

    return OpenAI(api_key="test", max_retries=0, http_client=httpx.Client(transport=httpx.MockTransport(handler)))


class FakeBooking:
    def __init__(self):
        self.calls = []

    def reserve(self, charger_id: str, user_id: str) -> str:
        self.calls.append((charger_id, user_id))
        return f"R-{charger_id}"
