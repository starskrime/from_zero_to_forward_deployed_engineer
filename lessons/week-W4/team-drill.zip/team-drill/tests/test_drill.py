"""Six of these tests fail. Each failure is a bug in trip_drill/, not in the tests. Fix the code."""
import json
from pathlib import Path

import pytest
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command

from trip_drill import agents
from trip_drill.critic import review
from trip_drill.graph import build_graph
from trip_drill.network import (ChargePlan, Stop, charge_minutes, load_network, plan_charging, shortest_route,
                                usable_chargers, validate)
from tests.fakes import FakeBooking, routed_client

NET = load_network(Path(__file__).resolve().parent.parent / "data" / "norvale.json")
CITY = NET.vehicles["voltra-city"]          # 50 kWh, 16 kWh/100 km, charges at up to 100 kW, CCS

# One stop: Ashford -> Dunmore, charging at CH-03 in Cedar Falls.
SHORT = {"origin": "Ashford", "destination": "Dunmore", "vehicle_id": "voltra-city", "start_soc": 0.9,
         "interests": ["food"]}
SHORT_GOOD = {"summary": "Ashford to Dunmore, 300 km, one stop.",
              "steps": ["Charge at CH-03 in Cedar Falls from 21% to 80% (18 min), lunch at Old Mill Diner."]}
SHORT_BAD = {"summary": "One stop.", "steps": ["Charge at CH-04 in Cedar Falls."]}

# Two stops: Ashford -> Kestrel Point, charging at CH-10 in Harlow and CH-08 in Fairhaven.
LONG = {**SHORT, "destination": "Kestrel Point"}
LONG_GOOD = {"summary": "Ashford to Kestrel Point, 540 km, two stops.",
             "steps": ["Charge at CH-10 in Harlow to 100% (31 min).", "Charge at CH-08 in Fairhaven to 80% (18 min)."]}

WRITER = "You write a short, practical itinerary"          # listed first: its input names the towns too
INTAKE = "You turn a driver's trip request"


def stop_key(town):
    """Matches only the stop agent's own request for this town (its payload starts with town, minutes)."""
    return f'\\"town\\": \\"{town}\\", \\"minutes_available'


def short_trip(writer_replies):
    return routed_client({WRITER: writer_replies, INTAKE: [SHORT],
                          stop_key("Cedar Falls"): [{"town": "Cedar Falls", "places": ["Old Mill Diner"], "note": "fits"}]})


def run(app, thread, request="Ashford to Dunmore", user="u1"):
    return app.invoke({"request": request, "user_id": user}, {"configurable": {"thread_id": thread}})


# --- deterministic trip tools ---------------------------------------------------------------------

def test_shortest_route_and_greedy_stops():
    route = shortest_route(NET, "Ashford", "Kestrel Point")
    assert route.towns == ["Ashford", "Millbrook", "Harlow", "Ironbridge", "Fairhaven", "Kestrel Point"]
    assert route.km == 540
    plan = plan_charging(NET, route, CITY, 0.9)
    assert [(s.town, s.charger_id, s.depart_soc) for s in plan.stops] == [("Harlow", "CH-10", 1.0),
                                                                         ("Fairhaven", "CH-08", 0.8)]
    assert validate(NET, route, CITY, plan, 0.9) == []


def test_usable_chargers_skip_broken_and_wrong_connector():
    assert usable_chargers(NET, "Ironbridge", "CCS") == []                  # NACS only
    assert usable_chargers(NET, "Northgate", "CCS") == []                   # out of service
    assert [c["id"] for c in usable_chargers(NET, "Cedar Falls", "CCS")] == ["CH-03", "CH-04"]


def test_charge_minutes_uses_the_slower_of_car_and_charger():
    ch = next(c for c in NET.chargers if c["id"] == "CH-03")               # a 350 kW charger
    assert charge_minutes(CITY, ch, 0.2, 0.8) == pytest.approx(18.0)       # 30 kWh at the car's 100 kW
    assert charge_minutes(CITY, ch, 0.8, 1.0) == pytest.approx(15.0)       # 10 kWh at 40 kW (taper)


def test_validator_flags_a_low_arrival_at_the_destination():
    route = shortest_route(NET, "Ashford", "Harlow")                        # 200 km = 64% of the battery
    plan = ChargePlan(True, [], 0.04)                                       # e.g. a plan a model edited
    assert validate(NET, route, CITY, plan, 0.68) == ["arrives in Harlow with 4%, below the 10% reserve"]


def test_validator_flags_chargers_the_car_cannot_use():
    route = shortest_route(NET, "Cedar Falls", "Elmstead")                  # via Dunmore
    for charger_id, problem in [("CH-05", "CH-05 in Dunmore has no CCS connector"),
                                ("CH-06", "CH-06 in Dunmore is out_of_service"),
                                ("CH-10", "CH-10 is not a charger in Dunmore")]:
        plan = ChargePlan(True, [Stop("Dunmore", charger_id, 0.628, 0.9, 13.6, 10.0, 6.0)], 0.548)
        assert validate(NET, route, CITY, plan, 0.9) == [problem]


# --- agents and hand-offs --------------------------------------------------------------------------

def test_critic_catches_wrong_charger_in_text():
    spec = agents.TripSpec(**LONG)
    route = shortest_route(NET, spec.origin, spec.destination)
    plan = plan_charging(NET, route, CITY, spec.start_soc)
    problems = review(NET, route, CITY, plan, spec, "Charge at CH-10, then CH-11.")
    assert problems == ["itinerary never mentions CH-08", "itinerary mentions CH-11, which is not in the plan"]


def test_stop_agent_sees_only_its_town():
    ctx = json.loads(agents.stop_context(NET, "Harlow", 31.2, ["food"]))
    assert ctx["town"] == "Harlow" and ctx["minutes_available"] == 31
    assert "Harlow cheese market" in [p["name"] for p in ctx["guidebook"]]
    assert {p["town"] for p in ctx["guidebook"]} == {"Harlow"}              # no places from other towns
    assert "voltra" not in json.dumps(ctx)                                  # and nothing about the car


def test_writer_hand_off_carries_the_critics_feedback():
    reqs = []
    client = routed_client({WRITER: [SHORT_GOOD]}, reqs)
    view = {"trip": "Ashford to Dunmore", "stops": [{"town": "Cedar Falls", "charger_id": "CH-03"}]}
    itinerary, usage = agents.write_itinerary(client, view, ["itinerary never mentions CH-03"])
    assert itinerary.steps == SHORT_GOOD["steps"] and usage["agent"] == "writer"
    assert "Fix these problems from review: ['itinerary never mentions CH-03']" in reqs[0]["input"]


# --- the graph -------------------------------------------------------------------------------------

def test_parallel_stop_agents_both_land_in_state():
    client = routed_client({WRITER: [LONG_GOOD], INTAKE: [LONG],
                            stop_key("Harlow"): [{"town": "Harlow", "places": ["Harlow cheese market"], "note": "fits"}],
                            stop_key("Fairhaven"): [{"town": "Fairhaven", "places": [], "note": "no food listed"}]})
    app = build_graph(client, NET, FakeBooking(), InMemorySaver())
    paused = run(app, "long-1", "Ashford to Kestrel Point")
    assert sorted(i["town"] for i in paused["ideas"]) == ["Fairhaven", "Harlow"]
    assert paused["__interrupt__"][0].value["reserve"] == ["CH-10", "CH-08"]


def test_graph_revises_until_the_critic_passes():
    app = build_graph(short_trip([SHORT_BAD, SHORT_GOOD]), NET, FakeBooking(), InMemorySaver())
    paused = run(app, "short-1")
    assert "__interrupt__" in paused and paused["problems"] == []
    assert [u["agent"] for u in paused["usage"]].count("writer") == 2


def test_graph_gives_up_after_max_revisions():
    app = build_graph(short_trip([SHORT_BAD] * 4), NET, FakeBooking(), InMemorySaver())
    out = run(app, "short-2")
    assert out["status"] == "needs_human"
    assert [u["agent"] for u in out["usage"]].count("writer") == 3          # first draft + MAX_REVISIONS


def test_graph_books_only_after_the_human_approves():
    booking = FakeBooking()
    app = build_graph(short_trip([SHORT_GOOD]), NET, booking, InMemorySaver())
    paused = run(app, "short-3")
    assert paused["__interrupt__"][0].value["reserve"] == ["CH-03"]
    assert booking.calls == []                                              # nothing reserved while waiting
    done = app.invoke(Command(resume=True), {"configurable": {"thread_id": "short-3"}})
    assert done["status"] == "booked" and done["booked"] == ["R-CH-03"]
    assert booking.calls == [("CH-03", "u1")]                               # exactly one per charger


def test_graph_decline_ends_the_run():
    app = build_graph(short_trip([SHORT_GOOD]), NET, FakeBooking(), InMemorySaver())
    run(app, "short-4")
    out = app.invoke(Command(resume=False), {"configurable": {"thread_id": "short-4"}})
    assert out["status"] == "declined" and "CH-03" in out["itinerary"] and "booked" not in out


def test_graph_infeasible_stops_before_any_agent_but_intake():
    spec = {**SHORT, "origin": "Cedar Falls", "destination": "Wolf Ridge"}
    app = build_graph(routed_client({INTAKE: [spec]}), NET, FakeBooking(), InMemorySaver())
    out = run(app, "far-1", "Cedar Falls to Wolf Ridge")
    assert out["status"] == "infeasible" and not out.get("ideas")
    assert [u["agent"] for u in out["usage"]] == ["intake"]
